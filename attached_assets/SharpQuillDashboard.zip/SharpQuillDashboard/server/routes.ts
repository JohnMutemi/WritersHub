import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { zodResolver } from "@hookform/resolvers/zod";
import { 
  insertJobSchema, 
  insertBidSchema, 
  insertMessageSchema, 
  insertDisputeSchema,
  User
} from "@shared/schema";
import { setupAuth, hashPassword, comparePasswords } from "./auth";
import { setupWebSockets } from "./socket";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  setupAuth(app);
  
  // Create HTTP server
  const httpServer = createServer(app);

  // Jobs API
  app.get("/api/jobs", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const jobs = await storage.getOpenJobs();
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch jobs" });
    }
  });

  app.get("/api/jobs/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const job = await storage.getJob(parseInt(req.params.id));
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }
      res.json(job);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch job" });
    }
  });

  app.post("/api/jobs", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "client") return res.status(403).json({ message: "Only clients can post jobs" });
    
    try {
      console.log("Job submission data:", JSON.stringify(req.body, null, 2));
      
      // Validate the data (the schema will handle date conversion automatically)
      const validatedData = insertJobSchema.parse(req.body);
      console.log("Validated job data:", JSON.stringify(validatedData, null, 2));
      
      const job = await storage.createJob({
        ...validatedData,
        clientId: req.user.id
      });
      
      res.status(201).json(job);
    } catch (error) {
      console.error("Job validation error:", error);
      res.status(400).json({ message: "Invalid job data", error: JSON.stringify(error) });
    }
  });

  // Bids API
  app.get("/api/jobs/:jobId/bids", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const jobId = parseInt(req.params.jobId);
      const job = await storage.getJob(jobId);
      
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }
      
      // Only the client who posted the job can see all bids
      if (req.user.role !== "admin" && req.user.id !== job.clientId && req.user.role !== "writer") {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const bids = await storage.getBidsByJob(jobId);
      
      // If user is a writer, only show their own bids
      if (req.user.role === "writer" && req.user.id !== job.clientId) {
        const filteredBids = bids.filter(bid => bid.writerId === req.user.id);
        return res.json(filteredBids);
      }
      
      res.json(bids);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bids" });
    }
  });

  app.post("/api/jobs/:jobId/bids", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "writer") return res.status(403).json({ message: "Only writers can place bids" });
    
    try {
      const jobId = parseInt(req.params.jobId);
      const job = await storage.getJob(jobId);
      
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }
      
      if (job.status !== "open") {
        return res.status(400).json({ message: "Cannot bid on a job that's not open" });
      }
      
      // Check if writer already has a bid for this job
      const existingBids = await storage.getBidsByJob(jobId);
      const hasExistingBid = existingBids.some(bid => bid.writerId === req.user.id);
      
      if (hasExistingBid) {
        return res.status(400).json({ message: "You already have a bid for this job" });
      }
      
      const validatedData = insertBidSchema.parse(req.body);
      const bid = await storage.createBid({
        ...validatedData,
        jobId,
        writerId: req.user.id
      });
      
      // Create notification for client
      await storage.createNotification({
        userId: job.clientId,
        type: "new_bid",
        title: "New Bid Received",
        message: `You've received a new bid on your job: ${job.title}`,
        relatedId: bid.id
      });
      
      res.status(201).json(bid);
    } catch (error) {
      res.status(400).json({ message: "Invalid bid data", error });
    }
  });

  app.put("/api/bids/:bidId/accept", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "client") return res.status(403).json({ message: "Only clients can accept bids" });
    
    try {
      const bidId = parseInt(req.params.bidId);
      const bid = await storage.getBid(bidId);
      
      if (!bid) {
        return res.status(404).json({ message: "Bid not found" });
      }
      
      const job = await storage.getJob(bid.jobId);
      
      if (!job) {
        return res.status(404).json({ message: "Associated job not found" });
      }
      
      if (job.clientId !== req.user.id) {
        return res.status(403).json({ message: "You can only accept bids for your own jobs" });
      }
      
      if (job.status !== "open") {
        return res.status(400).json({ message: "This job is no longer open for bids" });
      }
      
      // Update bid status
      await storage.updateBid(bidId, { status: "accepted" });
      
      // Update job status
      await storage.updateJob(job.id, { status: "in_progress" });
      
      // Create order
      const order = await storage.createOrder({
        jobId: job.id,
        clientId: job.clientId,
        writerId: bid.writerId,
        bidId: bid.id,
        status: "in_progress",
        paymentStatus: "pending"
      });
      
      // Create transaction for escrow
      await storage.createTransaction({
        orderId: order.id,
        clientId: job.clientId,
        writerId: bid.writerId,
        amount: bid.amount,
        type: "deposit",
        status: "completed",
        description: `Deposit for order #${order.id} - ${job.title}`
      });
      
      // Create notifications
      await storage.createNotification({
        userId: bid.writerId,
        type: "bid_accepted",
        title: "Bid Accepted",
        message: `Your bid for "${job.title}" has been accepted!`,
        relatedId: order.id
      });
      
      await storage.createNotification({
        userId: job.clientId,
        type: "order_created",
        title: "Order Created",
        message: `Your order for "${job.title}" has been created.`,
        relatedId: order.id
      });
      
      res.json(order);
    } catch (error) {
      res.status(500).json({ message: "Failed to accept bid" });
    }
  });

  // Orders API
  app.get("/api/orders", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      let orders;
      
      if (req.user.role === "admin") {
        orders = Array.from(await storage.getOrdersByStatus("in_progress"));
      } else if (req.user.role === "client") {
        orders = await storage.getOrdersByClient(req.user.id);
      } else if (req.user.role === "writer") {
        orders = await storage.getOrdersByWriter(req.user.id);
      }
      
      res.json(orders);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  app.get("/api/orders/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const order = await storage.getOrder(parseInt(req.params.id));
      
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      // Check if user has permission to view this order
      if (req.user.role !== "admin" && req.user.id !== order.clientId && req.user.id !== order.writerId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      res.json(order);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch order" });
    }
  });

  app.put("/api/orders/:id/complete", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "writer") return res.status(403).json({ message: "Only writers can complete orders" });
    
    try {
      const orderId = parseInt(req.params.id);
      const order = await storage.getOrder(orderId);
      
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      if (order.writerId !== req.user.id) {
        return res.status(403).json({ message: "You can only complete your own orders" });
      }
      
      if (order.status !== "in_progress") {
        return res.status(400).json({ message: "This order cannot be completed" });
      }
      
      const { submittedWork } = req.body;
      
      if (!submittedWork) {
        return res.status(400).json({ message: "Submitted work is required" });
      }
      
      // Update order
      const updatedOrder = await storage.updateOrder(orderId, {
        submittedWork,
        status: "completed",
        completedAt: new Date()
      });
      
      // Create notification for client
      await storage.createNotification({
        userId: order.clientId,
        type: "order_completed",
        title: "Order Completed",
        message: "Your order has been completed and is ready for review!",
        relatedId: order.id
      });
      
      res.json(updatedOrder);
    } catch (error) {
      res.status(500).json({ message: "Failed to complete order" });
    }
  });

  app.put("/api/orders/:id/review", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "client") return res.status(403).json({ message: "Only clients can review orders" });
    
    try {
      const orderId = parseInt(req.params.id);
      const order = await storage.getOrder(orderId);
      
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      if (order.clientId !== req.user.id) {
        return res.status(403).json({ message: "You can only review your own orders" });
      }
      
      if (order.status !== "completed") {
        return res.status(400).json({ message: "This order is not ready for review" });
      }
      
      const { clientReview, writerRating } = req.body;
      
      if (!clientReview || !writerRating) {
        return res.status(400).json({ message: "Review and rating are required" });
      }
      
      // Update order with review
      const updatedOrder = await storage.updateOrder(orderId, {
        clientReview,
        writerRating
      });
      
      // Get writer
      const writer = await storage.getUser(order.writerId);
      
      if (writer) {
        // Calculate new writer rating
        const writerOrders = await storage.getOrdersByWriter(writer.id);
        const reviewedOrders = writerOrders.filter(o => o.writerRating !== undefined && o.writerRating !== null);
        
        if (reviewedOrders.length > 0) {
          const totalRating = reviewedOrders.reduce((sum, o) => sum + (o.writerRating || 0), 0);
          const newRating = totalRating / reviewedOrders.length;
          
          // Update writer rating
          await storage.updateUser(writer.id, { rating: newRating });
        }
        
        // Process payment to writer
        await storage.createTransaction({
          orderId: order.id,
          clientId: order.clientId,
          writerId: order.writerId,
          amount: (await storage.getBid(order.bidId))?.amount || 0,
          type: "payment",
          status: "completed",
          description: `Payment for completed order #${order.id}`
        });
        
        // Create notification for writer
        await storage.createNotification({
          userId: order.writerId,
          type: "order_reviewed",
          title: "Order Reviewed",
          message: `Your order has been reviewed and payment has been released.`,
          relatedId: order.id
        });
      }
      
      res.json(updatedOrder);
    } catch (error) {
      res.status(500).json({ message: "Failed to review order" });
    }
  });

  // Messages API
  app.get("/api/messages/order/:orderId", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const orderId = parseInt(req.params.orderId);
      const order = await storage.getOrder(orderId);
      
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      // Check if user has permission to view messages for this order
      if (req.user.role !== "admin" && req.user.id !== order.clientId && req.user.id !== order.writerId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const messages = await storage.getMessagesByOrder(orderId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  app.post("/api/messages", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const validatedData = insertMessageSchema.parse(req.body);
      
      // Verify sender is current user
      if (validatedData.senderId !== req.user.id) {
        return res.status(403).json({ message: "Invalid sender" });
      }
      
      // If order is provided, verify that sender and receiver are involved in the order
      if (validatedData.orderId) {
        const order = await storage.getOrder(validatedData.orderId);
        
        if (!order) {
          return res.status(404).json({ message: "Order not found" });
        }
        
        if (req.user.id !== order.clientId && req.user.id !== order.writerId) {
          return res.status(403).json({ message: "You are not involved in this order" });
        }
        
        if (validatedData.receiverId !== order.clientId && validatedData.receiverId !== order.writerId) {
          return res.status(403).json({ message: "Invalid receiver for this order" });
        }
      }
      
      const message = await storage.createMessage(validatedData);
      
      // Create notification for receiver
      await storage.createNotification({
        userId: validatedData.receiverId,
        type: "new_message",
        title: "New Message",
        message: "You have received a new message",
        relatedId: message.id
      });
      
      res.status(201).json(message);
    } catch (error) {
      res.status(400).json({ message: "Invalid message data", error });
    }
  });

  // Notifications API
  app.get("/api/notifications", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const notifications = await storage.getUserNotifications(req.user.id);
      res.json(notifications);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.put("/api/notifications/:id/read", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const notificationId = parseInt(req.params.id);
      const notification = await storage.getNotification(notificationId);
      
      if (!notification) {
        return res.status(404).json({ message: "Notification not found" });
      }
      
      if (notification.userId !== req.user.id) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      await storage.markNotificationAsRead(notificationId);
      res.sendStatus(200);
    } catch (error) {
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  // Disputes API
  app.get("/api/disputes", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "admin") return res.status(403).json({ message: "Only admins can view all disputes" });
    
    try {
      const disputes = await storage.getDisputes();
      res.json(disputes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch disputes" });
    }
  });

  app.post("/api/disputes", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "client") return res.status(403).json({ message: "Only clients can open disputes" });
    
    try {
      const validatedData = insertDisputeSchema.parse(req.body);
      
      const order = await storage.getOrder(validatedData.orderId);
      
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      if (order.clientId !== req.user.id) {
        return res.status(403).json({ message: "You can only open disputes for your own orders" });
      }
      
      // Set clientId and writerId from order
      validatedData.clientId = order.clientId;
      validatedData.writerId = order.writerId;
      
      const dispute = await storage.createDispute(validatedData);
      
      // Update order status
      await storage.updateOrder(order.id, { status: "disputed" });
      
      // Create notifications
      await storage.createNotification({
        userId: order.writerId,
        type: "dispute_opened",
        title: "Dispute Opened",
        message: `A dispute has been opened for order #${order.id}`,
        relatedId: dispute.id
      });
      
      const adminUsers = await storage.getUsersByRole("admin");
      for (const admin of adminUsers) {
        await storage.createNotification({
          userId: admin.id,
          type: "new_dispute",
          title: "New Dispute",
          message: `A new dispute has been opened for order #${order.id}`,
          relatedId: dispute.id
        });
      }
      
      res.status(201).json(dispute);
    } catch (error) {
      res.status(400).json({ message: "Invalid dispute data", error });
    }
  });

  app.put("/api/disputes/:id/resolve", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "admin") return res.status(403).json({ message: "Only admins can resolve disputes" });
    
    try {
      const disputeId = parseInt(req.params.id);
      const dispute = await storage.getDispute(disputeId);
      
      if (!dispute) {
        return res.status(404).json({ message: "Dispute not found" });
      }
      
      const { resolution, refundAmount } = req.body;
      
      if (!resolution) {
        return res.status(400).json({ message: "Resolution is required" });
      }
      
      // Update dispute
      const updatedDispute = await storage.updateDispute(disputeId, {
        status: "resolved",
        resolution,
        resolvedBy: req.user.id,
        resolvedAt: new Date()
      });
      
      // Update order status
      await storage.updateOrder(dispute.orderId, { status: "completed" });
      
      // Handle refund if necessary
      if (refundAmount && refundAmount > 0) {
        await storage.createTransaction({
          orderId: dispute.orderId,
          clientId: dispute.clientId,
          writerId: dispute.writerId,
          amount: refundAmount,
          type: "refund",
          status: "completed",
          description: `Refund for dispute on order #${dispute.orderId}`
        });
      }
      
      // Create notifications
      await storage.createNotification({
        userId: dispute.clientId,
        type: "dispute_resolved",
        title: "Dispute Resolved",
        message: `Your dispute for order #${dispute.orderId} has been resolved`,
        relatedId: disputeId
      });
      
      await storage.createNotification({
        userId: dispute.writerId,
        type: "dispute_resolved",
        title: "Dispute Resolved",
        message: `The dispute for order #${dispute.orderId} has been resolved`,
        relatedId: disputeId
      });
      
      res.json(updatedDispute);
    } catch (error) {
      res.status(500).json({ message: "Failed to resolve dispute" });
    }
  });

  // User Management API (Admin only)
  app.get("/api/users", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "admin") return res.status(403).json({ message: "Access denied" });
    
    try {
      const users = await storage.getUsers();
      // Remove passwords from response
      const sanitizedUsers = users.map(user => {
        const { password, ...userWithoutPassword } = user;
        return userWithoutPassword;
      });
      res.json(sanitizedUsers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });
  
  app.get("/api/users/pending-writers", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "admin") return res.status(403).json({ message: "Access denied" });
    
    try {
      const users = await storage.getUsers();
      const pendingWriters = users
        .filter(user => user.role === "writer" && 
                       (!user.approvalStatus || user.approvalStatus === "pending"))
        .map(user => {
          const { password, ...userWithoutPassword } = user;
          return userWithoutPassword;
        });
      res.json(pendingWriters);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch pending writers" });
    }
  });

  app.put("/api/users/:id/ban", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "admin") return res.status(403).json({ message: "Access denied" });
    
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // In a real app, we would set a 'banned' flag and possibly log them out
      // For now, just return success
      res.json({ success: true, message: "User banned" });
    } catch (error) {
      res.status(500).json({ message: "Failed to ban user" });
    }
  });
  
  app.put("/api/users/:id/approve", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "admin") return res.status(403).json({ message: "Access denied" });
    
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      if (user.role !== "writer") {
        return res.status(400).json({ message: "Only writers can be approved" });
      }
      
      const { approved } = req.body;
      
      // Update the user's approval status
      const updatedUser = await storage.updateUser(userId, {
        approvalStatus: approved ? "approved" : "rejected"
      });
      
      // Create a notification for the writer
      await storage.createNotification({
        userId: userId,
        type: approved ? "writer_approved" : "writer_rejected",
        title: approved ? "Application Approved" : "Application Rejected",
        message: approved 
          ? "Congratulations! Your writer application has been approved. You can now start bidding on jobs."
          : "We regret to inform you that your writer application has been rejected.",
        read: false
      });
      
      const { password, ...userWithoutPassword } = updatedUser || user;
      res.json({ 
        success: true, 
        message: approved ? "Writer approved" : "Writer rejected",
        user: userWithoutPassword
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to update writer status" });
    }
  });
  
  // Writer quiz API
  app.post("/api/writers/:id/quiz", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "writer" && req.user.role !== "admin") {
      return res.status(403).json({ message: "Access denied" });
    }
    
    try {
      const writerId = parseInt(req.params.id);
      
      // Admin can submit for any writer, but writers can only submit their own quiz
      if (req.user.role === "writer" && req.user.id !== writerId) {
        return res.status(403).json({ message: "You can only submit your own quiz" });
      }
      
      const writer = await storage.getUser(writerId);
      
      if (!writer) {
        return res.status(404).json({ message: "Writer not found" });
      }
      
      if (writer.role !== "writer") {
        return res.status(400).json({ message: "User is not a writer" });
      }
      
      const { answers, score, passed } = req.body;
      
      // Update the writer's profile with quiz results
      const updatedWriter = await storage.updateUser(writerId, {
        quizScore: score,
        quizPassed: passed
      });
      
      // Create a notification for the writer if admin submitted it
      if (req.user.role === "admin") {
        await storage.createNotification({
          userId: writerId,
          type: passed ? "quiz_passed" : "quiz_failed",
          title: passed ? "Quiz Passed" : "Quiz Failed",
          message: passed 
            ? `Congratulations! You passed the writer qualification quiz with a score of ${score}%.`
            : `You did not pass the writer qualification quiz (${score}%). An admin will review your results.`,
          read: false
        });
      }
      
      res.json({ 
        success: true, 
        score,
        passed,
        message: "Quiz results recorded successfully"
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to submit quiz results" });
    }
  });
  
  // Get quiz results for a specific writer
  app.get("/api/writers/:id/quiz", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const writerId = parseInt(req.params.id);
      const writer = await storage.getUser(writerId);
      
      if (!writer) {
        return res.status(404).json({ message: "Writer not found" });
      }
      
      // Writers can only view their own results, but admins can view any
      if (req.user.role !== "admin" && req.user.id !== writerId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      res.json({
        quizScore: writer.quizScore || 0,
        quizPassed: writer.quizPassed || false,
        approvalStatus: writer.approvalStatus || "pending"
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch quiz results" });
    }
  });

  // Stats API (for dashboards)
  app.get("/api/stats", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const userId = req.user.id;
      const role = req.user.role;
      let stats = {};
      
      if (role === "admin") {
        // Get admin stats
        const allUsers = await storage.getUsers();
        const clients = allUsers.filter(user => user.role === "client").length;
        const writers = allUsers.filter(user => user.role === "writer").length;
        
        const allOrders = await storage.getOrdersByStatus("in_progress");
        const completedOrders = await storage.getOrdersByStatus("completed");
        const disputes = await storage.getOpenDisputes();
        
        const transactions = Array.from(await storage.getUserTransactions(userId));
        const currentMonth = new Date().getMonth();
        const monthlyRevenue = transactions
          .filter(t => {
            if (t.type !== "deposit" || t.status !== "completed") return false;
            
            // Safely handle the date
            const createdAt = t.createdAt ? new Date(t.createdAt) : null;
            return createdAt && createdAt.getMonth() === currentMonth;
          })
          .reduce((sum, t) => sum + t.amount, 0);
        
        stats = {
          totalUsers: allUsers.length,
          clientCount: clients,
          writerCount: writers,
          activeOrders: allOrders.length,
          completedOrders: completedOrders.length,
          pendingDisputes: disputes.length,
          monthlyRevenue
        };
      } else if (role === "writer") {
        // Get writer stats
        const ordersInProgress = await storage.getOrdersByWriter(userId);
        const activeOrders = ordersInProgress.filter(o => o.status === "in_progress").length;
        const completedOrders = ordersInProgress.filter(o => o.status === "completed").length;
        
        const writer = await storage.getUser(userId);
        
        const transactions = Array.from(await storage.getUserTransactions(userId));
        const currentMonth = new Date().getMonth();
        const monthlyEarnings = transactions
          .filter(t => {
            if (t.type !== "payment" || t.status !== "completed") return false;
            
            // Safely handle the date
            const createdAt = t.createdAt ? new Date(t.createdAt) : null;
            return createdAt && createdAt.getMonth() === currentMonth;
          })
          .reduce((sum, t) => sum + t.amount, 0);
        
        stats = {
          ordersInProgress: activeOrders,
          completedOrders,
          rating: writer?.rating || 0,
          earnings: monthlyEarnings
        };
      } else if (role === "client") {
        // Get client stats
        const myOrders = await storage.getOrdersByClient(userId);
        const activeOrders = myOrders.filter(o => o.status === "in_progress").length;
        const completedOrders = myOrders.filter(o => o.status === "completed").length;
        
        const myJobs = await storage.getClientJobs(userId);
        const openJobs = myJobs.filter(j => j.status === "open").length;
        
        const jobIdsWithBids = new Set(
          (await Promise.all(myJobs.map(async job => {
            const bids = await storage.getBidsByJob(job.id);
            return bids.length > 0 ? job.id : null;
          }))).filter(id => id !== null)
        );
        
        const openBids = jobIdsWithBids.size;
        
        const transactions = Array.from(await storage.getUserTransactions(userId));
        const totalSpending = transactions
          .filter(t => (t.type === "deposit" || t.type === "payment") && 
                    t.status === "completed")
          .reduce((sum, t) => sum + t.amount, 0);
        
        stats = {
          activeOrders,
          completedOrders,
          openJobs,
          openBids,
          totalSpending
        };
      }
      
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });
  
  // Writer's bids API
  app.get("/api/writers/bids", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "writer") return res.status(403).json({ message: "Access denied" });
    
    try {
      const bids = await storage.getBidsByWriter(req.user.id);
      
      // For each bid, fetch the related job details
      const bidsWithJobDetails = await Promise.all(
        bids.map(async (bid) => {
          const job = await storage.getJob(bid.jobId);
          if (job) {
            const client = await storage.getUser(job.clientId);
            return {
              ...bid,
              job: {
                ...job,
                client: client ? {
                  id: client.id,
                  fullName: client.fullName,
                  profilePicture: client.profilePicture
                } : null
              }
            };
          }
          return bid;
        })
      );
      
      res.json(bidsWithJobDetails);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bids" });
    }
  });

  // Transactions / Withdraw API
  app.post("/api/transactions/withdraw", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "writer") return res.status(403).json({ message: "Only writers can withdraw funds" });
    
    try {
      const withdrawSchema = z.object({
        amount: z.number().positive("Amount must be positive"),
        paymentMethod: z.string().min(1, "Payment method is required"),
        accountInfo: z.string().min(1, "Account information is required")
      });
      
      const validatedData = withdrawSchema.parse(req.body);
      
      // Get writer's current earnings
      const writer = await storage.getUser(req.user.id);
      
      if (!writer || !writer.earnings) {
        return res.status(400).json({ message: "Writer profile not found or no earnings available" });
      }
      
      if (validatedData.amount > writer.earnings) {
        return res.status(400).json({ message: "Insufficient balance" });
      }
      
      // Create withdrawal transaction
      const transaction = await storage.createTransaction({
        clientId: req.user.id, // Using clientId field as the user who's withdrawing
        amount: validatedData.amount,
        type: "withdrawal",
        status: "pending",
        description: `Withdrawal to ${validatedData.paymentMethod}: ${validatedData.accountInfo}`
      });
      
      // Update user's earnings
      await storage.updateUser(req.user.id, {
        earnings: writer.earnings - validatedData.amount
      });
      
      // Create notification
      await storage.createNotification({
        userId: req.user.id,
        type: "withdrawal_requested",
        title: "Withdrawal Requested",
        message: `Your withdrawal request for $${validatedData.amount} has been submitted.`,
        relatedId: transaction.id
      });
      
      // Notify admin about the withdrawal request
      const admins = await storage.getUsersByRole("admin");
      if (admins.length > 0) {
        await Promise.all(
          admins.map(admin => 
            storage.createNotification({
              userId: admin.id,
              type: "withdrawal_admin",
              title: "New Withdrawal Request",
              message: `Writer ${writer.fullName} has requested a withdrawal of $${validatedData.amount}.`,
              relatedId: transaction.id
            })
          )
        );
      }
      
      res.status(201).json({ 
        transaction,
        message: "Withdrawal request submitted successfully" 
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid withdrawal data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to process withdrawal" });
    }
  });

  // User profile update API
  app.patch("/api/users/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    // Users can only update their own profile (except admins)
    if (req.user.role !== "admin" && parseInt(req.params.id) !== req.user.id) {
      return res.status(403).json({ message: "Access denied" });
    }
    
    try {
      const updateData: Partial<User> = {
        fullName: req.body.fullName,
        email: req.body.email,
        bio: req.body.bio || null
      };
      
      // Handle specializations if provided
      if (req.body.specializations) {
        try {
          const specializations = JSON.parse(req.body.specializations);
          updateData.specializations = Array.isArray(specializations) ? specializations : null;
        } catch (e) {
          // If parsing fails, set to null
          updateData.specializations = null;
        }
      }
      
      // Profile image handling would go here (requires file upload middleware)
      // For now, we'll skip it
      
      const updatedUser = await storage.updateUser(parseInt(req.params.id), updateData);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Return updated user without password
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Failed to update profile" });
    }
  });
  
  // Admin APIs
  
  // Get admin stats
  app.get("/api/admin/stats", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "admin") return res.status(403).json({ message: "Access denied" });
    
    try {
      const allUsers = await storage.getUsers();
      const writers = allUsers.filter(user => user.role === "writer");
      const clients = allUsers.filter(user => user.role === "client");
      
      // Get pending writers (not fully verified)
      const pendingVerifications = writers.filter(writer => writer.approvalStatus === "pending").length;
      
      // Get jobs
      const allJobs = await storage.getJobs();
      const activeJobs = allJobs.filter(job => job.status === "open").length;
      const completedJobs = allJobs.filter(job => job.status === "completed").length;
      
      // Get disputes
      const disputes = await storage.getDisputes();
      const openDisputes = disputes.filter(dispute => dispute.status !== "resolved").length;
      
      // Get transactions
      const transactions = await storage.getUserTransactions(0); // 0 to get all transactions
      const revenue = transactions
        .filter(tx => tx.type === "deposit" && tx.status === "completed")
        .reduce((sum, tx) => sum + tx.amount, 0);
      
      res.json({
        totalUsers: allUsers.length,
        totalWriters: writers.length,
        totalClients: clients.length,
        pendingVerifications,
        activeJobs,
        completedJobs,
        totalDisputes: openDisputes,
        totalTransactions: transactions.length,
        totalRevenue: revenue,
        usersGrowth: 5, // Mock growth value
        revenueGrowth: 8 // Mock growth value
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch admin stats" });
    }
  });
  
  // Get all users (admin only)
  app.get("/api/admin/users", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "admin") return res.status(403).json({ message: "Access denied" });
    
    try {
      const users = await storage.getUsers();
      
      // Remove passwords before sending
      const usersWithoutPasswords = users.map(user => {
        const { password, ...userWithoutPassword } = user;
        return {
          ...userWithoutPassword,
          isActive: true, // Mocked active status
        };
      });
      
      res.json(usersWithoutPasswords);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });
  
  // Get pending writer applications
  app.get("/api/admin/writers/pending", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "admin") return res.status(403).json({ message: "Access denied" });
    
    try {
      const writers = await storage.getUsersByRole("writer");
      const pendingWriters = writers.filter(writer => 
        writer.approvalStatus === "pending" || writer.approvalStatus === null
      );
      
      // Remove passwords before sending
      const pendingWritersWithoutPasswords = pendingWriters.map(writer => {
        const { password, ...writerWithoutPassword } = writer;
        return {
          ...writerWithoutPassword,
          quizScore: writer.quizScore || null // Ensure quiz score is available
        };
      });
      
      res.json(pendingWritersWithoutPasswords);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch pending writers" });
    }
  });
  
  // Approve a writer
  app.post("/api/admin/writers/:id/approve", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "admin") return res.status(403).json({ message: "Access denied" });
    
    try {
      const writerId = parseInt(req.params.id);
      const writer = await storage.getUser(writerId);
      
      if (!writer) {
        return res.status(404).json({ message: "Writer not found" });
      }
      
      if (writer.role !== "writer") {
        return res.status(400).json({ message: "User is not a writer" });
      }
      
      // Update writer verification status
      const updatedWriter = await storage.updateUser(writerId, {
        approvalStatus: "approved"
      });
      
      if (!updatedWriter) {
        return res.status(500).json({ message: "Failed to update writer status" });
      }
      
      // Create notification for the writer
      await storage.createNotification({
        userId: writerId,
        type: "account_approved",
        title: "Account Approved",
        message: "Your writer account has been approved. You can now bid on jobs and start earning!",
      });
      
      // Return success
      res.json({ success: true, message: "Writer approved successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to approve writer" });
    }
  });
  
  // Reject a writer
  app.post("/api/admin/writers/:id/reject", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "admin") return res.status(403).json({ message: "Access denied" });
    
    try {
      const writerId = parseInt(req.params.id);
      const writer = await storage.getUser(writerId);
      
      if (!writer) {
        return res.status(404).json({ message: "Writer not found" });
      }
      
      if (writer.role !== "writer") {
        return res.status(400).json({ message: "User is not a writer" });
      }
      
      // Update writer verification status
      const updatedWriter = await storage.updateUser(writerId, {
        approvalStatus: "rejected"
      });
      
      if (!updatedWriter) {
        return res.status(500).json({ message: "Failed to update writer status" });
      }
      
      // Create notification for the writer
      await storage.createNotification({
        userId: writerId,
        type: "account_rejected",
        title: "Account Application Rejected",
        message: "We regret to inform you that your writer application has been rejected. Please contact support for more information.",
      });
      
      // Return success
      res.json({ success: true, message: "Writer rejected successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to reject writer" });
    }
  });
  
  // Get admin transactions
  app.get("/api/admin/transactions", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "admin") return res.status(403).json({ message: "Access denied" });
    
    try {
      const transactions = await storage.getUserTransactions(0); // 0 to get all transactions
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });
  
  // Client-specific APIs
  
  // Get client jobs
  app.get("/api/clients/jobs", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "client") return res.status(403).json({ message: "Access denied" });
    
    try {
      const jobs = await storage.getClientJobs(req.user.id);
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch client jobs" });
    }
  });
  
  // Get client orders
  app.get("/api/clients/orders", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "client") return res.status(403).json({ message: "Access denied" });
    
    try {
      const orders = await storage.getOrdersByClient(req.user.id);
      // For each order, attach title and other job details
      const ordersWithDetails = await Promise.all(
        orders.map(async (order) => {
          const job = await storage.getJob(order.jobId);
          const bid = await storage.getBid(order.bidId);
          
          return {
            ...order,
            title: job?.title || `Order #${order.id}`,
            deadline: job?.deadline,
            amount: bid?.amount || 0,
            deliveryDate: bid?.deliveryDate
          };
        })
      );
      
      res.json(ordersWithDetails);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch client orders" });
    }
  });
  
  // Get client statistics
  app.get("/api/clients/stats", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "client") return res.status(403).json({ message: "Access denied" });
    
    try {
      // Get client's jobs
      const clientJobs = await storage.getClientJobs(req.user.id);
      
      // Get client's orders
      const clientOrders = await storage.getOrdersByClient(req.user.id);
      
      // Calculate statistics
      const activeJobs = clientJobs.filter(job => job.status === "open").length;
      const pendingOrders = clientOrders.filter(order => order.status === "in_progress").length;
      const completedOrders = clientOrders.filter(order => order.status === "completed").length;
      
      // Get transaction data
      const transactions = await storage.getUserTransactions(req.user.id);
      const totalSpent = transactions
        .filter(tx => tx.type === "deposit" && tx.status === "completed")
        .reduce((sum, tx) => sum + tx.amount, 0);
        
      // Mock growth values for demo
      const jobsChange = 10; // 10% increase
      const ordersChange = 5; // 5% increase
      const completedOrdersChange = 8; // 8% increase
      const spendingChange = 15; // 15% increase
      
      // Get all bids for client's jobs
      const allBids = await Promise.all(
        clientJobs.map(async job => await storage.getBidsByJob(job.id))
      );
      const pendingBids = allBids
        .flat()
        .filter(bid => bid.status === "pending")
        .length;
      
      // Get monthly spending data (mock)
      const currentMonth = new Date().getMonth();
      const monthlySpending = Array(6).fill(0).map((_, i) => ({
        month: new Date(2025, currentMonth - 5 + i, 1).toLocaleDateString('en-US', { month: 'short' }),
        amount: Math.floor(Math.random() * 3000) + 1000 // Random amount between 1000 and 4000
      }));
      
      res.json({
        activeJobs,
        jobsChange,
        pendingOrders,
        ordersChange,
        completedOrders,
        completedOrdersChange,
        totalSpent,
        spendingChange,
        pendingBids,
        monthlySpending
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch client statistics" });
    }
  });
  
  // Get top writers for client
  app.get("/api/writers/top", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      // Get writers with a rating
      const allWriters = await storage.getUsersByRole("writer");
      const topWriters = allWriters
        .filter(writer => 
          writer.rating !== undefined && 
          writer.rating !== null && 
          writer.approvalStatus === "approved"
        )
        .sort((a, b) => (b.rating || 0) - (a.rating || 0))
        .slice(0, 6); // Get top 6 writers
      
      // Remove sensitive data
      const processedWriters = topWriters.map(writer => {
        const { password, ...rest } = writer;
        return rest;
      });
      
      res.json(processedWriters);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch top writers" });
    }
  });
  
  // Writer-specific APIs
  
  // Get writer bids
  app.get("/api/writers/bids", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "writer") return res.status(403).json({ message: "Access denied" });
    
    try {
      const bids = await storage.getBidsByWriter(req.user.id);
      // For each bid, attach job title and other details
      const bidsWithDetails = await Promise.all(
        bids.map(async (bid) => {
          const job = await storage.getJob(bid.jobId);
          return {
            ...bid,
            jobTitle: job?.title || `Job #${bid.jobId}`,
            jobDescription: job?.description,
            clientId: job?.clientId
          };
        })
      );
      
      res.json(bidsWithDetails);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch writer bids" });
    }
  });
  
  // Get open jobs for writer
  app.get("/api/writers/jobs", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "writer") return res.status(403).json({ message: "Access denied" });
    
    try {
      // Get all open jobs
      const openJobs = await storage.getOpenJobs();
      
      // For each job, check if the writer has already placed a bid
      const jobsWithBidInfo = await Promise.all(
        openJobs.map(async (job) => {
          const bids = await storage.getBidsByJob(job.id);
          const hasPlacedBid = bids.some(bid => bid.writerId === req.user.id);
          
          return {
            ...job,
            hasPlacedBid
          };
        })
      );
      
      res.json(jobsWithBidInfo);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch open jobs" });
    }
  });
  
  // Get writer statistics
  app.get("/api/writers/stats", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "writer") return res.status(403).json({ message: "Access denied" });
    
    try {
      // Get the writer's orders
      const writerOrders = await storage.getOrdersByWriter(req.user.id);
      
      // Calculate order statistics
      const ordersInProgress = writerOrders.filter(order => order.status === "in_progress").length;
      const completedOrders = writerOrders.filter(order => order.status === "completed").length;
      
      // Get writer's bids
      const writerBids = await storage.getBidsByWriter(req.user.id);
      const pendingBids = writerBids.filter(bid => bid.status === "pending").length;
      
      // Get writer's earnings from transactions
      const transactions = await storage.getUserTransactions(req.user.id);
      const earnings = transactions
        .filter(tx => tx.type === "payment" && tx.status === "completed")
        .reduce((sum, tx) => sum + tx.amount, 0);
      
      // Mock growth values for demo
      const ordersChange = 8; // 8% increase
      const completedOrdersChange = 5; // 5% increase
      const ratingChange = 3; // 3% increase
      const earningsChange = 12; // 12% increase
      
      // Get writer info
      const writer = await storage.getUser(req.user.id);
      
      // Calculate monthly earnings (mock data for demo)
      const currentMonth = new Date().getMonth();
      const monthlyEarnings = Array(6).fill(0).map((_, i) => ({
        month: new Date(2025, currentMonth - 5 + i, 1).toLocaleDateString('en-US', { month: 'short' }),
        amount: Math.floor(Math.random() * 2000) + 1000 // Random amount between 1000 and 3000
      }));
      
      // Calculate pending payments
      const pendingPayments = writerOrders
        .filter(order => order.status === "completed" && !order.clientReview)
        .length;
      
      res.json({
        ordersInProgress,
        ordersChange,
        completedOrders,
        completedOrdersChange,
        rating: writer?.rating || 0,
        ratingChange,
        earnings,
        earningsChange,
        pendingBids,
        monthlyEarnings,
        pendingPayments
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch writer statistics" });
    }
  });
  
  // Admin-specific APIs
  
  // Get admin dashboard statistics
  app.get("/api/admin/stats", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "admin") return res.status(403).json({ message: "Access denied" });
    
    try {
      // Get all users
      const users = await storage.getUsers();
      const totalUsers = users.length;
      
      // Get client/writer counts
      const clients = users.filter(user => user.role === "client").length;
      const writers = users.filter(user => user.role === "writer").length;
      
      // Get active jobs
      const jobs = await storage.getJobs();
      const activeJobs = jobs.filter(job => job.status === "open").length;
      
      // Get disputes
      const disputes = await storage.getDisputes();
      const totalDisputes = disputes.length;
      const openDisputes = disputes.filter(dispute => dispute.status === "open").length;
      
      // Get transactions data
      const transactions = Array.from((await storage.getJobs()).values())
        .flatMap(async job => {
          const order = await storage.getOrdersByClient(job.clientId);
          return order.flatMap(async o => await storage.getUserTransactions(o.clientId));
        });
      
      // Mock total revenue and growth values
      const totalRevenue = 25000; // $25,000
      const revenueGrowth = 15; // 15% growth
      
      // Mock user growth value
      const usersGrowth = 12; // 12% growth
      
      // Get all orders
      const orders = Array.from((await storage.getJobs()).values())
        .flatMap(async job => {
          return await storage.getOrdersByClient(job.clientId);
        });
      
      res.json({
        totalUsers,
        clients,
        writers,
        usersGrowth,
        activeJobs,
        totalDisputes,
        openDisputes,
        totalRevenue,
        revenueGrowth
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch admin statistics" });
    }
  });
  
  // User profile APIs
  
  // Get user profile
  app.get("/api/profile", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const user = await storage.getUser(req.user.id);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove sensitive data
      const { password, ...userProfile } = user;
      
      res.json(userProfile);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch profile" });
    }
  });
  
  // Update user profile
  app.put("/api/profile", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      // Validate and sanitize inputs
      const {
        fullName,
        email,
        bio,
        specializations,
        profilePicture
      } = req.body;
      
      // Prepare update data
      const updateData: Partial<User> = {};
      
      if (fullName) updateData.fullName = fullName;
      if (email) updateData.email = email;
      if (bio !== undefined) updateData.bio = bio;
      if (specializations !== undefined) updateData.specializations = specializations;
      if (profilePicture !== undefined) updateData.profilePicture = profilePicture;
      
      // Update the user
      const updatedUser = await storage.updateUser(req.user.id, updateData);
      
      if (!updatedUser) {
        return res.status(500).json({ message: "Failed to update profile" });
      }
      
      // Remove password before sending
      const { password, ...userProfile } = updatedUser;
      
      res.json(userProfile);
    } catch (error) {
      res.status(400).json({ message: "Failed to update profile", error });
    }
  });
  
  // Change password
  app.put("/api/profile/password", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const { currentPassword, newPassword } = req.body;
      
      if (!currentPassword || !newPassword) {
        return res.status(400).json({ message: "Current password and new password are required" });
      }
      
      // Get the user
      const user = await storage.getUser(req.user.id);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Use imported auth functions
      
      // Verify current password
      const isPasswordCorrect = await comparePasswords(currentPassword, user.password);
      
      if (!isPasswordCorrect) {
        return res.status(401).json({ message: "Current password is incorrect" });
      }
      
      // Hash the new password
      const hashedPassword = await hashPassword(newPassword);
      
      // Update the password
      const updatedUser = await storage.updateUser(req.user.id, {
        password: hashedPassword
      });
      
      if (!updatedUser) {
        return res.status(500).json({ message: "Failed to update password" });
      }
      
      res.json({ success: true, message: "Password updated successfully" });
    } catch (error) {
      res.status(400).json({ message: "Failed to update password", error });
    }
  });
  
  // Setup WebSockets for real-time messaging
  setupWebSockets(httpServer);

  return httpServer;
}
