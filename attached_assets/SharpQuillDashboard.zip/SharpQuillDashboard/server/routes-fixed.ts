import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertJobSchema, insertBidSchema, insertMessageSchema, insertDisputeSchema } from "@shared/schema";
import { setupAuth } from "./auth";
import { setupWebSockets } from "./socket";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  setupAuth(app);
  
  // Create HTTP server (will be returned at the end)
  const httpServer = createServer(app);
  
  // Setup WebSockets
  setupWebSockets(httpServer);

  // Jobs API
  app.get("/api/jobs", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const jobs = await storage.getOpenJobs();
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch jobs" });
    }
  });

  app.get("/api/jobs/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const job = await storage.getJob(parseInt(req.params.id));
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }
      res.json(job);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch job" });
    }
  });

  app.post("/api/jobs", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "client") return res.status(403).json({ message: "Only clients can post jobs" });
    
    try {
      const validatedData = insertJobSchema.parse(req.body);
      const job = await storage.createJob({
        ...validatedData,
        clientId: req.user.id
      });
      res.status(201).json(job);
    } catch (error) {
      res.status(400).json({ message: "Invalid job data", error });
    }
  });

  // Bids API
  app.get("/api/jobs/:jobId/bids", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const jobId = parseInt(req.params.jobId);
      const job = await storage.getJob(jobId);
      
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }
      
      // Only the client who posted the job can see all bids
      if (req.user.role !== "admin" && req.user.id !== job.clientId && req.user.role !== "writer") {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const bids = await storage.getBidsByJob(jobId);
      
      // If user is a writer, only show their own bids
      if (req.user.role === "writer" && req.user.id !== job.clientId) {
        const filteredBids = bids.filter(bid => bid.writerId === req.user.id);
        return res.json(filteredBids);
      }
      
      res.json(bids);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bids" });
    }
  });

  app.post("/api/jobs/:jobId/bids", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "writer") return res.status(403).json({ message: "Only writers can place bids" });
    
    try {
      const jobId = parseInt(req.params.jobId);
      const job = await storage.getJob(jobId);
      
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }
      
      if (job.status !== "open") {
        return res.status(400).json({ message: "Cannot bid on a job that's not open" });
      }
      
      // Check if writer already has a bid for this job
      const existingBids = await storage.getBidsByJob(jobId);
      const hasExistingBid = existingBids.some(bid => bid.writerId === req.user.id);
      
      if (hasExistingBid) {
        return res.status(400).json({ message: "You already have a bid for this job" });
      }
      
      const validatedData = insertBidSchema.parse(req.body);
      const bid = await storage.createBid({
        ...validatedData,
        jobId,
        writerId: req.user.id
      });
      
      // Create notification for client
      await storage.createNotification({
        userId: job.clientId,
        type: "new_bid",
        title: "New Bid Received",
        message: `You've received a new bid on your job: ${job.title}`,
        relatedId: bid.id
      });
      
      res.status(201).json(bid);
    } catch (error) {
      res.status(400).json({ message: "Invalid bid data", error });
    }
  });

  app.put("/api/bids/:bidId/accept", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "client") return res.status(403).json({ message: "Only clients can accept bids" });
    
    try {
      const bidId = parseInt(req.params.bidId);
      const bid = await storage.getBid(bidId);
      
      if (!bid) {
        return res.status(404).json({ message: "Bid not found" });
      }
      
      const job = await storage.getJob(bid.jobId);
      
      if (!job) {
        return res.status(404).json({ message: "Associated job not found" });
      }
      
      if (job.clientId !== req.user.id) {
        return res.status(403).json({ message: "You can only accept bids for your own jobs" });
      }
      
      if (job.status !== "open") {
        return res.status(400).json({ message: "This job is no longer open for bids" });
      }
      
      // Update bid status
      await storage.updateBid(bidId, { status: "accepted" });
      
      // Update job status
      await storage.updateJob(job.id, { status: "in_progress" });
      
      // Create order
      const order = await storage.createOrder({
        jobId: job.id,
        clientId: job.clientId,
        writerId: bid.writerId,
        bidId: bid.id,
        status: "in_progress",
        paymentStatus: "pending"
      });
      
      // Create transaction for escrow
      await storage.createTransaction({
        orderId: order.id,
        clientId: job.clientId,
        writerId: bid.writerId,
        amount: bid.amount,
        type: "deposit",
        status: "completed",
        description: `Deposit for order #${order.id} - ${job.title}`
      });
      
      // Create notifications
      await storage.createNotification({
        userId: bid.writerId,
        type: "bid_accepted",
        title: "Bid Accepted",
        message: `Your bid for "${job.title}" has been accepted!`,
        relatedId: order.id
      });
      
      await storage.createNotification({
        userId: job.clientId,
        type: "order_created",
        title: "Order Created",
        message: `Your order for "${job.title}" has been created.`,
        relatedId: order.id
      });
      
      res.json(order);
    } catch (error) {
      res.status(500).json({ message: "Failed to accept bid" });
    }
  });

  // API routes for other endpoints...
  // (More routes would be added here)
  
  // User API
  app.get("/api/users/:role", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    if (req.user.role !== "admin" && req.params.role !== req.user.role) {
      return res.status(403).json({ message: "Access denied" });
    }
    
    try {
      const users = await storage.getUsersByRole(req.params.role);
      // Remove sensitive info
      const sanitizedUsers = users.map(user => {
        const { password, ...userWithoutPassword } = user;
        return userWithoutPassword;
      });
      res.json(sanitizedUsers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });
  
  // Return the HTTP server to be used elsewhere
  return httpServer;
}