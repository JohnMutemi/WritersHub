import {
  users,
  jobs,
  bids,
  orders,
  messages,
  disputes,
  notifications,
  transactions,
  type User,
  type InsertUser,
  type Job,
  type InsertJob,
  type Bid,
  type InsertBid,
  type Order,
  type Message,
  type InsertMessage,
  type Dispute,
  type InsertDispute,
  type Notification,
  type Transaction
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";

const MemoryStore = createMemoryStore(session);

// Password hashing
const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

export interface IStorage {
  // User management
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUsers(): Promise<User[]>;
  getUsersByRole(role: string): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<User>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;

  // Job management
  getJob(id: number): Promise<Job | undefined>;
  getJobs(): Promise<Job[]>;
  getOpenJobs(): Promise<Job[]>;
  getClientJobs(clientId: number): Promise<Job[]>;
  createJob(job: InsertJob & { clientId: number }): Promise<Job>;
  updateJob(id: number, data: Partial<Job>): Promise<Job | undefined>;
  deleteJob(id: number): Promise<boolean>;

  // Bid management
  getBid(id: number): Promise<Bid | undefined>;
  getBidsByJob(jobId: number): Promise<Bid[]>;
  getBidsByWriter(writerId: number): Promise<Bid[]>;
  createBid(bid: InsertBid & { writerId: number }): Promise<Bid>;
  updateBid(id: number, data: Partial<Bid>): Promise<Bid | undefined>;
  deleteBid(id: number): Promise<boolean>;

  // Order management
  getOrder(id: number): Promise<Order | undefined>;
  getOrdersByClient(clientId: number): Promise<Order[]>;
  getOrdersByWriter(writerId: number): Promise<Order[]>;
  getOrdersByStatus(status: string): Promise<Order[]>;
  createOrder(order: Partial<Order>): Promise<Order>;
  updateOrder(id: number, data: Partial<Order>): Promise<Order | undefined>;
  
  // Message management
  getMessage(id: number): Promise<Message | undefined>;
  getMessagesByOrder(orderId: number): Promise<Message[]>;
  getConversation(user1Id: number, user2Id: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  markMessageAsRead(id: number): Promise<boolean>;
  
  // Dispute management
  getDispute(id: number): Promise<Dispute | undefined>;
  getDisputes(): Promise<Dispute[]>;
  getOpenDisputes(): Promise<Dispute[]>;
  createDispute(dispute: InsertDispute): Promise<Dispute>;
  updateDispute(id: number, data: Partial<Dispute>): Promise<Dispute | undefined>;
  
  // Notification management
  getNotification(id: number): Promise<Notification | undefined>;
  getUserNotifications(userId: number): Promise<Notification[]>;
  createNotification(notification: Partial<Notification>): Promise<Notification>;
  markNotificationAsRead(id: number): Promise<boolean>;
  
  // Transaction management
  getTransaction(id: number): Promise<Transaction | undefined>;
  getUserTransactions(userId: number): Promise<Transaction[]>;
  createTransaction(transaction: Partial<Transaction>): Promise<Transaction>;
  updateTransaction(id: number, data: Partial<Transaction>): Promise<Transaction | undefined>;
  
  // Session store
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private userMap: Map<number, User>;
  private jobMap: Map<number, Job>;
  private bidMap: Map<number, Bid>;
  private orderMap: Map<number, Order>;
  private messageMap: Map<number, Message>;
  private disputeMap: Map<number, Dispute>;
  private notificationMap: Map<number, Notification>;
  private transactionMap: Map<number, Transaction>;
  
  public sessionStore: session.SessionStore;
  
  private userId: number = 1;
  private jobId: number = 1;
  private bidId: number = 1;
  private orderId: number = 1;
  private messageId: number = 1;
  private disputeId: number = 1;
  private notificationId: number = 1;
  private transactionId: number = 1;

  constructor() {
    this.userMap = new Map();
    this.jobMap = new Map();
    this.bidMap = new Map();
    this.orderMap = new Map();
    this.messageMap = new Map();
    this.disputeMap = new Map();
    this.notificationMap = new Map();
    this.transactionMap = new Map();
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
    
    // Initialize with demo data
    this.seedDemoData();
  }

  // User management
  async getUser(id: number): Promise<User | undefined> {
    return this.userMap.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.userMap.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase()
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.userMap.values()).find(
      (user) => user.email.toLowerCase() === email.toLowerCase()
    );
  }

  async getUsers(): Promise<User[]> {
    return Array.from(this.userMap.values());
  }

  async getUsersByRole(role: string): Promise<User[]> {
    return Array.from(this.userMap.values()).filter(
      (user) => user.role === role
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const now = new Date();
    const user: User = {
      id,
      ...insertUser,
      rating: 0,
      earnings: 0,
      createdAt: now,
    };
    this.userMap.set(id, user);
    return user;
  }

  async updateUser(id: number, data: Partial<User>): Promise<User | undefined> {
    const user = this.userMap.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...data };
    this.userMap.set(id, updatedUser);
    return updatedUser;
  }

  async deleteUser(id: number): Promise<boolean> {
    return this.userMap.delete(id);
  }

  // Job management
  async getJob(id: number): Promise<Job | undefined> {
    return this.jobMap.get(id);
  }

  async getJobs(): Promise<Job[]> {
    return Array.from(this.jobMap.values());
  }

  async getOpenJobs(): Promise<Job[]> {
    return Array.from(this.jobMap.values()).filter(
      (job) => job.status === 'open'
    );
  }

  async getClientJobs(clientId: number): Promise<Job[]> {
    return Array.from(this.jobMap.values()).filter(
      (job) => job.clientId === clientId
    );
  }

  async createJob(job: InsertJob & { clientId: number }): Promise<Job> {
    const id = this.jobId++;
    const now = new Date();
    const newJob: Job = {
      id,
      ...job,
      status: 'open',
      createdAt: now,
    };
    this.jobMap.set(id, newJob);
    return newJob;
  }

  async updateJob(id: number, data: Partial<Job>): Promise<Job | undefined> {
    const job = this.jobMap.get(id);
    if (!job) return undefined;
    
    const updatedJob = { ...job, ...data };
    this.jobMap.set(id, updatedJob);
    return updatedJob;
  }

  async deleteJob(id: number): Promise<boolean> {
    return this.jobMap.delete(id);
  }

  // Bid management
  async getBid(id: number): Promise<Bid | undefined> {
    return this.bidMap.get(id);
  }

  async getBidsByJob(jobId: number): Promise<Bid[]> {
    return Array.from(this.bidMap.values()).filter(
      (bid) => bid.jobId === jobId
    );
  }

  async getBidsByWriter(writerId: number): Promise<Bid[]> {
    return Array.from(this.bidMap.values()).filter(
      (bid) => bid.writerId === writerId
    );
  }

  async createBid(bid: InsertBid & { writerId: number }): Promise<Bid> {
    const id = this.bidId++;
    const now = new Date();
    const newBid: Bid = {
      id,
      ...bid,
      status: 'pending',
      createdAt: now,
    };
    this.bidMap.set(id, newBid);
    return newBid;
  }

  async updateBid(id: number, data: Partial<Bid>): Promise<Bid | undefined> {
    const bid = this.bidMap.get(id);
    if (!bid) return undefined;
    
    const updatedBid = { ...bid, ...data };
    this.bidMap.set(id, updatedBid);
    return updatedBid;
  }

  async deleteBid(id: number): Promise<boolean> {
    return this.bidMap.delete(id);
  }

  // Order management
  async getOrder(id: number): Promise<Order | undefined> {
    return this.orderMap.get(id);
  }

  async getOrdersByClient(clientId: number): Promise<Order[]> {
    return Array.from(this.orderMap.values()).filter(
      (order) => order.clientId === clientId
    );
  }

  async getOrdersByWriter(writerId: number): Promise<Order[]> {
    return Array.from(this.orderMap.values()).filter(
      (order) => order.writerId === writerId
    );
  }

  async getOrdersByStatus(status: string): Promise<Order[]> {
    return Array.from(this.orderMap.values()).filter(
      (order) => order.status === status
    );
  }

  async createOrder(order: Partial<Order>): Promise<Order> {
    const id = this.orderId++;
    const now = new Date();
    const newOrder: Order = {
      id,
      jobId: order.jobId!,
      clientId: order.clientId!,
      writerId: order.writerId!,
      bidId: order.bidId!,
      status: order.status || 'in_progress',
      paymentStatus: order.paymentStatus || 'pending',
      submittedWork: order.submittedWork,
      clientReview: order.clientReview,
      writerRating: order.writerRating,
      completedAt: order.completedAt,
      createdAt: now,
    };
    this.orderMap.set(id, newOrder);
    return newOrder;
  }

  async updateOrder(id: number, data: Partial<Order>): Promise<Order | undefined> {
    const order = this.orderMap.get(id);
    if (!order) return undefined;
    
    const updatedOrder = { ...order, ...data };
    this.orderMap.set(id, updatedOrder);
    return updatedOrder;
  }

  // Message management
  async getMessage(id: number): Promise<Message | undefined> {
    return this.messageMap.get(id);
  }

  async getMessagesByOrder(orderId: number): Promise<Message[]> {
    return Array.from(this.messageMap.values()).filter(
      (message) => message.orderId === orderId
    ).sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  }

  async getConversation(user1Id: number, user2Id: number): Promise<Message[]> {
    return Array.from(this.messageMap.values()).filter(
      (message) => 
        (message.senderId === user1Id && message.receiverId === user2Id) ||
        (message.senderId === user2Id && message.receiverId === user1Id)
    ).sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const id = this.messageId++;
    const now = new Date();
    const newMessage: Message = {
      id,
      ...message,
      read: false,
      createdAt: now,
    };
    this.messageMap.set(id, newMessage);
    return newMessage;
  }

  async markMessageAsRead(id: number): Promise<boolean> {
    const message = this.messageMap.get(id);
    if (!message) return false;
    
    message.read = true;
    this.messageMap.set(id, message);
    return true;
  }

  // Dispute management
  async getDispute(id: number): Promise<Dispute | undefined> {
    return this.disputeMap.get(id);
  }

  async getDisputes(): Promise<Dispute[]> {
    return Array.from(this.disputeMap.values());
  }

  async getOpenDisputes(): Promise<Dispute[]> {
    return Array.from(this.disputeMap.values()).filter(
      (dispute) => dispute.status === 'open'
    );
  }

  async createDispute(dispute: InsertDispute): Promise<Dispute> {
    const id = this.disputeId++;
    const now = new Date();
    const newDispute: Dispute = {
      id,
      ...dispute,
      status: 'open',
      resolution: undefined,
      resolvedBy: undefined,
      resolvedAt: undefined,
      createdAt: now,
    };
    this.disputeMap.set(id, newDispute);
    return newDispute;
  }

  async updateDispute(id: number, data: Partial<Dispute>): Promise<Dispute | undefined> {
    const dispute = this.disputeMap.get(id);
    if (!dispute) return undefined;
    
    const updatedDispute = { ...dispute, ...data };
    this.disputeMap.set(id, updatedDispute);
    return updatedDispute;
  }

  // Notification management
  async getNotification(id: number): Promise<Notification | undefined> {
    return this.notificationMap.get(id);
  }

  async getUserNotifications(userId: number): Promise<Notification[]> {
    return Array.from(this.notificationMap.values())
      .filter((notification) => notification.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createNotification(notification: Partial<Notification>): Promise<Notification> {
    const id = this.notificationId++;
    const now = new Date();
    const newNotification: Notification = {
      id,
      userId: notification.userId!,
      type: notification.type!,
      title: notification.title!,
      message: notification.message!,
      read: false,
      relatedId: notification.relatedId,
      createdAt: now,
    };
    this.notificationMap.set(id, newNotification);
    return newNotification;
  }

  async markNotificationAsRead(id: number): Promise<boolean> {
    const notification = this.notificationMap.get(id);
    if (!notification) return false;
    
    notification.read = true;
    this.notificationMap.set(id, notification);
    return true;
  }

  // Transaction management
  async getTransaction(id: number): Promise<Transaction | undefined> {
    return this.transactionMap.get(id);
  }

  async getUserTransactions(userId: number): Promise<Transaction[]> {
    return Array.from(this.transactionMap.values()).filter(
      (transaction) => 
        transaction.clientId === userId || transaction.writerId === userId
    );
  }

  async createTransaction(transaction: Partial<Transaction>): Promise<Transaction> {
    const id = this.transactionId++;
    const now = new Date();
    const newTransaction: Transaction = {
      id,
      orderId: transaction.orderId,
      clientId: transaction.clientId!,
      writerId: transaction.writerId,
      amount: transaction.amount!,
      type: transaction.type!,
      status: transaction.status || 'pending',
      description: transaction.description,
      createdAt: now,
    };
    this.transactionMap.set(id, newTransaction);
    return newTransaction;
  }

  async updateTransaction(id: number, data: Partial<Transaction>): Promise<Transaction | undefined> {
    const transaction = this.transactionMap.get(id);
    if (!transaction) return undefined;
    
    const updatedTransaction = { ...transaction, ...data };
    this.transactionMap.set(id, updatedTransaction);
    return updatedTransaction;
  }

  // Seed demo data
  private async seedDemoData() {
    // Create demo users with properly hashed passwords
    const adminPass = await hashPassword("admin123");
    const adminUser = await this.createUser({
      username: "admin",
      password: adminPass,
      email: "admin@sharpquill.com",
      fullName: "Admin User",
      role: "admin",
      bio: "Platform administrator",
      specializations: [],
      profilePicture: "https://ui-avatars.com/api/?name=Admin+User&background=0D8ABC&color=fff"
    });

    const writerPass = await hashPassword("writer123");
    const writerUser = await this.createUser({
      username: "johnwriter",
      password: writerPass,
      email: "john@example.com",
      fullName: "John Doe",
      role: "writer",
      bio: "Experienced writer specializing in academic content",
      specializations: ["Literature", "History", "Philosophy"],
      profilePicture: "https://ui-avatars.com/api/?name=John+Doe&background=4F46E5&color=fff"
    });

    const clientPass = await hashPassword("client123");
    const clientUser = await this.createUser({
      username: "emilyclient",
      password: clientPass,
      email: "emily@example.com",
      fullName: "Emily Johnson",
      role: "client",
      bio: "Looking for quality writing assistance",
      specializations: [],
      profilePicture: "https://ui-avatars.com/api/?name=Emily+Johnson&background=22C55E&color=fff"
    });

    // Create demo jobs
    const job1 = await this.createJob({
      clientId: clientUser.id,
      title: "Research Paper on Climate Change",
      description: "Need a comprehensive research paper on the economic impacts of climate change",
      subject: "Environmental Science",
      type: "Research Paper",
      pages: 10,
      wordCount: 2500,
      academicLevel: "Undergraduate",
      citationStyle: "APA",
      budget: 150,
      deadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
      attachments: []
    });

    const job2 = await this.createJob({
      clientId: clientUser.id,
      title: "Philosophy Essay on Existentialism",
      description: "Looking for a well-written essay on existentialist philosophy focusing on Sartre and Camus",
      subject: "Philosophy",
      type: "Essay",
      pages: 5,
      wordCount: 1250,
      academicLevel: "Undergraduate",
      citationStyle: "MLA",
      budget: 80,
      deadline: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000), // 5 days from now
      attachments: []
    });

    // Create bids
    const bid1 = await this.createBid({
      jobId: job1.id,
      writerId: writerUser.id,
      amount: 130,
      deliveryDate: new Date(Date.now() + 6 * 24 * 60 * 60 * 1000), // 6 days from now
      message: "I have extensive experience researching climate change impacts and can deliver high-quality work before your deadline."
    });

    // Create order (accepted bid)
    const order1 = await this.createOrder({
      jobId: job1.id,
      clientId: clientUser.id,
      writerId: writerUser.id,
      bidId: bid1.id,
      status: 'in_progress'
    });

    // Create messages
    await this.createMessage({
      senderId: clientUser.id,
      receiverId: writerUser.id,
      orderId: order1.id,
      content: "Hello! Looking forward to working with you on this research paper."
    });

    await this.createMessage({
      senderId: writerUser.id,
      receiverId: clientUser.id,
      orderId: order1.id,
      content: "Thank you for accepting my bid! I'll start working on it right away. Do you have any specific requirements or sources you'd like me to use?"
    });

    // Create notifications
    await this.createNotification({
      userId: writerUser.id,
      type: "bid_accepted",
      title: "Bid Accepted",
      message: "Your bid for 'Research Paper on Climate Change' has been accepted.",
      relatedId: order1.id
    });

    await this.createNotification({
      userId: clientUser.id,
      type: "order_started",
      title: "Order Started",
      message: "Work on your 'Research Paper on Climate Change' has begun.",
      relatedId: order1.id
    });

    // Create transaction (downpayment)
    await this.createTransaction({
      orderId: order1.id,
      clientId: clientUser.id,
      writerId: writerUser.id,
      amount: 130,
      type: "deposit",
      status: "completed",
      description: "Downpayment for order #" + order1.id
    });
  }
}

export const storage = new MemStorage();
