import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';
import { storage } from './storage';

interface SocketClient extends WebSocket {
  userId?: number;
  isAlive: boolean;
}

interface Message {
  type: string;
  data: any;
}

export function setupWebSockets(server: Server) {
  const wss = new WebSocketServer({ server, path: '/ws' });
  
  // Map to store user connections
  const clients = new Map<number, SocketClient>();
  
  wss.on('connection', (ws: SocketClient) => {
    ws.isAlive = true;
    
    ws.on('pong', () => {
      ws.isAlive = true;
    });
    
    ws.on('message', async (message: string) => {
      try {
        const parsedMessage: Message = JSON.parse(message);
        
        // Handle authentication
        if (parsedMessage.type === 'auth') {
          const { userId } = parsedMessage.data;
          
          // Verify user exists
          const user = await storage.getUser(userId);
          if (!user) {
            ws.send(JSON.stringify({
              type: 'error',
              data: { message: 'Invalid user ID' }
            }));
            return;
          }
          
          // Save user ID with socket connection
          ws.userId = userId;
          clients.set(userId, ws);
          
          ws.send(JSON.stringify({
            type: 'auth_success',
            data: { userId }
          }));
          
          return;
        }
        
        // Verify authentication for other message types
        if (!ws.userId) {
          ws.send(JSON.stringify({
            type: 'error',
            data: { message: 'Authentication required' }
          }));
          return;
        }
        
        // Handle chat messages
        if (parsedMessage.type === 'chat_message') {
          const { receiverId, content, orderId } = parsedMessage.data;
          
          if (!receiverId || !content) {
            ws.send(JSON.stringify({
              type: 'error',
              data: { message: 'Invalid message data' }
            }));
            return;
          }
          
          // Save message to database
          const message = await storage.createMessage({
            senderId: ws.userId,
            receiverId,
            orderId,
            content
          });
          
          // Create notification
          await storage.createNotification({
            userId: receiverId,
            type: 'new_message',
            title: 'New Message',
            message: 'You have received a new message',
            relatedId: message.id
          });
          
          // Send to the receiver if online
          const receiverSocket = clients.get(receiverId);
          if (receiverSocket && receiverSocket.readyState === WebSocket.OPEN) {
            receiverSocket.send(JSON.stringify({
              type: 'new_message',
              data: message
            }));
          }
          
          // Send confirmation to sender
          ws.send(JSON.stringify({
            type: 'message_sent',
            data: message
          }));
          
          return;
        }
        
        // Handle notifications
        if (parsedMessage.type === 'mark_notification_read') {
          const { notificationId } = parsedMessage.data;
          
          if (!notificationId) {
            ws.send(JSON.stringify({
              type: 'error',
              data: { message: 'Invalid notification ID' }
            }));
            return;
          }
          
          // Verify user owns the notification
          const notification = await storage.getNotification(notificationId);
          if (!notification || notification.userId !== ws.userId) {
            ws.send(JSON.stringify({
              type: 'error',
              data: { message: 'Notification not found or access denied' }
            }));
            return;
          }
          
          // Mark as read
          await storage.markNotificationAsRead(notificationId);
          
          ws.send(JSON.stringify({
            type: 'notification_marked_read',
            data: { notificationId }
          }));
          
          return;
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
        ws.send(JSON.stringify({
          type: 'error',
          data: { message: 'Invalid message format' }
        }));
      }
    });
    
    ws.on('close', () => {
      if (ws.userId) {
        clients.delete(ws.userId);
      }
    });
  });
  
  // Ping clients to ensure connections are still alive
  const interval = setInterval(() => {
    wss.clients.forEach((ws: SocketClient) => {
      if (!ws.isAlive) return ws.terminate();
      
      ws.isAlive = false;
      ws.ping();
    });
  }, 30000);
  
  wss.on('close', () => {
    clearInterval(interval);
  });
}
