import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";
import DashboardPage from "@/pages/dashboard";
import WriterQuizPage from "@/pages/admin/writer-quiz";
import { ThemeProvider } from "@/components/ui/theme-provider";
import ClientDashboard from "@/pages/client/client-dashboard";
import AdminDashboard from "@/pages/admin/admin-dashboard";
import ProfilePage from "@/pages/profile-page";
import MessagesPage from "@/pages/messages";
import { useAuth } from "@/hooks/use-auth";

// Role-based dashboard redirect
function DashboardRouter() {
  const { user, isLoading } = useAuth();
  
  if (isLoading) {
    return <div className="flex items-center justify-center min-h-screen">
      <div className="animate-spin h-10 w-10 border-4 border-primary border-t-transparent rounded-full"></div>
    </div>;
  }
  
  if (!user) return <Redirect to="/auth" />;
  
  switch (user.role) {
    case "client":
      return <ClientDashboard />;
    case "admin":
      return <AdminDashboard />;
    case "writer":
      return <DashboardPage />;
    default:
      return <Redirect to="/auth" />;
  }
}

// Import necessary pages
import JobsPage from "@/pages/jobs-page";
import JobDetailPage from "@/pages/job-detail-page";
import OrdersPage from "@/pages/orders-page";
import OrderDetailPage from "@/pages/order-detail-page";
import ActivityPage from "@/pages/activity-page";
import WriterDashboard from "@/pages/writer/writer-dashboard";
import WritersPage from "@/pages/admin/writers-page";
import DisputesPage from "@/pages/admin/disputes-page";
import TransactionsPage from "@/pages/admin/transactions-page";
import KPIReportsPage from "@/pages/admin/kpi-reports";
import UserManagementPage from "@/pages/admin/user-management";
import SettingsPage from "@/pages/settings-page";

function Router() {
  return (
    <Switch>
      <Route path="/auth" component={AuthPage} />
      <ProtectedRoute path="/" component={DashboardRouter} />
      <ProtectedRoute path="/dashboard" component={DashboardRouter} />
      <ProtectedRoute path="/profile" component={ProfilePage} />
      <ProtectedRoute path="/messages" component={MessagesPage} />
      <ProtectedRoute path="/activity" component={ActivityPage} />
      <ProtectedRoute path="/settings" component={SettingsPage} />
      
      {/* Writer-specific routes */}
      <ProtectedRoute path="/writer-dashboard" component={WriterDashboard} />
      <ProtectedRoute path="/writer-quiz/:id" component={WriterQuizPage} />
      <ProtectedRoute path="/jobs" component={JobsPage} />
      <ProtectedRoute path="/jobs/:id" component={JobDetailPage} />
      <ProtectedRoute path="/orders" component={OrdersPage} />
      <ProtectedRoute path="/orders/:id" component={OrderDetailPage} />
      
      {/* Admin-specific routes */}
      <ProtectedRoute path="/admin/writers" component={WritersPage} />
      <ProtectedRoute path="/admin/disputes" component={DisputesPage} />
      <ProtectedRoute path="/admin/transactions" component={TransactionsPage} />
      <ProtectedRoute path="/admin/kpi-reports" component={KPIReportsPage} />
      <ProtectedRoute path="/admin/user-management" component={UserManagementPage} />
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <ThemeProvider defaultTheme="light" storageKey="sharpquill-theme">
          <Router />
          <Toaster />
        </ThemeProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
