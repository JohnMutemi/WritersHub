import { useState, useEffect, useCallback } from "react";
import { useAuth } from "./use-auth";

export function useSocket() {
  const { user } = useAuth();
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [connected, setConnected] = useState(false);

  // Initialize WebSocket connection
  useEffect(() => {
    if (!user) {
      return;
    }

    // Set up WebSocket connection
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const ws = new WebSocket(wsUrl);

    // Connection opened
    ws.addEventListener("open", () => {
      console.log("WebSocket connection established");
      setConnected(true);
      
      // Authenticate with the server using user ID
      ws.send(JSON.stringify({
        type: "auth",
        data: { userId: user.id }
      }));
    });

    // Connection error
    ws.addEventListener("error", (event) => {
      console.error("WebSocket error:", event);
      setConnected(false);
    });

    // Connection closed
    ws.addEventListener("close", () => {
      console.log("WebSocket connection closed");
      setConnected(false);
    });

    // Store the WebSocket instance
    setSocket(ws);

    // Clean up when component unmounts
    return () => {
      ws.close();
    };
  }, [user]);

  // Reconnect function for manual reconnection
  const reconnect = useCallback(() => {
    if (socket) {
      socket.close();
      setSocket(null);
      setConnected(false);
    }
  }, [socket]);

  return socket;
}
