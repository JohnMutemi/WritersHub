import React from "react";
import { 
  FileText, 
  CheckCircle, 
  Mail, 
  DollarSign, 
  AlertTriangle,
  X
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface Notification {
  id: number;
  type: string;
  title: string;
  message: string;
  read: boolean;
  relatedId?: number;
  createdAt: string;
}

interface NotificationsDropdownProps {
  notifications: Notification[];
  onClose: () => void;
}

export function NotificationsDropdown({ notifications, onClose }: NotificationsDropdownProps) {
  // Handle marking a notification as read
  const handleMarkAsRead = async (id: number) => {
    try {
      await apiRequest("PUT", `/api/notifications/${id}/read`);
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
    } catch (error) {
      console.error("Error marking notification as read:", error);
    }
  };

  // Get icon based on notification type
  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "new_bid":
      case "bid_accepted":
        return <FileText className="h-5 w-5 text-primary-600" />;
      case "order_completed":
      case "order_reviewed":
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case "new_message":
        return <Mail className="h-5 w-5 text-blue-600" />;
      case "payment_released":
        return <DollarSign className="h-5 w-5 text-yellow-600" />;
      case "dispute_opened":
      case "dispute_resolved":
        return <AlertTriangle className="h-5 w-5 text-red-600" />;
      default:
        return <FileText className="h-5 w-5 text-primary-600" />;
    }
  };

  return (
    <div className="absolute right-0 mt-2 w-80 bg-white rounded-md shadow-lg py-1 z-10">
      <div className="px-4 py-2 border-b border-neutral-200 flex justify-between items-center">
        <h3 className="text-sm font-semibold text-neutral-800">Notifications</h3>
        <button
          onClick={onClose}
          className="text-neutral-500 hover:text-neutral-700"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      <div className="max-h-96 overflow-y-auto">
        {notifications.length === 0 ? (
          <div className="px-4 py-3 text-sm text-neutral-500 text-center">
            No notifications yet
          </div>
        ) : (
          notifications.slice(0, 5).map((notification) => (
            <div
              key={notification.id}
              className={`px-4 py-3 hover:bg-neutral-50 border-b border-neutral-100 ${
                !notification.read ? "bg-blue-50" : ""
              }`}
              onClick={() => handleMarkAsRead(notification.id)}
            >
              <div className="flex">
                <div className="flex-shrink-0">
                  <span className="inline-block h-8 w-8 rounded-full bg-primary-100 flex items-center justify-center">
                    {getNotificationIcon(notification.type)}
                  </span>
                </div>
                <div className="ml-3 w-full">
                  <p className="text-sm font-medium text-neutral-800">
                    {notification.title}
                  </p>
                  <p className="text-xs text-neutral-500 mt-1">
                    {notification.message}
                  </p>
                  <p className="text-xs text-neutral-400 mt-1">
                    {formatDistanceToNow(new Date(notification.createdAt), {
                      addSuffix: true,
                    })}
                  </p>
                </div>
                {!notification.read && (
                  <span className="ml-2 h-2 w-2 rounded-full bg-primary-600"></span>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      <div className="px-4 py-2 text-center border-t border-neutral-200">
        <a
          href="/notifications"
          className="text-sm text-primary-600 hover:text-primary-700"
          onClick={(e) => {
            e.preventDefault();
            onClose();
            // Redirect logic would go here
          }}
        >
          View all notifications
        </a>
      </div>
    </div>
  );
}
