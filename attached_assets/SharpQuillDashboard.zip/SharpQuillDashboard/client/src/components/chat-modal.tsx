import React, { useState, useRef, useEffect } from "react";
import { X, Paperclip, Send } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/use-auth";
import { useSocket } from "@/hooks/use-socket";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface Message {
  id: number;
  senderId: number;
  receiverId: number;
  orderId?: number;
  content: string;
  attachment?: string;
  createdAt: string;
}

interface ChatModalProps {
  recipientId: number;
  recipientName: string;
  recipientAvatar: string;
  orderId?: number;
  orderTitle?: string;
  onClose: () => void;
}

export function ChatModal({
  recipientId,
  recipientName,
  recipientAvatar,
  orderId,
  orderTitle,
  onClose
}: ChatModalProps) {
  const { user } = useAuth();
  const socket = useSocket();
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Fetch messages when component mounts
  useEffect(() => {
    const fetchMessages = async () => {
      try {
        setLoading(true);
        let endpoint = orderId 
          ? `/api/messages/order/${orderId}`
          : `/api/messages/conversation/${recipientId}`;
          
        const response = await fetch(endpoint, {
          credentials: "include"
        });
        
        if (!response.ok) {
          throw new Error("Failed to fetch messages");
        }
        
        const data = await response.json();
        setMessages(data);
      } catch (error) {
        console.error("Error fetching messages:", error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchMessages();
  }, [orderId, recipientId]);

  // Scroll to bottom of messages when new ones arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Listen for new messages from WebSocket
  useEffect(() => {
    if (!socket) return;
    
    const handleNewMessage = (data: any) => {
      if (data.type === "new_message") {
        const newMessage = data.data;
        
        // Add message if it's part of this conversation
        if (
          (newMessage.senderId === recipientId && newMessage.receiverId === user?.id) ||
          (newMessage.senderId === user?.id && newMessage.receiverId === recipientId)
        ) {
          setMessages(prevMessages => [...prevMessages, newMessage]);
        }
      }
    };
    
    socket.addEventListener("message", (event) => {
      try {
        const data = JSON.parse(event.data);
        handleNewMessage(data);
      } catch (error) {
        console.error("Error parsing WebSocket message:", error);
      }
    });
    
    return () => {
      // Clean up if needed
    };
  }, [socket, recipientId, user?.id]);

  const handleSendMessage = async () => {
    if (!message.trim() || !user) return;
    
    try {
      // Try to send via WebSocket first
      if (socket && socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({
          type: "chat_message",
          data: {
            receiverId: recipientId,
            content: message,
            orderId
          }
        }));
      } else {
        // Fallback to REST API
        const response = await apiRequest("POST", "/api/messages", {
          senderId: user.id,
          receiverId: recipientId,
          orderId,
          content: message
        });
        
        const newMessage = await response.json();
        setMessages(prevMessages => [...prevMessages, newMessage]);
        
        // Invalidate queries to refresh data
        queryClient.invalidateQueries({ queryKey: [`/api/messages/order/${orderId}`] });
        queryClient.invalidateQueries({ queryKey: [`/api/messages/conversation/${recipientId}`] });
      }
      
      // Clear input field
      setMessage("");
    } catch (error) {
      console.error("Error sending message:", error);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl h-[80vh] flex flex-col">
        {/* Chat Header */}
        <div className="px-5 py-4 border-b border-neutral-200 flex items-center justify-between">
          <div className="flex items-center">
            <img
              src={recipientAvatar}
              alt={recipientName}
              className="w-10 h-10 rounded-full mr-3"
            />
            <div>
              <h3 className="font-medium text-neutral-900">{recipientName}</h3>
              {orderTitle && (
                <p className="text-xs text-neutral-500">
                  Order #{orderId}: {orderTitle}
                </p>
              )}
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="text-neutral-500 hover:text-neutral-700"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>

        {/* Chat Messages */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {loading ? (
            <div className="flex justify-center items-center h-full">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : messages.length === 0 ? (
            <div className="flex justify-center items-center h-full text-neutral-500">
              No messages yet. Start the conversation!
            </div>
          ) : (
            messages.map((msg) => {
              const isSentByCurrentUser = msg.senderId === user?.id;
              
              return (
                <div
                  key={msg.id}
                  className={`flex items-end ${
                    isSentByCurrentUser ? "justify-end" : ""
                  }`}
                >
                  {!isSentByCurrentUser && (
                    <img
                      src={recipientAvatar}
                      alt={recipientName}
                      className="w-8 h-8 rounded-full mr-2"
                    />
                  )}
                  <div
                    className={`px-4 py-2 rounded-lg max-w-xs sm:max-w-md ${
                      isSentByCurrentUser
                        ? "bg-primary-600 text-white rounded-br-none"
                        : "bg-neutral-100 text-neutral-800 rounded-bl-none"
                    }`}
                  >
                    <p className={`text-sm ${isSentByCurrentUser ? "text-white" : "text-neutral-800"}`}>
                      {msg.content}
                    </p>
                    <p
                      className={`text-xs mt-1 ${
                        isSentByCurrentUser ? "text-primary-200" : "text-neutral-500"
                      }`}
                    >
                      {formatDistanceToNow(new Date(msg.createdAt), {
                        addSuffix: true,
                      })}
                    </p>
                    {msg.attachment && (
                      <div className="mt-2 p-2 bg-white rounded border border-neutral-200">
                        <div className="flex items-center">
                          <Paperclip className="h-4 w-4 text-neutral-500 mr-2" />
                          <div>
                            <p className="text-xs font-medium text-neutral-800">
                              {msg.attachment.split("/").pop()}
                            </p>
                          </div>
                          <a 
                            href={msg.attachment} 
                            download
                            className="ml-auto text-primary-600 text-xs"
                            target="_blank" 
                            rel="noopener noreferrer"
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                            </svg>
                          </a>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Chat Input */}
        <div className="px-5 py-4 border-t border-neutral-200">
          <div className="flex space-x-3">
            <Button
              variant="ghost"
              size="icon"
              className="text-neutral-500 hover:text-neutral-700"
              title="Attach file (not implemented in demo)"
            >
              <Paperclip className="h-5 w-5" />
            </Button>
            <Input
              type="text"
              placeholder="Type your message..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={handleKeyDown}
              className="flex-1 border-neutral-300 rounded-full"
            />
            <Button
              className="rounded-full"
              size="icon"
              onClick={handleSendMessage}
              disabled={!message.trim()}
            >
              <Send className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
