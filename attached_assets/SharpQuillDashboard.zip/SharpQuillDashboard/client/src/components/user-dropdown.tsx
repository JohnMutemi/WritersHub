import React from "react";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { 
  User,
  Settings,
  LogOut
} from "lucide-react";

interface UserDropdownProps {
  onClose: () => void;
}

export function UserDropdown({ onClose }: UserDropdownProps) {
  const { logoutMutation } = useAuth();

  const handleLogout = (e: React.MouseEvent) => {
    e.preventDefault();
    logoutMutation.mutate();
    onClose();
  };

  return (
    <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10">
      <div>
        <Link
          href="/profile"
          onClick={onClose}
          className="flex items-center px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-100"
        >
          <User className="h-4 w-4 mr-2" />
          Your Profile
        </Link>
      </div>
      
      <div>
        <Link
          href="/settings"
          onClick={onClose}
          className="flex items-center px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-100"
        >
          <Settings className="h-4 w-4 mr-2" />
          Settings
        </Link>
      </div>
      
      <div className="border-t border-neutral-200 my-1"></div>
      
      <div>
        <Link
          href="#"
          onClick={handleLogout}
          className="flex items-center px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-100"
        >
          <LogOut className="h-4 w-4 mr-2" />
          Sign out
        </Link>
      </div>
    </div>
  );
}
