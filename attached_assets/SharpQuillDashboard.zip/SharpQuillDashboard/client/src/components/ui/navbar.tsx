import React, { useState } from "react";
import { Menu, Bell } from "lucide-react";
import { NotificationsDropdown } from "@/components/notifications-dropdown";
import { UserDropdown } from "@/components/user-dropdown";
import { Button } from "@/components/ui/button";
import { User } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";

interface NavbarProps {
  title: string;
  onToggleSidebar: () => void;
  user: User;
}

export function Navbar({ title, onToggleSidebar, user }: NavbarProps) {
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  const { data: notifications = [] } = useQuery({
    queryKey: ["/api/notifications"],
  });

  const unreadCount = notifications.filter((notification: any) => !notification.read).length;

  return (
    <header className="bg-white border-b border-gray-200 z-30">
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex">
            <Button 
              variant="ghost" 
              onClick={onToggleSidebar} 
              className="md:hidden mr-2"
              size="icon"
            >
              <Menu className="h-5 w-5" />
              <span className="sr-only">Open sidebar</span>
            </Button>
            <h1 className="text-xl font-semibold text-gray-800">{title}</h1>
          </div>

          <div className="flex items-center space-x-4">
            {/* Notifications */}
            <div className="relative">
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => {
                  setIsNotificationsOpen(!isNotificationsOpen);
                  setIsUserMenuOpen(false);
                }}
                className="text-gray-500 hover:text-gray-700"
              >
                <Bell className="h-5 w-5" />
                {unreadCount > 0 && (
                  <span className="absolute top-0 right-0 -mt-1 -mr-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-xs font-bold text-white">
                    {unreadCount > 9 ? '9+' : unreadCount}
                  </span>
                )}
              </Button>
              
              {isNotificationsOpen && (
                <NotificationsDropdown 
                  notifications={notifications} 
                  onClose={() => setIsNotificationsOpen(false)}
                />
              )}
            </div>

            {/* User menu */}
            <div className="relative">
              <Button 
                variant="ghost" 
                onClick={() => {
                  setIsUserMenuOpen(!isUserMenuOpen);
                  setIsNotificationsOpen(false);
                }}
                className="flex items-center text-sm focus:outline-none"
              >
                <div className="flex items-center">
                  <img 
                    src={user.profilePicture || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.fullName)}&background=0D8ABC&color=fff`}
                    alt={user.fullName} 
                    className="h-8 w-8 rounded-full mr-2"
                  />
                  <span className="hidden md:block font-medium text-gray-700">{user.fullName}</span>
                  <svg className="ml-1 h-4 w-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </div>
              </Button>
              
              {isUserMenuOpen && (
                <UserDropdown onClose={() => setIsUserMenuOpen(false)} />
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
