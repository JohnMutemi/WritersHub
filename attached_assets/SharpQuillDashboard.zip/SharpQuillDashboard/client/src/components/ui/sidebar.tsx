import React from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  Home,
  FileText,
  MessageSquare,
  DollarSign,
  User,
  Settings,
  Briefcase,
  Users,
  BarChart2,
  Gavel,
  LogOut,
  X,
  ChartPie,
  UserCog
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  userRole: string;
  userName: string;
  userEmail: string;
  userAvatar: string;
}

export function Sidebar({ isOpen, onClose, userRole, userName, userEmail, userAvatar }: SidebarProps) {
  const [location] = useLocation();
  const { logoutMutation } = useAuth();

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  // Define navigation items based on user role
  const navigationItems = [
    { name: "Dashboard", href: "/dashboard", icon: Home, roles: ["client", "writer", "admin"] },
  ];

  // Writer specific navigation
  if (userRole === "writer") {
    navigationItems.push(
      { name: "Available Jobs", href: "/jobs", icon: Briefcase, roles: ["writer"] },
      { name: "My Orders", href: "/orders", icon: FileText, roles: ["writer"] }
    );
  }

  // Client specific navigation
  if (userRole === "client") {
    navigationItems.push(
      { name: "My Jobs", href: "/jobs", icon: Briefcase, roles: ["client"] },
      { name: "My Orders", href: "/orders", icon: FileText, roles: ["client"] }
    );
  }

  // Admin specific navigation
  if (userRole === "admin") {
    navigationItems.push(
      { name: "Dashboard", href: "/dashboard", icon: BarChart2, roles: ["admin"] },
      { name: "KPI Reports", href: "/admin/kpi-reports", icon: ChartPie, roles: ["admin"] },
      { name: "User Management", href: "/admin/user-management", icon: UserCog, roles: ["admin"] },
      { name: "Writer Management", href: "/admin/writers", icon: Users, roles: ["admin"] },
      { name: "Disputes", href: "/admin/disputes", icon: Gavel, roles: ["admin"] },
      { name: "Transactions", href: "/admin/transactions", icon: DollarSign, roles: ["admin"] }
    );
  }

  // Common navigation items for all roles
  navigationItems.push(
    { name: "Messages", href: "/messages", icon: MessageSquare, roles: ["client", "writer", "admin"] },
    { name: "Activity", href: "/activity", icon: BarChart2, roles: ["client", "writer", "admin"] },
    { name: "Profile", href: "/profile", icon: User, roles: ["client", "writer", "admin"] },
    { name: "Settings", href: "/settings", icon: Settings, roles: ["client", "writer", "admin"] }
  );

  // Filter navigation items based on user role
  const filteredNavItems = navigationItems.filter(item => item.roles.includes(userRole));

  return (
    <>
      {/* Mobile sidebar backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-gray-600 bg-opacity-75 md:hidden"
          onClick={onClose}
        ></div>
      )}

      {/* Sidebar for mobile */}
      <aside
        className={cn(
          "fixed top-0 left-0 z-40 h-screen w-64 bg-neutral-800 text-white transform transition-transform ease-in-out duration-300 md:hidden",
          isOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="flex justify-between items-center px-4 py-3 border-b border-neutral-700">
          <div className="flex items-center space-x-3">
            <img src="https://placehold.co/40x40?text=SQ" alt="SharpQuill Logo" className="w-10 h-10 rounded" />
            <div>
              <h1 className="font-semibold text-lg">SharpQuill</h1>
              <div className="text-xs text-neutral-400 capitalize">{userRole} Dashboard</div>
            </div>
          </div>
          <button onClick={onClose} className="text-neutral-400 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Navigation */}
        <nav className="px-4 py-4">
          <div className="mb-4">
            <p className="text-neutral-400 text-xs uppercase font-semibold mb-2 pl-2">Main Menu</p>
            <ul>
              {filteredNavItems.map((item) => (
                <li key={item.name} className="mb-1">
                  <Link
                    href={item.href}
                    onClick={() => {
                      if (window.innerWidth < 768) {
                        onClose(); // Close mobile sidebar when navigating
                      }
                    }}
                    className={cn(
                      "flex items-center px-2 py-2 text-neutral-300 hover:text-white hover:bg-neutral-700 rounded-md transition-colors duration-150 ease-in-out",
                      location === item.href && "bg-neutral-700 text-white"
                    )}
                  >
                    <item.icon className="h-5 w-5" />
                    <span className="ml-3">{item.name}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </nav>

        {/* User info */}
        <div className="mt-auto px-4 py-3 border-t border-neutral-700">
          <div className="flex items-center">
            <img
              src={userAvatar}
              alt="User"
              className="w-10 h-10 rounded-full"
            />
            <div className="ml-3">
              <p className="text-sm font-medium text-white">{userName}</p>
              <p className="text-xs text-neutral-400">{userEmail}</p>
            </div>
            <button
              onClick={handleLogout}
              className="ml-auto text-neutral-300 hover:text-white"
              aria-label="Logout"
            >
              <LogOut className="h-5 w-5" />
            </button>
          </div>
        </div>
      </aside>

      {/* Sidebar for desktop */}
      <aside className="hidden md:block w-64 bg-neutral-800 text-white h-screen sticky top-0 overflow-y-auto">
        <div className="px-6 py-4 border-b border-neutral-700">
          <div className="flex items-center space-x-3">
            <img src="https://placehold.co/40x40?text=SQ" alt="SharpQuill Logo" className="w-10 h-10 rounded" />
            <div>
              <h1 className="font-semibold text-lg">SharpQuill</h1>
              <div className="text-xs text-neutral-400 capitalize">{userRole} Dashboard</div>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="px-4 py-4">
          <div className="mb-4">
            <p className="text-neutral-400 text-xs uppercase font-semibold mb-2 pl-2">Main Menu</p>
            <ul>
              {filteredNavItems.map((item) => (
                <li key={item.name} className="mb-1">
                  <Link
                    href={item.href}
                    className={cn(
                      "flex items-center px-2 py-2 text-neutral-300 hover:text-white hover:bg-neutral-700 rounded-md transition-colors duration-150 ease-in-out",
                      location === item.href && "bg-neutral-700 text-white"
                    )}
                  >
                    <item.icon className="h-5 w-5" />
                    <span className="ml-3">{item.name}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </nav>

        {/* User info */}
        <div className="mt-auto px-4 py-3 border-t border-neutral-700">
          <div className="flex items-center">
            <img
              src={userAvatar}
              alt="User"
              className="w-10 h-10 rounded-full"
            />
            <div className="ml-3">
              <p className="text-sm font-medium text-white">{userName}</p>
              <p className="text-xs text-neutral-400">{userEmail}</p>
            </div>
            <button
              onClick={handleLogout}
              className="ml-auto text-neutral-300 hover:text-white"
              aria-label="Logout"
            >
              <LogOut className="h-5 w-5" />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}
