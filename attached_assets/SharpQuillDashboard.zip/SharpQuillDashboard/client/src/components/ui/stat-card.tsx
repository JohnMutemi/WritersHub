import React from "react";
import { cn } from "@/lib/utils";

export interface StatCardProps {
  label: string;
  value: string | number;
  icon: React.ReactNode;
  change?: string;
  changeType?: "positive" | "negative" | "neutral";
  className?: string;
  action?: React.ReactNode;
}

export function StatCard({ 
  label, 
  value, 
  icon, 
  change, 
  changeType = "neutral",
  className,
  action
}: StatCardProps) {
  const changeColorClass = 
    changeType === "positive" 
      ? "text-success" 
      : changeType === "negative"
        ? "text-destructive"
        : "text-neutral-500";

  return (
    <div className={cn("bg-white rounded-lg shadow p-5", className)}>
      <div className="flex justify-between">
        <div>
          <p className="text-neutral-500 text-sm">{label}</p>
          <h3 className="text-2xl font-semibold mt-1">{value}</h3>
          {change && (
            <p className={cn("text-xs mt-1 flex items-center", changeColorClass)}>
              {changeType === "positive" && <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M3.293 9.707a1 1 0 010-1.414l6-6a1 1 0 011.414 0l6 6a1 1 0 01-1.414 1.414L11 5.414V17a1 1 0 11-2 0V5.414L4.707 9.707a1 1 0 01-1.414 0z" clipRule="evenodd" />
              </svg>}
              {changeType === "negative" && <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M16.707 10.293a1 1 0 010 1.414l-6 6a1 1 0 01-1.414 0l-6-6a1 1 0 111.414-1.414L9 14.586V3a1 1 0 012 0v11.586l4.293-4.293a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>}
              <span>{change}</span>
            </p>
          )}
          {action && <div className="mt-2">{action}</div>}
        </div>
        <div className="h-12 w-12 bg-primary-100 rounded-full flex items-center justify-center text-primary-600">
          {icon}
        </div>
      </div>
    </div>
  );
}
