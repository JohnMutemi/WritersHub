import React, { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import * as z from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertJobSchema } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// Extend the insert job schema with additional validation
const createJobSchema = insertJobSchema.extend({
  citationStyle: z.string().optional().nullable(),
  attachments: z.array(z.string()).optional().nullable(),
  deadline: z.date().refine(
    (date) => date > new Date(), 
    { message: "Deadline must be in the future" }
  ),
});

type CreateJobValues = z.infer<typeof createJobSchema>;

interface CreateJobModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function CreateJobModal({ isOpen, onClose }: CreateJobModalProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [timeValue, setTimeValue] = useState("12:00");
  
  // Define form with default values
  const form = useForm<CreateJobValues>({
    resolver: zodResolver(createJobSchema),
    defaultValues: {
      title: "",
      type: "Essay",
      description: "",
      subject: "",
      academicLevel: "Undergraduate",
      pages: 1,
      wordCount: 275, // Default 275 words per page
      budget: 20,
      deadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // Default 1 week from now
      citationStyle: "APA",
      attachments: [],
    },
  });

  // Update word count when pages change
  const pages = form.watch("pages");
  const wordsPerPage = 275;
  
  // Watch the deadline field to update the time input
  const deadline = form.watch("deadline");
  
  // Update the time value when deadline changes
  useEffect(() => {
    if (deadline instanceof Date) {
      const hours = deadline.getHours().toString().padStart(2, '0');
      const minutes = deadline.getMinutes().toString().padStart(2, '0');
      setTimeValue(`${hours}:${minutes}`);
    }
  }, [deadline]);
  
  // Trigger word count update whenever pages change
  if (pages && pages * wordsPerPage !== form.getValues("wordCount")) {
    form.setValue("wordCount", pages * wordsPerPage);
  }

  // Create job mutation
  const createJobMutation = useMutation({
    mutationFn: async (data: CreateJobValues) => {
      setIsSubmitting(true);
      try {
        // Ensure the deadline is properly serialized
        const formattedData = {
          ...data,
          deadline: data.deadline instanceof Date ? data.deadline.toISOString() : data.deadline
        };
        console.log("Sending job data to server:", formattedData);
        const res = await apiRequest("POST", "/api/jobs", formattedData);
        return await res.json();
      } catch (error) {
        console.error("API request error:", error);
        throw error;
      }
    },
    onSuccess: () => {
      toast({
        title: "Job created successfully",
        description: "Your job has been posted and is now available for writers to bid on.",
        variant: "default",
      });
      
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ["/api/clients/jobs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] }); 
      
      // Reset form and close modal
      form.reset();
      onClose();
      setIsSubmitting(false);
    },
    onError: (error: Error) => {
      setIsSubmitting(false);
      toast({
        title: "Failed to create job",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = async (data: CreateJobValues) => {
    try {
      // Get the deadline from the form data
      const deadline = data.deadline;
      console.log("Original deadline value:", deadline);
      
      // Ensure deadline is a valid date in the future
      if (!(deadline instanceof Date) || isNaN(deadline.getTime())) {
        toast({
          title: "Invalid deadline",
          description: "Please select a valid deadline date",
          variant: "destructive"
        });
        return;
      }
      
      const now = new Date();
      if (deadline <= now) {
        toast({
          title: "Invalid deadline",
          description: "Deadline must be in the future",
          variant: "destructive"
        });
        return;
      }
      
      // The mutation function will handle the date serialization
      createJobMutation.mutate(data);
    } catch (error) {
      console.error("Error submitting job:", error);
      toast({
        title: "Submission Error",
        description: "There was a problem creating your job. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Post a New Writing Job</DialogTitle>
          <DialogDescription>
            Fill out the details about your writing project. Be as specific as possible to attract the right writers.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Title */}
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., Research Paper on Climate Change" {...field} />
                  </FormControl>
                  <FormDescription>
                    A clear, descriptive title of your writing project
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Type and Subject */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Document Type</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Essay">Essay</SelectItem>
                        <SelectItem value="Research Paper">Research Paper</SelectItem>
                        <SelectItem value="Case Study">Case Study</SelectItem>
                        <SelectItem value="Term Paper">Term Paper</SelectItem>
                        <SelectItem value="Dissertation">Dissertation</SelectItem>
                        <SelectItem value="Thesis">Thesis</SelectItem>
                        <SelectItem value="Article">Article</SelectItem>
                        <SelectItem value="Book Review">Book Review</SelectItem>
                        <SelectItem value="Creative Writing">Creative Writing</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="subject"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Subject</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Environmental Science" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Description */}
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Detailed Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Describe your writing needs in detail. Include specific requirements, sources to be used, approaches to be taken, etc." 
                      {...field} 
                      rows={5}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Academic Level and Citation Style */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="academicLevel"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Academic Level</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select level" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="High School">High School</SelectItem>
                        <SelectItem value="Undergraduate">Undergraduate</SelectItem>
                        <SelectItem value="Masters">Masters</SelectItem>
                        <SelectItem value="PhD">PhD</SelectItem>
                        <SelectItem value="Professional">Professional</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="citationStyle"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Citation Style</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value || undefined}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select style" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="APA">APA</SelectItem>
                        <SelectItem value="MLA">MLA</SelectItem>
                        <SelectItem value="Chicago">Chicago</SelectItem>
                        <SelectItem value="Harvard">Harvard</SelectItem>
                        <SelectItem value="IEEE">IEEE</SelectItem>
                        <SelectItem value="None">None</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Length and Budget */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <FormField
                control={form.control}
                name="pages"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Pages</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min={1} 
                        {...field} 
                        onChange={(e) => {
                          const value = parseInt(e.target.value);
                          field.onChange(value);
                          form.setValue("wordCount", value * wordsPerPage);
                        }}
                      />
                    </FormControl>
                    <FormDescription>
                      {field.value} page(s) = {field.value * wordsPerPage} words
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="wordCount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Word Count</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min={275} 
                        step={275} 
                        {...field} 
                        onChange={(e) => {
                          const value = parseInt(e.target.value);
                          field.onChange(value);
                          form.setValue("pages", Math.ceil(value / wordsPerPage));
                        }}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="budget"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Budget (USD)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min={5} 
                        step={5} 
                        {...field} 
                        onChange={(e) => field.onChange(parseFloat(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Deadline */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="deadline"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Deadline Date</FormLabel>
                    <FormControl>
                      <Input 
                        type="date" 
                        {...field} 
                        value={field.value instanceof Date ? field.value.toISOString().split('T')[0] : field.value}
                        min={new Date().toISOString().split('T')[0]}
                        onChange={(e) => {
                          // Create a new date preserving the existing time if possible
                          const currentDate = field.value instanceof Date ? field.value : new Date();
                          const hours = currentDate.getHours();
                          const minutes = currentDate.getMinutes();
                          
                          // Create a new date with the selected date but preserve time
                          const newDate = new Date(e.target.value);
                          newDate.setHours(hours, minutes);
                          
                          // Update field with the new date
                          field.onChange(newDate);
                        }}
                      />
                    </FormControl>
                    <FormDescription>
                      Select the deadline date
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="space-y-2">
                <FormItem>
                  <FormLabel>Time</FormLabel>
                  <FormControl>
                    <Input 
                      type="time" 
                      value={timeValue}
                      onChange={(e) => {
                        // Update the state
                        setTimeValue(e.target.value);
                        
                        // Get the current deadline date
                        const deadlineDate = form.getValues("deadline");
                        if (!(deadlineDate instanceof Date)) return;
                        
                        // Parse the time string "HH:MM"
                        const [hours, minutes] = e.target.value.split(':').map(Number);
                        
                        // Update the time on the existing date
                        const newDeadline = new Date(deadlineDate);
                        newDeadline.setHours(hours, minutes);
                        
                        // Update the deadline field with the new datetime
                        form.setValue("deadline", newDeadline);
                      }}
                    />
                  </FormControl>
                  <FormDescription>
                    Specify the exact time (24h format)
                  </FormDescription>
                </FormItem>
              </div>
            </div>

            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={onClose}
                disabled={isSubmitting}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={isSubmitting}
              >
                {isSubmitting ? "Creating..." : "Create Job"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}