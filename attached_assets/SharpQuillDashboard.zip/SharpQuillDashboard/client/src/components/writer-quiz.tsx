import { useState, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useToast } from "@/hooks/use-toast";
import { Loader2, CheckCircle, XCircle } from "lucide-react";

// Quiz questions structured with correct answers
const quizQuestions = [
  {
    id: 1,
    question: "Which citation style is commonly used in humanities disciplines?",
    options: [
      "APA (American Psychological Association)",
      "MLA (Modern Language Association)",
      "Chicago/Turabian",
      "IEEE (Institute of Electrical and Electronics Engineers)"
    ],
    correctAnswer: 1 // Index of the correct answer (MLA)
  },
  {
    id: 2,
    question: "What is the primary purpose of a thesis statement in an academic paper?",
    options: [
      "To summarize the entire paper",
      "To provide background information on the topic",
      "To present the author's main argument or claim",
      "To list the sources used in the research"
    ],
    correctAnswer: 2 // To present the author's main argument or claim
  },
  {
    id: 3,
    question: "What is plagiarism in academic writing?",
    options: [
      "Using direct quotes with proper citation",
      "Paraphrasing ideas with attribution",
      "Using someone else's work or ideas without proper attribution",
      "Collaborating with peers on a group project"
    ],
    correctAnswer: 2 // Using someone else's work or ideas without proper attribution
  },
  {
    id: 4,
    question: "Which of the following is NOT a characteristic of scholarly sources?",
    options: [
      "Peer-reviewed",
      "Written for the general public rather than specialists",
      "Published in academic journals",
      "Includes citations and a bibliography"
    ],
    correctAnswer: 1 // Written for the general public rather than specialists
  },
  {
    id: 5,
    question: "What is the purpose of an annotated bibliography?",
    options: [
      "To list all sources alphabetically without commentary",
      "To summarize and evaluate the sources you have used",
      "To outline the structure of your paper",
      "To present your research findings"
    ],
    correctAnswer: 1 // To summarize and evaluate the sources you have used
  },
  {
    id: 6,
    question: "In academic writing, what is the difference between primary and secondary sources?",
    options: [
      "Primary sources are more reliable than secondary sources",
      "Primary sources are original materials, while secondary sources analyze or interpret primary sources",
      "Primary sources are published in journals, while secondary sources are published in books",
      "Primary sources are recent, while secondary sources are older"
    ],
    correctAnswer: 1 // Primary sources are original materials, while secondary sources analyze or interpret primary sources
  },
  {
    id: 7,
    question: "What is the purpose of a literature review in research?",
    options: [
      "To demonstrate your reading comprehension skills",
      "To list all available sources on your topic",
      "To provide context for your research and show how it fits within existing knowledge",
      "To critique other researchers' methodologies"
    ],
    correctAnswer: 2 // To provide context for your research and show how it fits within existing knowledge
  },
  {
    id: 8,
    question: "Which of the following is an example of a credible academic source?",
    options: [
      "A personal blog post",
      "A Wikipedia article",
      "A peer-reviewed journal article",
      "A popular magazine article"
    ],
    correctAnswer: 2 // A peer-reviewed journal article
  },
  {
    id: 9,
    question: "What is the purpose of the methodology section in a research paper?",
    options: [
      "To list the references used in the paper",
      "To summarize the main findings of the research",
      "To explain how the research was conducted",
      "To discuss the implications of the research"
    ],
    correctAnswer: 2 // To explain how the research was conducted
  },
  {
    id: 10,
    question: "Which of the following is NOT typically included in an abstract?",
    options: [
      "The research problem or question",
      "The methodology used",
      "A brief summary of the findings",
      "Detailed literature review"
    ],
    correctAnswer: 3 // Detailed literature review
  }
];

interface WriterQuizProps {
  writerId: number;
  onComplete?: (score: number, passed: boolean) => void;
}

export function WriterQuiz({ writerId, onComplete }: WriterQuizProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>(Array(quizQuestions.length).fill(-1));
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [score, setScore] = useState(0);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const submitQuizMutation = useMutation({
    mutationFn: async (data: { writerId: number, score: number, passed: boolean }) => {
      const response = await fetch(`/api/writers/${writerId}/quiz`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          answers: selectedAnswers,
          score: data.score,
          passed: data.passed
        }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to submit quiz results');
      }
      
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      queryClient.invalidateQueries({ queryKey: ['/api/users/pending-writers'] });
      queryClient.invalidateQueries({ queryKey: [`/api/writers/${writerId}/quiz`] });
      
      toast({
        title: "Quiz submitted successfully",
        description: `Your quiz has been submitted with a score of ${score}%`,
        variant: "default",
      });
      
      if (onComplete) {
        onComplete(score, score >= 70);
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to submit quiz",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const handleAnswerSelection = (questionIndex: number, answerIndex: number) => {
    const newAnswers = [...selectedAnswers];
    newAnswers[questionIndex] = answerIndex;
    setSelectedAnswers(newAnswers);
  };

  const handleNext = () => {
    if (currentQuestion < quizQuestions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(prev => prev - 1);
    }
  };

  const handleSubmit = () => {
    setIsSubmitting(true);
    
    // Calculate score
    let correctCount = 0;
    selectedAnswers.forEach((selectedAnswer, index) => {
      if (selectedAnswer === quizQuestions[index].correctAnswer) {
        correctCount++;
      }
    });
    
    const calculatedScore = Math.round((correctCount / quizQuestions.length) * 100);
    const passed = calculatedScore >= 70; // Pass threshold is 70%
    
    setScore(calculatedScore);
    setQuizCompleted(true);
    
    // Submit the results
    submitQuizMutation.mutate({
      writerId,
      score: calculatedScore,
      passed
    });
  };

  const allQuestionsAnswered = selectedAnswers.every(answer => answer !== -1);

  if (quizCompleted) {
    return (
      <Card className="w-full max-w-2xl mx-auto">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl">Quiz Results</CardTitle>
          <CardDescription>
            You scored {score}% ({score >= 70 ? 'Passed' : 'Failed'})
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex flex-col items-center justify-center py-8">
            {score >= 70 ? (
              <CheckCircle className="h-16 w-16 text-green-500 mb-4" />
            ) : (
              <XCircle className="h-16 w-16 text-red-500 mb-4" />
            )}
            <p className="text-2xl font-bold">{score}%</p>
            <p className="text-neutral-600 mt-2">
              {score >= 70 
                ? "Congratulations! You've passed the writer's assessment."
                : "Unfortunately, you didn't pass the assessment. You need 70% to pass."}
            </p>
          </div>
          
          <div className="border-t border-b border-neutral-200 py-4">
            <h3 className="font-medium mb-2">Assessment Overview:</h3>
            <ul className="space-y-2">
              <li className="flex justify-between">
                <span>Total Questions:</span>
                <span>{quizQuestions.length}</span>
              </li>
              <li className="flex justify-between">
                <span>Correct Answers:</span>
                <span>{Math.round((score / 100) * quizQuestions.length)}</span>
              </li>
              <li className="flex justify-between">
                <span>Incorrect Answers:</span>
                <span>{quizQuestions.length - Math.round((score / 100) * quizQuestions.length)}</span>
              </li>
              <li className="flex justify-between font-medium">
                <span>Passing Score:</span>
                <span>70%</span>
              </li>
            </ul>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Writer Competency Assessment</CardTitle>
        <CardDescription>
          Question {currentQuestion + 1} of {quizQuestions.length}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-medium mb-2">{quizQuestions[currentQuestion].question}</h3>
            <RadioGroup 
              value={selectedAnswers[currentQuestion].toString()} 
              onValueChange={(value) => handleAnswerSelection(currentQuestion, parseInt(value))}
            >
              {quizQuestions[currentQuestion].options.map((option, index) => (
                <div key={index} className="flex items-center space-x-2 py-2">
                  <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                  <Label htmlFor={`option-${index}`} className="cursor-pointer">{option}</Label>
                </div>
              ))}
            </RadioGroup>
          </div>

          <div className="w-full bg-neutral-200 rounded-full h-2.5">
            <div 
              className="bg-primary h-2.5 rounded-full" 
              style={{ width: `${((currentQuestion + 1) / quizQuestions.length) * 100}%` }}
            ></div>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button 
          variant="outline" 
          onClick={handlePrevious}
          disabled={currentQuestion === 0}
        >
          Previous
        </Button>
        
        <div className="flex space-x-2">
          {currentQuestion === quizQuestions.length - 1 ? (
            <Button 
              onClick={handleSubmit}
              disabled={!allQuestionsAnswered || isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Submitting...
                </>
              ) : (
                'Submit Quiz'
              )}
            </Button>
          ) : (
            <Button 
              onClick={handleNext}
              disabled={selectedAnswers[currentQuestion] === -1}
            >
              Next
            </Button>
          )}
        </div>
      </CardFooter>
    </Card>
  );
}