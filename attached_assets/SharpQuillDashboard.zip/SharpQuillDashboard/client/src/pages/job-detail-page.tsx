import { useState } from "react";
import { useRoute } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { DashboardLayout } from "@/components/ui/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { InsertBid } from "@shared/schema";
import { Calendar, Clock, FileText, Briefcase, DollarSign, BookOpen, Hash, Award, FileDown } from "lucide-react";

interface BidDialogProps {
  jobId: number;
  jobTitle: string;
  jobBudget: number;
  jobDeadline: string;
  isOpen: boolean;
  onClose: () => void;
}

function BidDialog({ jobId, jobTitle, jobBudget, jobDeadline, isOpen, onClose }: BidDialogProps) {
  const { toast } = useToast();
  const [bidAmount, setBidAmount] = useState<number>(jobBudget);
  const [deliveryDate, setDeliveryDate] = useState<string>(
    new Date(jobDeadline).toISOString().split("T")[0]
  );
  const [message, setMessage] = useState<string>("");

  const createBidMutation = useMutation({
    mutationFn: async (bidData: Partial<InsertBid>) => {
      const res = await apiRequest("POST", `/api/jobs/${jobId}/bids`, bidData);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Bid submitted successfully",
        description: "Your bid has been sent to the client for review",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/jobs/${jobId}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/jobs/${jobId}/bids`] });
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to submit bid",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Send the delivery date as a string, the schema will handle conversion
    createBidMutation.mutate({
      amount: bidAmount,
      deliveryDate: deliveryDate,
      message,
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Place a Bid</DialogTitle>
          <DialogDescription>
            You're bidding on: <span className="font-semibold">{jobTitle}</span>
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="amount">Your Bid (USD)</Label>
              <Input
                id="amount"
                type="number"
                step="0.01"
                min="1"
                max={jobBudget * 1.5}
                value={bidAmount}
                onChange={(e) => setBidAmount(parseFloat(e.target.value))}
                required
              />
              <p className="text-xs text-muted-foreground">Client's budget: ${jobBudget}</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="deliveryDate">Delivery Date</Label>
              <Input
                id="deliveryDate"
                type="date"
                value={deliveryDate}
                onChange={(e) => setDeliveryDate(e.target.value)}
                min={new Date().toISOString().split("T")[0]}
                max={new Date(jobDeadline).toISOString().split("T")[0]}
                required
              />
              <p className="text-xs text-muted-foreground">
                Client's deadline: {new Date(jobDeadline).toLocaleDateString()}
              </p>
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="message">Cover Message</Label>
            <Textarea
              id="message"
              placeholder="Explain why you're the best writer for this job..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={4}
              required
            />
          </div>
          <DialogFooter>
            <Button variant="outline" type="button" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={createBidMutation.isPending}>
              {createBidMutation.isPending ? "Submitting..." : "Submit Bid"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function JobDetailPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, params] = useRoute<{ id: string }>("/jobs/:id");
  const jobId = parseInt(params?.id || "0");
  const [isBidDialogOpen, setIsBidDialogOpen] = useState<boolean>(false);

  // Fetch job details
  const { data: job, isLoading: isLoadingJob } = useQuery({
    queryKey: [`/api/jobs/${jobId}`],
    enabled: jobId > 0,
  });

  // Fetch bids for this job if user is client who posted it or admin
  const { data: bids = [], isLoading: isLoadingBids } = useQuery({
    queryKey: [`/api/jobs/${jobId}/bids`],
    enabled: !!job && (user?.role === "admin" || (user?.role === "client" && user.id === job.clientId)),
  });

  // Fetch my bid if user is a writer
  const { data: myBids = [], isLoading: isLoadingMyBid } = useQuery({
    queryKey: ["/api/writers/bids"],
    enabled: !!user && user.role === "writer",
  });

  // Get my bid for this job if any
  const myBid = myBids.find((bid: any) => bid.jobId === jobId);

  // Accept bid mutation for clients
  const acceptBidMutation = useMutation({
    mutationFn: async (bidId: number) => {
      const res = await apiRequest("POST", `/api/bids/${bidId}/accept`, {});
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Bid accepted",
        description: "The writer has been notified and an order has been created",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/jobs/${jobId}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/jobs/${jobId}/bids`] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to accept bid",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Reject bid mutation for clients
  const rejectBidMutation = useMutation({
    mutationFn: async (bidId: number) => {
      const res = await apiRequest("POST", `/api/bids/${bidId}/reject`, {});
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Bid rejected",
        description: "The writer has been notified",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/jobs/${jobId}/bids`] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to reject bid",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  if (isLoadingJob) {
    return (
      <DashboardLayout title="Job Details">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </DashboardLayout>
    );
  }

  if (!job) {
    return (
      <DashboardLayout title="Job Details">
        <div className="flex flex-col items-center justify-center h-64 text-neutral-500">
          <p className="mb-2">Job not found</p>
          <Button variant="outline" onClick={() => window.history.back()}>
            Go Back
          </Button>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout title="Job Details">
      <div className="space-y-6">
        {/* Job Details */}
        <Card>
          <CardHeader className="px-6 py-5 border-b border-neutral-200">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-2">
              <div>
                <Badge className="mb-2">{job.type}</Badge>
                <CardTitle className="text-2xl font-bold">{job.title}</CardTitle>
              </div>
              {user?.role === "writer" && !myBid && (
                <Button onClick={() => setIsBidDialogOpen(true)}>Place Bid</Button>
              )}
            </div>
            <CardDescription className="flex flex-wrap gap-3 text-sm text-neutral-500">
              <div className="flex items-center">
                <Calendar className="h-4 w-4 mr-1" />
                <span>Posted on {new Date(job.createdAt).toLocaleDateString()}</span>
              </div>
              <div className="flex items-center">
                <Clock className="h-4 w-4 mr-1" />
                <span>Deadline: {new Date(job.deadline).toLocaleDateString()}</span>
              </div>
              <div className="flex items-center">
                <DollarSign className="h-4 w-4 mr-1" />
                <span>Budget: ${job.budget}</span>
              </div>
              <div className="flex items-center">
                <BookOpen className="h-4 w-4 mr-1" />
                <span>Subject: {job.subject}</span>
              </div>
            </CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <div className="border rounded-md p-4 bg-neutral-50">
                <h3 className="font-medium text-neutral-700 mb-2 flex items-center">
                  <Hash className="h-4 w-4 mr-1" /> Word Count
                </h3>
                <p className="text-xl font-semibold">{job.wordCount} words</p>
                <p className="text-sm text-neutral-500">{job.pages} pages</p>
              </div>
              <div className="border rounded-md p-4 bg-neutral-50">
                <h3 className="font-medium text-neutral-700 mb-2 flex items-center">
                  <Award className="h-4 w-4 mr-1" /> Academic Level
                </h3>
                <p className="text-xl font-semibold">{job.academicLevel}</p>
                <p className="text-sm text-neutral-500">Citation: {job.citationStyle || "Not specified"}</p>
              </div>
              <div className="border rounded-md p-4 bg-neutral-50">
                <h3 className="font-medium text-neutral-700 mb-2 flex items-center">
                  <FileText className="h-4 w-4 mr-1" /> Status
                </h3>
                <p className="text-xl font-semibold capitalize">{job.status}</p>
                <p className="text-sm text-neutral-500">Bids: {bids.length || "Loading..."}</p>
              </div>
            </div>

            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-3">Description</h3>
              <p className="text-neutral-700 whitespace-pre-line">
                {job.description}
              </p>
            </div>

            {job.attachments && job.attachments.length > 0 && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-3">Attachments</h3>
                <div className="space-y-2">
                  {job.attachments.map((attachment: string, index: number) => (
                    <div key={index} className="flex items-center p-3 border rounded-md bg-neutral-50">
                      <FileDown className="h-5 w-5 mr-2 text-neutral-500" />
                      <a 
                        href={attachment} 
                        className="text-primary-600 hover:text-primary-700 font-medium"
                        target="_blank" 
                        rel="noopener noreferrer"
                      >
                        {attachment.split('/').pop()}
                      </a>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* My Bid Section (for writer) */}
            {user?.role === "writer" && myBid && (
              <div className="border rounded-md p-4 mt-6">
                <h3 className="text-lg font-semibold mb-3">Your Bid</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div>
                    <p className="text-sm text-neutral-500">Your Price</p>
                    <p className="text-xl font-bold">${myBid.amount}</p>
                  </div>
                  <div>
                    <p className="text-sm text-neutral-500">Delivery Date</p>
                    <p className="text-xl font-semibold">{new Date(myBid.deliveryDate).toLocaleDateString()}</p>
                  </div>
                  <div>
                    <p className="text-sm text-neutral-500">Status</p>
                    <Badge className={
                      myBid.status === "accepted" ? "bg-green-100 text-green-800 border-green-200" :
                      myBid.status === "rejected" ? "bg-red-100 text-red-800 border-red-200" :
                      "bg-yellow-100 text-yellow-800 border-yellow-200"
                    }>
                      {myBid.status.charAt(0).toUpperCase() + myBid.status.slice(1)}
                    </Badge>
                  </div>
                  <div>
                    <p className="text-sm text-neutral-500">Submitted</p>
                    <p className="text-sm font-semibold">{new Date(myBid.createdAt).toLocaleDateString()}</p>
                  </div>
                </div>
                {myBid.message && (
                  <div className="mt-4">
                    <p className="text-sm text-neutral-500">Your Message</p>
                    <p className="text-neutral-700 mt-1">{myBid.message}</p>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Bids List (for clients and admins) */}
        {(user?.role === "client" || user?.role === "admin") && (
          <Card>
            <CardHeader className="px-6 py-4 border-b border-neutral-200">
              <CardTitle className="text-xl font-semibold">Bids</CardTitle>
              <CardDescription>Writers who have bid on this job</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              {isLoadingBids ? (
                <div className="flex justify-center items-center h-48">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                </div>
              ) : bids.length === 0 ? (
                <div className="flex items-center justify-center h-48 text-neutral-500">
                  <p>No bids received yet</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full divide-y divide-neutral-200">
                    <thead className="bg-neutral-50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Writer</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Bid Amount</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Delivery Date</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Status</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-neutral-200">
                      {bids.map((bid: any) => (
                        <tr key={bid.id} className="hover:bg-neutral-50">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <div className="h-10 w-10 rounded-full bg-neutral-200 flex items-center justify-center text-neutral-600 font-semibold">
                                {bid.writer?.fullName?.charAt(0) || "W"}
                              </div>
                              <div className="ml-3">
                                <p className="text-sm font-medium text-neutral-800">{bid.writer?.fullName || "Writer"}</p>
                                <p className="text-xs text-neutral-500">Rating: {bid.writer?.rating || "N/A"}/5</p>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-neutral-800">
                            ${bid.amount}
                            <p className="text-xs text-neutral-500">
                              {bid.amount < job.budget ? 
                                `$${(job.budget - bid.amount).toFixed(2)} below budget` : 
                                bid.amount > job.budget ? 
                                `$${(bid.amount - job.budget).toFixed(2)} above budget` : 
                                "Matches budget"}
                            </p>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                            {new Date(bid.deliveryDate).toLocaleDateString()}
                            <p className="text-xs text-neutral-500">
                              {new Date(bid.deliveryDate) < new Date(job.deadline) ? 
                                `${Math.ceil((new Date(job.deadline).getTime() - new Date(bid.deliveryDate).getTime()) / (1000 * 60 * 60 * 24))} days early` : 
                                "On deadline"}
                            </p>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <Badge className={
                              bid.status === "accepted" ? "bg-green-100 text-green-800 border-green-200" :
                              bid.status === "rejected" ? "bg-red-100 text-red-800 border-red-200" :
                              "bg-yellow-100 text-yellow-800 border-yellow-200"
                            }>
                              {bid.status.charAt(0).toUpperCase() + bid.status.slice(1)}
                            </Badge>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm">
                            {user?.role === "client" && user.id === job.clientId && bid.status === "pending" && (
                              <div className="flex space-x-2">
                                <Button 
                                  size="sm" 
                                  onClick={() => acceptBidMutation.mutate(bid.id)}
                                  disabled={acceptBidMutation.isPending}
                                >
                                  Accept
                                </Button>
                                <Button 
                                  size="sm" 
                                  variant="outline" 
                                  onClick={() => rejectBidMutation.mutate(bid.id)}
                                  disabled={rejectBidMutation.isPending}
                                >
                                  Reject
                                </Button>
                              </div>
                            )}
                            {(bid.status !== "pending" || (user?.role === "client" && user.id !== job.clientId) || user?.role === "admin") && (
                              <Button size="sm" variant="outline">
                                View Details
                              </Button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Bid Dialog */}
        <BidDialog
          jobId={jobId}
          jobTitle={job.title}
          jobBudget={job.budget}
          jobDeadline={job.deadline}
          isOpen={isBidDialogOpen}
          onClose={() => setIsBidDialogOpen(false)}
        />
      </div>
    </DashboardLayout>
  );
}