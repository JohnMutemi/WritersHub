import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { DashboardLayout } from "@/components/ui/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/use-auth";

export default function OrdersPage() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState<string>("");

  // Fetch orders
  const { data: orders = [], isLoading: isLoadingOrders } = useQuery({
    queryKey: ["/api/orders"],
    enabled: !!user,
  });

  // Filter orders based on search query
  const filteredOrders = orders.filter((order: any) => {
    if (!searchQuery) return true;
    
    // Search in job title if it exists
    const jobTitle = order.job?.title || "";
    return jobTitle.toLowerCase().includes(searchQuery.toLowerCase());
  });

  // Group orders by status
  const inProgressOrders = filteredOrders.filter((order: any) => order.status === "in_progress");
  const completedOrders = filteredOrders.filter((order: any) => order.status === "completed");
  const cancelledOrders = filteredOrders.filter((order: any) => 
    order.status === "cancelled" || order.status === "disputed"
  );

  // Function to format status for display
  const formatStatus = (status: string) => {
    return status.replace('_', ' ').split(' ').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  };

  return (
    <DashboardLayout title="My Orders">
      <div className="space-y-6">
        {/* Search and Filter */}
        <div className="flex items-center space-x-2 mb-6">
          <Input
            placeholder="Search orders..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="max-w-sm"
          />
          <Button variant="outline" onClick={() => setSearchQuery("")} disabled={!searchQuery}>
            Clear
          </Button>
        </div>

        {/* Orders Tabs */}
        <Tabs defaultValue="in-progress" className="space-y-4">
          <TabsList>
            <TabsTrigger value="in-progress">In Progress ({inProgressOrders.length})</TabsTrigger>
            <TabsTrigger value="completed">Completed ({completedOrders.length})</TabsTrigger>
            <TabsTrigger value="cancelled">Cancelled/Disputed ({cancelledOrders.length})</TabsTrigger>
          </TabsList>

          {/* In Progress Tab */}
          <TabsContent value="in-progress">
            <Card>
              <CardHeader className="px-6 py-4 border-b border-neutral-200">
                <CardTitle className="text-xl font-semibold">In Progress Orders</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                {isLoadingOrders ? (
                  <div className="flex justify-center items-center h-64">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                  </div>
                ) : inProgressOrders.length === 0 ? (
                  <div className="flex items-center justify-center h-64 text-neutral-500">
                    <p>No in-progress orders found</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full divide-y divide-neutral-200">
                      <thead className="bg-neutral-50">
                        <tr>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Order</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                            {user?.role === "writer" ? "Client" : "Writer"}
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Payment</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Due Date</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Status</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-neutral-200">
                        {inProgressOrders.map((order: any) => {
                          // Extract job details or use placeholders
                          const job = order.job || {};
                          const jobTitle = job.title || `Order #${order.id}`;
                          
                          return (
                            <tr key={order.id} className="hover:bg-neutral-50">
                              <td className="px-6 py-4 whitespace-nowrap">
                                <Link href={`/orders/${order.id}`} className="text-primary-600 hover:text-primary-700 font-medium">
                                  {jobTitle}
                                </Link>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                                {user?.role === "writer" ? order.client?.fullName || "Client" : order.writer?.fullName || "Writer"}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                                <Badge className={
                                  order.paymentStatus === "paid" ? "bg-green-100 text-green-800 border-green-200" :
                                  "bg-yellow-100 text-yellow-800 border-yellow-200"
                                }>
                                  {order.paymentStatus || "Pending"}
                                </Badge>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                                {order.dueDate ? new Date(order.dueDate).toLocaleDateString() : "Not set"}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                                  {formatStatus(order.status)}
                                </Badge>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <Link href={`/orders/${order.id}`}>
                                  <Button size="sm">View Order</Button>
                                </Link>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Completed Tab */}
          <TabsContent value="completed">
            <Card>
              <CardHeader className="px-6 py-4 border-b border-neutral-200">
                <CardTitle className="text-xl font-semibold">Completed Orders</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                {isLoadingOrders ? (
                  <div className="flex justify-center items-center h-64">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                  </div>
                ) : completedOrders.length === 0 ? (
                  <div className="flex items-center justify-center h-64 text-neutral-500">
                    <p>No completed orders found</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full divide-y divide-neutral-200">
                      <thead className="bg-neutral-50">
                        <tr>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Order</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                            {user?.role === "writer" ? "Client" : "Writer"}
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Payment</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Completed On</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Rating</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-neutral-200">
                        {completedOrders.map((order: any) => {
                          // Extract job details or use placeholders
                          const job = order.job || {};
                          const jobTitle = job.title || `Order #${order.id}`;
                          
                          return (
                            <tr key={order.id} className="hover:bg-neutral-50">
                              <td className="px-6 py-4 whitespace-nowrap">
                                <Link href={`/orders/${order.id}`} className="text-primary-600 hover:text-primary-700 font-medium">
                                  {jobTitle}
                                </Link>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                                {user?.role === "writer" ? order.client?.fullName || "Client" : order.writer?.fullName || "Writer"}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                                <Badge className="bg-green-100 text-green-800 border-green-200">
                                  {order.paymentStatus || "Paid"}
                                </Badge>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                                {order.completedAt ? new Date(order.completedAt).toLocaleDateString() : "Not recorded"}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                                {order.writerRating ? `${order.writerRating}/5` : "Not rated"}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <Link href={`/orders/${order.id}`}>
                                  <Button size="sm" variant="outline">View Order</Button>
                                </Link>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Cancelled Tab */}
          <TabsContent value="cancelled">
            <Card>
              <CardHeader className="px-6 py-4 border-b border-neutral-200">
                <CardTitle className="text-xl font-semibold">Cancelled & Disputed Orders</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                {isLoadingOrders ? (
                  <div className="flex justify-center items-center h-64">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                  </div>
                ) : cancelledOrders.length === 0 ? (
                  <div className="flex items-center justify-center h-64 text-neutral-500">
                    <p>No cancelled or disputed orders found</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full divide-y divide-neutral-200">
                      <thead className="bg-neutral-50">
                        <tr>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Order</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                            {user?.role === "writer" ? "Client" : "Writer"}
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Payment</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Date</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Status</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-neutral-200">
                        {cancelledOrders.map((order: any) => {
                          // Extract job details or use placeholders
                          const job = order.job || {};
                          const jobTitle = job.title || `Order #${order.id}`;
                          
                          return (
                            <tr key={order.id} className="hover:bg-neutral-50">
                              <td className="px-6 py-4 whitespace-nowrap">
                                <Link href={`/orders/${order.id}`} className="text-primary-600 hover:text-primary-700 font-medium">
                                  {jobTitle}
                                </Link>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                                {user?.role === "writer" ? order.client?.fullName || "Client" : order.writer?.fullName || "Writer"}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                                <Badge className={
                                  order.paymentStatus === "refunded" ? "bg-orange-100 text-orange-800 border-orange-200" :
                                  order.paymentStatus === "paid" ? "bg-green-100 text-green-800 border-green-200" :
                                  "bg-red-100 text-red-800 border-red-200"
                                }>
                                  {order.paymentStatus || "Cancelled"}
                                </Badge>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                                {order.updatedAt ? new Date(order.updatedAt).toLocaleDateString() : "Not recorded"}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <Badge variant="outline" className={
                                  order.status === "disputed" ? "bg-red-50 text-red-700 border-red-200" : 
                                  "bg-neutral-50 text-neutral-700 border-neutral-200"
                                }>
                                  {formatStatus(order.status)}
                                </Badge>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <Link href={`/orders/${order.id}`}>
                                  <Button size="sm" variant="outline">View Order</Button>
                                </Link>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}