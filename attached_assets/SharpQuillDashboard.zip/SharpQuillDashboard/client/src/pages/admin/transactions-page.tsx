import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { DashboardLayout } from "@/components/ui/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  ArrowUpRight, 
  ArrowDownRight, 
  CreditCard, 
  DollarSign, 
  Calendar, 
  Download 
} from "lucide-react";

export default function TransactionsPage() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [filterType, setFilterType] = useState<string>("all");
  const [filterUser, setFilterUser] = useState<string>("all");
  const [selectedTransaction, setSelectedTransaction] = useState<any>(null);
  const [isTransactionDetailsOpen, setIsTransactionDetailsOpen] = useState<boolean>(false);
  const [isProcessWithdrawalOpen, setIsProcessWithdrawalOpen] = useState<boolean>(false);
  
  // Fetch all transactions
  const { data: transactions = [], isLoading: isLoadingTransactions } = useQuery({
    queryKey: ["/api/admin/transactions"],
  });

  // Fetch pending withdrawals
  const { data: pendingWithdrawals = [], isLoading: isLoadingWithdrawals } = useQuery({
    queryKey: ["/api/admin/transactions/withdrawals/pending"],
  });

  // Process withdrawal mutation
  const processWithdrawalMutation = useMutation({
    mutationFn: async ({ transactionId, status }: { transactionId: number, status: string }) => {
      const res = await apiRequest("POST", `/api/admin/transactions/${transactionId}/process`, { status });
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Withdrawal processed",
        description: "The withdrawal request has been processed",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/transactions/withdrawals/pending"] });
      setIsProcessWithdrawalOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to process withdrawal",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Filter transactions based on search and filters
  const filteredTransactions = transactions.filter((transaction: any) => {
    // Filter by search query
    const matchesSearch = searchQuery
      ? transaction.id.toString().includes(searchQuery) ||
        transaction.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        transaction.userId.toString().includes(searchQuery) ||
        transaction.user?.fullName?.toLowerCase().includes(searchQuery.toLowerCase())
      : true;

    // Filter by transaction type
    const matchesType = filterType === "all" 
      ? true 
      : transaction.type === filterType;

    // Filter by user type
    const matchesUser = filterUser === "all"
      ? true
      : transaction.user?.role === filterUser;

    return matchesSearch && matchesType && matchesUser;
  });

  // Group transactions by type for stats
  const deposits = transactions.filter((t: any) => t.type === "deposit");
  const withdrawals = transactions.filter((t: any) => t.type === "withdrawal");
  const payments = transactions.filter((t: any) => t.type === "payment");
  
  // Calculate total amounts
  const totalDeposits = deposits.reduce((sum: number, t: any) => sum + t.amount, 0);
  const totalWithdrawals = withdrawals.reduce((sum: number, t: any) => sum + t.amount, 0);
  const totalPayments = payments.reduce((sum: number, t: any) => sum + t.amount, 0);
  const platformRevenue = totalDeposits - totalWithdrawals - totalPayments;

  const openTransactionDetails = (transaction: any) => {
    setSelectedTransaction(transaction);
    setIsTransactionDetailsOpen(true);
  };

  const openProcessWithdrawal = (transaction: any) => {
    setSelectedTransaction(transaction);
    setIsProcessWithdrawalOpen(true);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  return (
    <DashboardLayout title="Transactions">
      <div className="space-y-6">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-medium text-neutral-500">Client Deposits</h3>
                <DollarSign className="h-4 w-4 text-green-500" />
              </div>
              <div className="text-2xl font-bold">${totalDeposits.toFixed(2)}</div>
              <div className="flex items-center mt-1 text-xs text-green-600">
                <ArrowUpRight className="h-3 w-3 mr-1" />
                <span>+{deposits.length} transactions</span>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-medium text-neutral-500">Writer Withdrawals</h3>
                <DollarSign className="h-4 w-4 text-orange-500" />
              </div>
              <div className="text-2xl font-bold">${totalWithdrawals.toFixed(2)}</div>
              <div className="flex items-center mt-1 text-xs text-orange-600">
                <ArrowDownRight className="h-3 w-3 mr-1" />
                <span>{withdrawals.length} transactions</span>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-medium text-neutral-500">Writer Payments</h3>
                <CreditCard className="h-4 w-4 text-blue-500" />
              </div>
              <div className="text-2xl font-bold">${totalPayments.toFixed(2)}</div>
              <div className="flex items-center mt-1 text-xs text-blue-600">
                <span>{payments.length} transactions</span>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-medium text-neutral-500">Platform Revenue</h3>
                <DollarSign className="h-4 w-4 text-primary-500" />
              </div>
              <div className="text-2xl font-bold">${platformRevenue.toFixed(2)}</div>
              <div className="flex items-center mt-1 text-xs text-primary-600">
                <Calendar className="h-3 w-3 mr-1" />
                <span>All time</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row md:items-center gap-4">
          <div className="w-full md:w-1/3">
            <Input
              placeholder="Search by ID, user, or description..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full"
            />
          </div>
          
          <div className="flex items-center space-x-2">
            <Select
              value={filterType}
              onValueChange={setFilterType}
            >
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="deposit">Deposits</SelectItem>
                <SelectItem value="withdrawal">Withdrawals</SelectItem>
                <SelectItem value="payment">Payments</SelectItem>
                <SelectItem value="refund">Refunds</SelectItem>
              </SelectContent>
            </Select>
            
            <Select
              value={filterUser}
              onValueChange={setFilterUser}
            >
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="User Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Users</SelectItem>
                <SelectItem value="client">Clients</SelectItem>
                <SelectItem value="writer">Writers</SelectItem>
                <SelectItem value="admin">Admins</SelectItem>
              </SelectContent>
            </Select>
            
            <Button variant="outline" onClick={() => {
              setSearchQuery("");
              setFilterType("all");
              setFilterUser("all");
            }}>
              Reset
            </Button>
          </div>
        </div>

        {/* Transactions Tabs */}
        <Tabs defaultValue="all" className="space-y-4">
          <TabsList>
            <TabsTrigger value="all">All Transactions</TabsTrigger>
            <TabsTrigger value="pending">Pending Withdrawals ({pendingWithdrawals.length})</TabsTrigger>
          </TabsList>

          {/* All Transactions Tab */}
          <TabsContent value="all">
            <Card>
              <CardHeader className="px-6 py-4 border-b border-neutral-200">
                <CardTitle className="text-xl font-semibold">Transaction History</CardTitle>
                <CardDescription>View all financial transactions across the platform</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                {isLoadingTransactions ? (
                  <div className="flex justify-center items-center h-64">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                  </div>
                ) : filteredTransactions.length === 0 ? (
                  <div className="flex items-center justify-center h-64 text-neutral-500">
                    <p>No transactions found matching your criteria</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full divide-y divide-neutral-200">
                      <thead className="bg-neutral-50">
                        <tr>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">ID</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Date</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">User</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Type</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Amount</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Status</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-neutral-200">
                        {filteredTransactions.map((transaction: any) => (
                          <tr key={transaction.id} className="hover:bg-neutral-50">
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                              #{transaction.id}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                              {formatDate(transaction.createdAt)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                              <div className="flex items-center">
                                <div className="h-8 w-8 rounded-full bg-neutral-200 flex items-center justify-center text-neutral-600 font-semibold">
                                  {transaction.user?.fullName?.charAt(0) || "U"}
                                </div>
                                <div className="ml-2">
                                  <p className="font-medium">{transaction.user?.fullName || "Unknown"}</p>
                                  <Badge className="text-xs">
                                    {transaction.user?.role || "user"}
                                  </Badge>
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm">
                              <Badge className={
                                transaction.type === "deposit" ? "bg-green-100 text-green-800 border-green-200" :
                                transaction.type === "withdrawal" ? "bg-orange-100 text-orange-800 border-orange-200" :
                                transaction.type === "payment" ? "bg-blue-100 text-blue-800 border-blue-200" :
                                transaction.type === "refund" ? "bg-red-100 text-red-800 border-red-200" :
                                "bg-neutral-100 text-neutral-800 border-neutral-200"
                              }>
                                {transaction.type.charAt(0).toUpperCase() + transaction.type.slice(1)}
                              </Badge>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                              ${transaction.amount.toFixed(2)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm">
                              <Badge className={
                                transaction.status === "completed" ? "bg-green-100 text-green-800 border-green-200" :
                                transaction.status === "pending" ? "bg-yellow-100 text-yellow-800 border-yellow-200" :
                                transaction.status === "failed" ? "bg-red-100 text-red-800 border-red-200" :
                                "bg-neutral-100 text-neutral-800 border-neutral-200"
                              }>
                                {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
                              </Badge>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <Button 
                                size="sm" 
                                variant="outline" 
                                onClick={() => openTransactionDetails(transaction)}
                              >
                                Details
                              </Button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Pending Withdrawals Tab */}
          <TabsContent value="pending">
            <Card>
              <CardHeader className="px-6 py-4 border-b border-neutral-200">
                <CardTitle className="text-xl font-semibold">Pending Withdrawals</CardTitle>
                <CardDescription>Withdrawal requests awaiting processing</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                {isLoadingWithdrawals ? (
                  <div className="flex justify-center items-center h-64">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                  </div>
                ) : pendingWithdrawals.length === 0 ? (
                  <div className="flex items-center justify-center h-64 text-neutral-500">
                    <p>No pending withdrawals found</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full divide-y divide-neutral-200">
                      <thead className="bg-neutral-50">
                        <tr>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">ID</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Date</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Writer</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Amount</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Payment Method</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-neutral-200">
                        {pendingWithdrawals.map((transaction: any) => (
                          <tr key={transaction.id} className="hover:bg-neutral-50">
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                              #{transaction.id}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                              {formatDate(transaction.createdAt)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                              <div className="flex items-center">
                                <div className="h-8 w-8 rounded-full bg-neutral-200 flex items-center justify-center text-neutral-600 font-semibold">
                                  {transaction.user?.fullName?.charAt(0) || "W"}
                                </div>
                                <div className="ml-2">
                                  <p className="font-medium">{transaction.user?.fullName || "Unknown"}</p>
                                  <p className="text-xs text-neutral-500">{transaction.user?.email}</p>
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                              ${transaction.amount.toFixed(2)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                              <Badge className="bg-blue-100 text-blue-800 border-blue-200">
                                {transaction.paymentMethod || "Unknown"}
                              </Badge>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <Button 
                                size="sm" 
                                onClick={() => openProcessWithdrawal(transaction)}
                              >
                                Process
                              </Button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Transaction Details Dialog */}
        {selectedTransaction && (
          <Dialog open={isTransactionDetailsOpen} onOpenChange={setIsTransactionDetailsOpen}>
            <DialogContent className="sm:max-w-[550px]">
              <DialogHeader>
                <DialogTitle>Transaction Details</DialogTitle>
                <DialogDescription>
                  Detailed information about transaction #{selectedTransaction.id}
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 my-4">
                <div className="flex justify-between items-center">
                  <div>
                    <Badge className={
                      selectedTransaction.type === "deposit" ? "bg-green-100 text-green-800 border-green-200" :
                      selectedTransaction.type === "withdrawal" ? "bg-orange-100 text-orange-800 border-orange-200" :
                      selectedTransaction.type === "payment" ? "bg-blue-100 text-blue-800 border-blue-200" :
                      selectedTransaction.type === "refund" ? "bg-red-100 text-red-800 border-red-200" :
                      "bg-neutral-100 text-neutral-800 border-neutral-200"
                    }>
                      {selectedTransaction.type.charAt(0).toUpperCase() + selectedTransaction.type.slice(1)}
                    </Badge>
                    <Badge className="ml-2" variant={
                      selectedTransaction.status === "completed" ? "default" :
                      selectedTransaction.status === "pending" ? "outline" :
                      "destructive"
                    }>
                      {selectedTransaction.status.charAt(0).toUpperCase() + selectedTransaction.status.slice(1)}
                    </Badge>
                  </div>
                  <p className="text-xl font-bold">
                    ${selectedTransaction.amount.toFixed(2)}
                  </p>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-neutral-500">Transaction ID</p>
                    <p className="font-medium">#{selectedTransaction.id}</p>
                  </div>
                  <div>
                    <p className="text-sm text-neutral-500">Date</p>
                    <p className="font-medium">{formatDate(selectedTransaction.createdAt)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-neutral-500">Time</p>
                    <p className="font-medium">{new Date(selectedTransaction.createdAt).toLocaleTimeString()}</p>
                  </div>
                  <div>
                    <p className="text-sm text-neutral-500">Reference</p>
                    <p className="font-medium">
                      {selectedTransaction.reference || "N/A"}
                    </p>
                  </div>
                </div>
                
                <div className="border-t pt-4">
                  <h3 className="font-medium mb-2">User Information</h3>
                  <div className="flex items-center">
                    <div className="h-10 w-10 rounded-full bg-neutral-200 flex items-center justify-center text-neutral-600 font-semibold">
                      {selectedTransaction.user?.fullName?.charAt(0) || "U"}
                    </div>
                    <div className="ml-3">
                      <p className="font-medium">{selectedTransaction.user?.fullName || "Unknown"}</p>
                      <p className="text-sm text-neutral-500">{selectedTransaction.user?.email}</p>
                      <Badge className="mt-1">
                        {selectedTransaction.user?.role || "user"}
                      </Badge>
                    </div>
                  </div>
                </div>
                
                {selectedTransaction.paymentMethod && (
                  <div className="border-t pt-4">
                    <h3 className="font-medium mb-2">Payment Details</h3>
                    <p><span className="text-neutral-500">Method:</span> {selectedTransaction.paymentMethod}</p>
                    {selectedTransaction.accountInfo && (
                      <p><span className="text-neutral-500">Account:</span> {selectedTransaction.accountInfo}</p>
                    )}
                  </div>
                )}
                
                {selectedTransaction.description && (
                  <div className="border-t pt-4">
                    <h3 className="font-medium mb-2">Description</h3>
                    <p className="text-neutral-600">{selectedTransaction.description}</p>
                  </div>
                )}
                
                {selectedTransaction.orderId && (
                  <div className="border-t pt-4">
                    <h3 className="font-medium mb-2">Related Order</h3>
                    <Link href={`/orders/${selectedTransaction.orderId}`}>
                      <Button variant="outline" size="sm">
                        <FileText className="h-4 w-4 mr-1" />
                        View Order #{selectedTransaction.orderId}
                      </Button>
                    </Link>
                  </div>
                )}
              </div>
              
              <div className="flex justify-between">
                <Button variant="outline" onClick={() => setIsTransactionDetailsOpen(false)}>
                  Close
                </Button>
                
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-1" />
                  Download Receipt
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        )}

        {/* Process Withdrawal Dialog */}
        {selectedTransaction && (
          <Dialog open={isProcessWithdrawalOpen} onOpenChange={setIsProcessWithdrawalOpen}>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>Process Withdrawal</DialogTitle>
                <DialogDescription>
                  Process withdrawal request #{selectedTransaction.id}
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 my-4">
                <div className="border rounded-md p-4 bg-neutral-50">
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="font-medium">Withdrawal Details</h3>
                    <p className="text-lg font-bold">${selectedTransaction.amount.toFixed(2)}</p>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <p><span className="text-neutral-500">Writer:</span> {selectedTransaction.user?.fullName}</p>
                    <p><span className="text-neutral-500">Date:</span> {formatDate(selectedTransaction.createdAt)}</p>
                    <p><span className="text-neutral-500">Method:</span> {selectedTransaction.paymentMethod}</p>
                    <p><span className="text-neutral-500">Status:</span> Pending</p>
                  </div>
                </div>
                
                {selectedTransaction.accountInfo && (
                  <div className="border rounded-md p-4">
                    <h3 className="font-medium mb-2">Payment Information</h3>
                    <div className="bg-neutral-50 p-3 rounded-md text-sm font-mono">
                      {selectedTransaction.accountInfo}
                    </div>
                  </div>
                )}
                
                <div className="space-y-2">
                  <Label>Process this withdrawal as:</Label>
                  <div className="flex gap-4">
                    <Button 
                      onClick={() => processWithdrawalMutation.mutate({
                        transactionId: selectedTransaction.id,
                        status: "completed"
                      })}
                      disabled={processWithdrawalMutation.isPending}
                    >
                      Complete
                    </Button>
                    <Button 
                      variant="outline"
                      onClick={() => processWithdrawalMutation.mutate({
                        transactionId: selectedTransaction.id,
                        status: "failed"
                      })}
                      disabled={processWithdrawalMutation.isPending}
                    >
                      Reject
                    </Button>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end">
                <Button variant="outline" onClick={() => setIsProcessWithdrawalOpen(false)}>
                  Cancel
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </DashboardLayout>
  );
}