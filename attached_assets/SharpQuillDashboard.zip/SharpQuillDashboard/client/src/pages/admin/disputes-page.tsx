import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { DashboardLayout } from "@/components/ui/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface ResolveDisputeDialogProps {
  dispute: any;
  isOpen: boolean;
  onClose: () => void;
}

function ResolveDisputeDialog({ dispute, isOpen, onClose }: ResolveDisputeDialogProps) {
  const { toast } = useToast();
  const [resolution, setResolution] = useState<string>("");
  const [decision, setDecision] = useState<string>("client"); // "client" or "writer"

  const resolveDisputeMutation = useMutation({
    mutationFn: async (data: { resolution: string, favoredParty: string }) => {
      const res = await apiRequest("POST", `/api/disputes/${dispute.id}/resolve`, data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Dispute resolved",
        description: "The dispute has been resolved successfully",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/disputes"] });
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to resolve dispute",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    resolveDisputeMutation.mutate({
      resolution,
      favoredParty: decision,
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Resolve Dispute #{dispute.id}</DialogTitle>
          <DialogDescription>
            Review details and provide a resolution for this dispute
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 my-4">
          <div className="border rounded-md p-4 bg-neutral-50">
            <h3 className="font-medium text-neutral-700 mb-2">Dispute Information</h3>
            <p><span className="font-medium">Order:</span> #{dispute.orderId}</p>
            <p><span className="font-medium">Reason:</span> {dispute.reason}</p>
            <p><span className="font-medium">Filed By:</span> {dispute.raisedBy === "client" ? "Client" : "Writer"}</p>
            <p><span className="font-medium">Status:</span> {dispute.status}</p>
            <p><span className="font-medium">Date:</span> {new Date(dispute.createdAt).toLocaleDateString()}</p>
          </div>
          
          <div className="border rounded-md p-4">
            <h3 className="font-medium text-neutral-700 mb-2">Description</h3>
            <p className="text-neutral-600 whitespace-pre-line">{dispute.description}</p>
          </div>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="decision">Decision</Label>
            <div className="flex gap-4">
              <div className="flex items-center">
                <input
                  type="radio"
                  id="client"
                  name="decision"
                  value="client"
                  checked={decision === "client"}
                  onChange={() => setDecision("client")}
                  className="mr-2"
                />
                <Label htmlFor="client">Favor Client</Label>
              </div>
              <div className="flex items-center">
                <input
                  type="radio"
                  id="writer"
                  name="decision"
                  value="writer"
                  checked={decision === "writer"}
                  onChange={() => setDecision("writer")}
                  className="mr-2"
                />
                <Label htmlFor="writer">Favor Writer</Label>
              </div>
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="resolution">Resolution</Label>
            <Textarea
              id="resolution"
              value={resolution}
              onChange={(e) => setResolution(e.target.value)}
              placeholder="Explain your decision and any actions taken to resolve the dispute..."
              rows={5}
              required
            />
          </div>
          
          <DialogFooter className="flex justify-between">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={resolveDisputeMutation.isPending}>
              {resolveDisputeMutation.isPending ? "Resolving..." : "Resolve Dispute"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function DisputesPage() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedDispute, setSelectedDispute] = useState<any>(null);
  const [isResolveDialogOpen, setIsResolveDialogOpen] = useState<boolean>(false);
  
  // Fetch all disputes
  const { data: disputes = [], isLoading } = useQuery({
    queryKey: ["/api/disputes"],
  });

  // Filtered disputes based on search
  const filteredDisputes = disputes.filter((dispute: any) => {
    if (!searchQuery) return true;
    
    // Search by ID, order ID, or description
    return dispute.id.toString().includes(searchQuery) ||
           dispute.orderId.toString().includes(searchQuery) ||
           dispute.description?.toLowerCase().includes(searchQuery.toLowerCase());
  });

  // Separate open and resolved disputes
  const openDisputes = filteredDisputes.filter((dispute: any) => dispute.status === "open");
  const resolvedDisputes = filteredDisputes.filter((dispute: any) => dispute.status === "resolved");

  const openResolveDialog = (dispute: any) => {
    setSelectedDispute(dispute);
    setIsResolveDialogOpen(true);
  };

  return (
    <DashboardLayout title="Manage Disputes">
      <div className="space-y-6">
        {/* Search */}
        <div className="w-full md:w-1/3">
          <Input
            placeholder="Search disputes by ID, order ID, or description..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full"
          />
        </div>

        {/* Disputes Tabs */}
        <Tabs defaultValue="open" className="space-y-4">
          <TabsList>
            <TabsTrigger value="open">Open Disputes ({openDisputes.length})</TabsTrigger>
            <TabsTrigger value="resolved">Resolved ({resolvedDisputes.length})</TabsTrigger>
          </TabsList>

          {/* Open Disputes Tab */}
          <TabsContent value="open">
            <Card>
              <CardHeader className="px-6 py-4 border-b border-neutral-200">
                <CardTitle className="text-xl font-semibold">Open Disputes</CardTitle>
                <CardDescription>Active disputes requiring resolution</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                {isLoading ? (
                  <div className="flex justify-center items-center h-64">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                  </div>
                ) : openDisputes.length === 0 ? (
                  <div className="flex items-center justify-center h-64 text-neutral-500">
                    <p>No open disputes found</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full divide-y divide-neutral-200">
                      <thead className="bg-neutral-50">
                        <tr>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">ID</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Order</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Parties</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Reason</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Filed On</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-neutral-200">
                        {openDisputes.map((dispute: any) => (
                          <tr key={dispute.id} className="hover:bg-neutral-50">
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                              #{dispute.id}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                              <Link href={`/orders/${dispute.orderId}`} className="text-primary-600 hover:text-primary-700">
                                Order #{dispute.orderId}
                              </Link>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                              <div>
                                <Badge className="bg-neutral-100 text-neutral-800 border-neutral-200 mb-1">
                                  Client: {dispute.client?.fullName || "Unknown"}
                                </Badge>
                                <Badge className="bg-neutral-100 text-neutral-800 border-neutral-200">
                                  Writer: {dispute.writer?.fullName || "Unknown"}
                                </Badge>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                              <Badge className={
                                dispute.reason === "quality" ? "bg-orange-100 text-orange-800 border-orange-200" :
                                dispute.reason === "plagiarism" ? "bg-red-100 text-red-800 border-red-200" :
                                dispute.reason === "late" ? "bg-yellow-100 text-yellow-800 border-yellow-200" :
                                "bg-neutral-100 text-neutral-800 border-neutral-200"
                              }>
                                {dispute.reason.charAt(0).toUpperCase() + dispute.reason.slice(1)}
                              </Badge>
                              <Badge className="ml-1 bg-blue-100 text-blue-800 border-blue-200">
                                Filed by {dispute.raisedBy === "client" ? "Client" : "Writer"}
                              </Badge>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                              {new Date(dispute.createdAt).toLocaleDateString()}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex space-x-2">
                                <Button 
                                  size="sm" 
                                  onClick={() => openResolveDialog(dispute)}
                                >
                                  Resolve
                                </Button>
                                <Link href={`/orders/${dispute.orderId}`}>
                                  <Button size="sm" variant="outline">
                                    View Order
                                  </Button>
                                </Link>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Resolved Disputes Tab */}
          <TabsContent value="resolved">
            <Card>
              <CardHeader className="px-6 py-4 border-b border-neutral-200">
                <CardTitle className="text-xl font-semibold">Resolved Disputes</CardTitle>
                <CardDescription>Previously resolved dispute cases</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                {isLoading ? (
                  <div className="flex justify-center items-center h-64">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                  </div>
                ) : resolvedDisputes.length === 0 ? (
                  <div className="flex items-center justify-center h-64 text-neutral-500">
                    <p>No resolved disputes found</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full divide-y divide-neutral-200">
                      <thead className="bg-neutral-50">
                        <tr>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">ID</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Order</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Reason</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Resolution</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Resolved On</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-neutral-200">
                        {resolvedDisputes.map((dispute: any) => (
                          <tr key={dispute.id} className="hover:bg-neutral-50">
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                              #{dispute.id}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                              <Link href={`/orders/${dispute.orderId}`} className="text-primary-600 hover:text-primary-700">
                                Order #{dispute.orderId}
                              </Link>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                              <Badge className={
                                dispute.reason === "quality" ? "bg-orange-100 text-orange-800 border-orange-200" :
                                dispute.reason === "plagiarism" ? "bg-red-100 text-red-800 border-red-200" :
                                dispute.reason === "late" ? "bg-yellow-100 text-yellow-800 border-yellow-200" :
                                "bg-neutral-100 text-neutral-800 border-neutral-200"
                              }>
                                {dispute.reason.charAt(0).toUpperCase() + dispute.reason.slice(1)}
                              </Badge>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                              <div className="max-w-xs truncate">
                                {dispute.resolution?.substring(0, 30)}
                                {dispute.resolution?.length > 30 && "..."}
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                              {dispute.resolvedAt ? new Date(dispute.resolvedAt).toLocaleDateString() : "N/A"}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <Button 
                                size="sm" 
                                variant="outline" 
                                onClick={() => openResolveDialog(dispute)}
                              >
                                View Details
                              </Button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Resolve Dispute Dialog */}
        {selectedDispute && (
          <ResolveDisputeDialog
            dispute={selectedDispute}
            isOpen={isResolveDialogOpen}
            onClose={() => setIsResolveDialogOpen(false)}
          />
        )}
      </div>
    </DashboardLayout>
  );
}