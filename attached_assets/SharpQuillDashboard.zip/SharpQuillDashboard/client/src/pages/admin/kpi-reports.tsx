import React from "react";
import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";
import { DashboardLayout } from "@/components/ui/dashboard-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  BarChart, 
  Bar, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from "recharts";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Sample data for KPI reports
const userGrowthData = [
  { month: 'Jan', clients: 12, writers: 5, total: 17 },
  { month: 'Feb', clients: 14, writers: 8, total: 22 },
  { month: 'Mar', clients: 18, writers: 12, total: 30 },
  { month: 'Apr', clients: 25, writers: 15, total: 40 },
  { month: 'May', clients: 30, writers: 20, total: 50 },
  { month: 'Jun', clients: 37, writers: 25, total: 62 }
];

const revenueData = [
  { month: 'Jan', revenue: 12500 },
  { month: 'Feb', revenue: 17800 },
  { month: 'Mar', revenue: 22400 },
  { month: 'Apr', revenue: 29700 },
  { month: 'May', revenue: 35200 },
  { month: 'Jun', revenue: 42800 }
];

const platformActivityData = [
  { month: 'Jan', jobs: 32, orders: 25, disputes: 2 },
  { month: 'Feb', jobs: 40, orders: 30, disputes: 3 },
  { month: 'Mar', jobs: 45, orders: 38, disputes: 1 },
  { month: 'Apr', jobs: 55, orders: 45, disputes: 4 },
  { month: 'May', jobs: 65, orders: 52, disputes: 2 },
  { month: 'Jun', jobs: 75, orders: 67, disputes: 5 }
];

const userDistributionData = [
  { name: 'Clients', value: 65 },
  { name: 'Writers', value: 35 }
];

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

export default function KPIReportsPage() {
  const { user, isLoading } = useAuth();
  
  if (isLoading) {
    return <div className="flex items-center justify-center min-h-screen">
      <div className="animate-spin h-10 w-10 border-4 border-primary border-t-transparent rounded-full"></div>
    </div>;
  }
  
  if (!user || user.role !== "admin") {
    return <Redirect to="/auth" />;
  }
  
  return (
    <DashboardLayout>
      <div className="p-6">
        <div className="mb-6">
          <h1 className="text-3xl font-bold">KPI Reports</h1>
          <p className="text-muted-foreground">Comprehensive analytics and performance metrics for the platform</p>
        </div>
        
        <Tabs defaultValue="growth">
          <TabsList className="mb-6">
            <TabsTrigger value="growth">User Growth</TabsTrigger>
            <TabsTrigger value="revenue">Revenue</TabsTrigger>
            <TabsTrigger value="activity">Platform Activity</TabsTrigger>
            <TabsTrigger value="distribution">User Distribution</TabsTrigger>
          </TabsList>
          
          <TabsContent value="growth">
            <Card>
              <CardHeader>
                <CardTitle>User Growth</CardTitle>
                <CardDescription>Monthly growth of clients and writers on the platform</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={userGrowthData}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="clients" fill="#8884d8" name="Clients" />
                      <Bar dataKey="writers" fill="#82ca9d" name="Writers" />
                      <Bar dataKey="total" fill="#ffc658" name="Total Users" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="revenue">
            <Card>
              <CardHeader>
                <CardTitle>Revenue Overview</CardTitle>
                <CardDescription>Monthly revenue generated on the platform</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={revenueData}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip formatter={(value) => [`$${value}`, "Revenue"]} />
                      <Legend />
                      <Line 
                        type="monotone" 
                        dataKey="revenue" 
                        stroke="#8884d8" 
                        activeDot={{ r: 8 }} 
                        name="Revenue ($)" 
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="activity">
            <Card>
              <CardHeader>
                <CardTitle>Platform Activity</CardTitle>
                <CardDescription>Monthly trends in job postings, completed orders, and disputes</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={platformActivityData}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="jobs" stroke="#8884d8" name="Jobs Posted" />
                      <Line type="monotone" dataKey="orders" stroke="#82ca9d" name="Completed Orders" />
                      <Line type="monotone" dataKey="disputes" stroke="#ff7300" name="Disputes" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="distribution">
            <Card>
              <CardHeader>
                <CardTitle>User Distribution</CardTitle>
                <CardDescription>Distribution of clients and writers on the platform</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[400px] flex items-center justify-center">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={userDistributionData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={150}
                        fill="#8884d8"
                        dataKey="value"
                        nameKey="name"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {userDistributionData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value, name) => [`${value}%`, name]} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}