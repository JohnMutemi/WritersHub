import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { DashboardLayout } from "@/components/ui/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { WriterQuiz } from "@/components/writer-quiz";
import { CheckCircle, XCircle, ArrowLeft } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function WriterQuizPage() {
  const params = useParams<{ id: string }>();
  const writerId = params.id ? parseInt(params.id) : null;
  const [_, setLocation] = useLocation();

  // Fetch the writer information
  const { data: writer, isLoading: isLoadingWriter } = useQuery({
    queryKey: [`/api/users/${writerId}`],
    queryFn: async () => {
      if (!writerId) return null;
      const res = await fetch(`/api/users/${writerId}`);
      if (!res.ok) throw new Error('Failed to fetch writer information');
      return await res.json();
    },
    enabled: !!writerId
  });
  
  // Fetch the quiz results if they exist
  const { data: quizResults, isLoading: isLoadingQuizResults } = useQuery({
    queryKey: [`/api/writers/${writerId}/quiz`],
    queryFn: async () => {
      if (!writerId) return null;
      const res = await fetch(`/api/writers/${writerId}/quiz`);
      if (!res.ok) {
        // If 404, it means the writer hasn't taken the quiz yet
        if (res.status === 404) return null;
        throw new Error('Failed to fetch quiz results');
      }
      return await res.json();
    },
    enabled: !!writerId
  });

  const handleBack = () => {
    setLocation('/dashboard');
  };

  if (!writerId) {
    return (
      <DashboardLayout title="Writer Quiz">
        <Card>
          <CardContent className="pt-6">
            <p>Invalid writer ID.</p>
            <Button onClick={handleBack} className="mt-4">
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
            </Button>
          </CardContent>
        </Card>
      </DashboardLayout>
    );
  }

  if (isLoadingWriter || isLoadingQuizResults) {
    return (
      <DashboardLayout title="Writer Quiz">
        <Card>
          <CardHeader>
            <Skeleton className="h-8 w-64 mb-2" />
            <Skeleton className="h-4 w-32" />
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Skeleton className="h-12 w-full" />
              <Skeleton className="h-12 w-full" />
              <Skeleton className="h-12 w-full" />
              <Skeleton className="h-12 w-full" />
            </div>
          </CardContent>
          <CardFooter>
            <Skeleton className="h-10 w-24" />
          </CardFooter>
        </Card>
      </DashboardLayout>
    );
  }

  if (!writer) {
    return (
      <DashboardLayout title="Writer Quiz">
        <Card>
          <CardContent className="pt-6">
            <p>Writer not found.</p>
            <Button onClick={handleBack} className="mt-4">
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
            </Button>
          </CardContent>
        </Card>
      </DashboardLayout>
    );
  }

  // Check if the writer has already taken the quiz
  if (writer.quizScore !== undefined && writer.quizScore !== null) {
    // If they have, show their results
    return (
      <DashboardLayout title={`${writer.fullName}'s Quiz Results`}>
        <div className="mb-4">
          <Button variant="outline" onClick={handleBack}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Dashboard
          </Button>
        </div>
        
        <Card className="w-full max-w-2xl mx-auto">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">Quiz Results for {writer.fullName}</CardTitle>
            <CardDescription>
              Score: {writer.quizScore}% ({writer.quizPassed ? 'Passed' : 'Failed'})
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex flex-col items-center justify-center py-8">
              {writer.quizPassed ? (
                <CheckCircle className="h-16 w-16 text-green-500 mb-4" />
              ) : (
                <XCircle className="h-16 w-16 text-red-500 mb-4" />
              )}
              <p className="text-2xl font-bold">{writer.quizScore}%</p>
              <p className="text-neutral-600 mt-2">
                {writer.quizPassed 
                  ? "This writer has passed the assessment and is eligible for approval."
                  : "This writer did not pass the assessment. The passing threshold is 70%."}
              </p>
            </div>
            
            <div className="border-t border-b border-neutral-200 py-4">
              <h3 className="font-medium mb-2">Writer Information:</h3>
              <ul className="space-y-2">
                <li className="flex justify-between">
                  <span>Name:</span>
                  <span>{writer.fullName}</span>
                </li>
                <li className="flex justify-between">
                  <span>Email:</span>
                  <span>{writer.email}</span>
                </li>
                <li className="flex justify-between">
                  <span>Approval Status:</span>
                  <span className={
                    writer.approvalStatus === 'approved' 
                      ? 'text-green-600' 
                      : writer.approvalStatus === 'rejected'
                        ? 'text-red-600'
                        : 'text-yellow-600'
                  }>
                    {writer.approvalStatus 
                      ? writer.approvalStatus.charAt(0).toUpperCase() + writer.approvalStatus.slice(1)
                      : 'Pending'
                    }
                  </span>
                </li>
              </ul>
            </div>
          </CardContent>
          <CardFooter className="justify-center">
            <Button onClick={handleBack}>
              Return to Dashboard
            </Button>
          </CardFooter>
        </Card>
      </DashboardLayout>
    );
  }

  // If they haven't, allow them to take it (this path likely won't be reached for admin view)
  return (
    <DashboardLayout title={`Quiz for ${writer.fullName}`}>
      <div className="mb-4">
        <Button variant="outline" onClick={handleBack}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Dashboard
        </Button>
      </div>
      
      <WriterQuiz 
        writerId={writerId} 
        onComplete={(score, passed) => {
          // After completion, we can offer to navigate back
          setTimeout(() => {
            // Give time for the UI to update before offering navigation back
          }, 1500);
        }} 
      />
    </DashboardLayout>
  );
}