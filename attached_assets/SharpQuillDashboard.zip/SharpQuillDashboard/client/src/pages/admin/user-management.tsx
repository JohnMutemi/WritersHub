import React, { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";
import { DashboardLayout } from "@/components/ui/dashboard-layout";
import { useQuery, useMutation } from "@tanstack/react-query";
import { User } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { 
  MoreHorizontal, 
  BadgeCheck, 
  Star, 
  UserX, 
  Edit, 
  Ban, 
  CheckCircle,
  Search,
  Users
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { Input } from "@/components/ui/input";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function UserManagementPage() {
  const { user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  
  // Fetch all users
  const { data: users, isLoading } = useQuery<User[]>({
    queryKey: ["/api/admin/users"],
    queryFn: async () => {
      const res = await fetch("/api/admin/users");
      if (!res.ok) throw new Error("Failed to fetch users");
      return res.json();
    },
    enabled: !!user && user.role === "admin",
  });
  
  // Mutation to update user status
  const updateUserMutation = useMutation({
    mutationFn: async ({ userId, action }: { userId: number; action: string }) => {
      const res = await apiRequest("POST", `/api/admin/users/${userId}/${action}`);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "User updated",
        description: "The user has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      setIsDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update user",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  if (authLoading) {
    return <div className="flex items-center justify-center min-h-screen">
      <div className="animate-spin h-10 w-10 border-4 border-primary border-t-transparent rounded-full"></div>
    </div>;
  }
  
  if (!user || user.role !== "admin") {
    return <Redirect to="/auth" />;
  }
  
  // Filter users based on search
  const filteredUsers = users?.filter(user => 
    user.username.toLowerCase().includes(search.toLowerCase()) ||
    user.email.toLowerCase().includes(search.toLowerCase()) ||
    user.fullName.toLowerCase().includes(search.toLowerCase())
  ) || [];
  
  // Group users by role
  const clients = filteredUsers.filter(user => user.role === "client");
  const writers = filteredUsers.filter(user => user.role === "writer");
  const admins = filteredUsers.filter(user => user.role === "admin");
  
  const handleUserAction = (userId: number, action: string) => {
    updateUserMutation.mutate({ userId, action });
  };
  
  const openUserDetailsDialog = (user: User) => {
    setSelectedUser(user);
    setIsDialogOpen(true);
  };
  
  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case "admin": return "bg-red-500 hover:bg-red-600";
      case "writer": return "bg-blue-500 hover:bg-blue-600";
      case "client": return "bg-green-500 hover:bg-green-600";
      default: return "bg-gray-500 hover:bg-gray-600";
    }
  };
  
  return (
    <DashboardLayout>
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold">User Management</h1>
            <p className="text-muted-foreground">Manage and monitor all users on the platform</p>
          </div>
          
          <div className="flex items-center space-x-2">
            <div className="relative">
              <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search users..."
                className="pl-8 w-[300px]"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Total Users</CardTitle>
              <CardDescription>All registered users</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <Users className="h-6 w-6 mr-2 text-blue-500" />
                <span className="text-3xl font-bold">{users?.length || 0}</span>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Active Writers</CardTitle>
              <CardDescription>Writers with approved status</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <BadgeCheck className="h-6 w-6 mr-2 text-green-500" />
                <span className="text-3xl font-bold">
                  {writers?.filter(w => w.approvalStatus === 'approved').length || 0}
                </span>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Pending Approvals</CardTitle>
              <CardDescription>Writers awaiting approval</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <Ban className="h-6 w-6 mr-2 text-yellow-500" />
                <span className="text-3xl font-bold">
                  {writers?.filter(w => w.approvalStatus === 'pending').length || 0}
                </span>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <Tabs defaultValue="all">
          <TabsList className="mb-6">
            <TabsTrigger value="all">All Users</TabsTrigger>
            <TabsTrigger value="clients">Clients</TabsTrigger>
            <TabsTrigger value="writers">Writers</TabsTrigger>
            <TabsTrigger value="admins">Admins</TabsTrigger>
          </TabsList>
          
          <TabsContent value="all">
            <UserTable 
              users={filteredUsers} 
              openUserDetails={openUserDetailsDialog}
              handleUserAction={handleUserAction}
              isLoading={isLoading}
            />
          </TabsContent>
          
          <TabsContent value="clients">
            <UserTable 
              users={clients} 
              openUserDetails={openUserDetailsDialog}
              handleUserAction={handleUserAction}
              isLoading={isLoading}
            />
          </TabsContent>
          
          <TabsContent value="writers">
            <UserTable 
              users={writers} 
              openUserDetails={openUserDetailsDialog}
              handleUserAction={handleUserAction}
              isLoading={isLoading}
            />
          </TabsContent>
          
          <TabsContent value="admins">
            <UserTable 
              users={admins} 
              openUserDetails={openUserDetailsDialog}
              handleUserAction={handleUserAction}
              isLoading={isLoading}
            />
          </TabsContent>
        </Tabs>
      </div>
      
      {/* User Details Dialog */}
      {selectedUser && (
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>User Details</DialogTitle>
              <DialogDescription>
                Complete information about this user
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <div className="flex items-center space-x-4 mb-6">
                  <div className="h-16 w-16 rounded-full bg-neutral-100 flex items-center justify-center overflow-hidden">
                    {selectedUser.profilePicture ? (
                      <img 
                        src={selectedUser.profilePicture} 
                        alt={selectedUser.fullName}
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <Users className="h-8 w-8 text-neutral-400" />
                    )}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold">{selectedUser.fullName}</h3>
                    <Badge className={getRoleBadgeColor(selectedUser.role)}>
                      {selectedUser.role.charAt(0).toUpperCase() + selectedUser.role.slice(1)}
                    </Badge>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Username</p>
                    <p className="font-medium">{selectedUser.username}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Email</p>
                    <p className="font-medium">{selectedUser.email}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Member Since</p>
                    <p className="font-medium">
                      {selectedUser.createdAt ? format(new Date(selectedUser.createdAt), 'MMM dd, yyyy') : 'N/A'}
                    </p>
                  </div>
                </div>
              </div>
              
              <div>
                {selectedUser.role === "writer" && (
                  <div className="space-y-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Approval Status</p>
                      <Badge 
                        variant={selectedUser.approvalStatus === 'approved' ? 'default' : 'outline'}
                        className={
                          selectedUser.approvalStatus === 'approved' 
                            ? 'bg-green-500 hover:bg-green-600' 
                            : selectedUser.approvalStatus === 'rejected'
                              ? 'border-red-500 text-red-500' 
                              : 'border-yellow-500 text-yellow-500'
                        }
                      >
                        {selectedUser.approvalStatus ? (selectedUser.approvalStatus.charAt(0).toUpperCase() + selectedUser.approvalStatus.slice(1)) : 'Pending'}
                      </Badge>
                    </div>
                    
                    <div>
                      <p className="text-sm text-muted-foreground">Rating</p>
                      <div className="flex items-center">
                        <Star className="h-4 w-4 text-yellow-500 mr-1" />
                        <p className="font-medium">
                          {selectedUser.rating ? selectedUser.rating.toFixed(1) : 'N/A'}
                        </p>
                      </div>
                    </div>
                    
                    <div>
                      <p className="text-sm text-muted-foreground">Quiz Score</p>
                      <p className="font-medium">
                        {selectedUser.quizScore ? `${selectedUser.quizScore}%` : 'Not taken'}
                        {selectedUser.quizPassed && ' (Passed)'}
                      </p>
                    </div>
                    
                    <div>
                      <p className="text-sm text-muted-foreground">Specializations</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {selectedUser.specializations?.map((spec, i) => (
                          <Badge variant="outline" key={i}>
                            {spec}
                          </Badge>
                        )) || 'None specified'}
                      </div>
                    </div>
                    
                    <div>
                      <p className="text-sm text-muted-foreground">Total Earnings</p>
                      <p className="font-medium">
                        ${selectedUser.earnings?.toFixed(2) || '0.00'}
                      </p>
                    </div>
                  </div>
                )}
                
                {selectedUser.role === "client" && (
                  <div className="space-y-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Bio</p>
                      <p className="font-medium">{selectedUser.bio || 'No bio provided'}</p>
                    </div>
                  </div>
                )}
                
                <div className="mt-6">
                  <p className="text-sm text-muted-foreground mb-2">Actions</p>
                  <div className="flex space-x-2">
                    {selectedUser.role === "writer" && selectedUser.approvalStatus === "pending" && (
                      <>
                        <Button 
                          size="sm" 
                          className="bg-green-500 hover:bg-green-600"
                          onClick={() => handleUserAction(selectedUser.id, "approve")}
                        >
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Approve
                        </Button>
                        <Button 
                          size="sm" 
                          variant="destructive"
                          onClick={() => handleUserAction(selectedUser.id, "reject")}
                        >
                          <Ban className="h-4 w-4 mr-1" />
                          Reject
                        </Button>
                      </>
                    )}
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => handleUserAction(selectedUser.id, "edit")}
                    >
                      <Edit className="h-4 w-4 mr-1" />
                      Edit
                    </Button>
                    <Button 
                      size="sm" 
                      variant="destructive"
                      onClick={() => handleUserAction(selectedUser.id, "suspend")}
                    >
                      <UserX className="h-4 w-4 mr-1" />
                      Suspend
                    </Button>
                  </div>
                </div>
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </DashboardLayout>
  );
}

interface UserTableProps {
  users: User[];
  openUserDetails: (user: User) => void;
  handleUserAction: (userId: number, action: string) => void;
  isLoading: boolean;
}

function UserTable({ users, openUserDetails, handleUserAction, isLoading }: UserTableProps) {
  return (
    <div className="border rounded-lg">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>User</TableHead>
            <TableHead>Role</TableHead>
            <TableHead>Email</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Joined</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {isLoading ? (
            <TableRow>
              <TableCell colSpan={6} className="text-center py-10">
                <div className="flex flex-col items-center justify-center">
                  <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mb-2"></div>
                  <p className="text-muted-foreground">Loading users...</p>
                </div>
              </TableCell>
            </TableRow>
          ) : users.length === 0 ? (
            <TableRow>
              <TableCell colSpan={6} className="text-center py-10">
                <p className="text-muted-foreground">No users found</p>
              </TableCell>
            </TableRow>
          ) : (
            users.map((user) => (
              <TableRow key={user.id}>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    <div className="h-8 w-8 rounded-full bg-neutral-100 flex items-center justify-center overflow-hidden">
                      {user.profilePicture ? (
                        <img 
                          src={user.profilePicture} 
                          alt={user.fullName}
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <Users className="h-4 w-4 text-neutral-400" />
                      )}
                    </div>
                    <div>
                      <p className="font-medium">{user.fullName}</p>
                      <p className="text-xs text-muted-foreground">@{user.username}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge 
                    className={
                      user.role === 'admin' 
                        ? 'bg-red-500 hover:bg-red-600' 
                        : user.role === 'writer'
                          ? 'bg-blue-500 hover:bg-blue-600' 
                          : 'bg-green-500 hover:bg-green-600'
                    }
                  >
                    {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                  </Badge>
                </TableCell>
                <TableCell>{user.email}</TableCell>
                <TableCell>
                  {user.role === 'writer' ? (
                    <Badge 
                      variant={user.approvalStatus === 'approved' ? 'default' : 'outline'}
                      className={
                        user.approvalStatus === 'approved' 
                          ? 'bg-green-500 hover:bg-green-600' 
                          : user.approvalStatus === 'rejected'
                            ? 'border-red-500 text-red-500' 
                            : 'border-yellow-500 text-yellow-500'
                      }
                    >
                      {user.approvalStatus ? (user.approvalStatus.charAt(0).toUpperCase() + user.approvalStatus.slice(1)) : 'Pending'}
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="border-green-500 text-green-500">
                      Active
                    </Badge>
                  )}
                </TableCell>
                <TableCell>
                  {user.createdAt ? format(new Date(user.createdAt), 'MMM dd, yyyy') : 'N/A'}
                </TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">
                        <MoreHorizontal className="h-4 w-4" />
                        <span className="sr-only">Open menu</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                      <DropdownMenuItem onClick={() => openUserDetails(user)}>
                        View details
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      {user.role === 'writer' && user.approvalStatus === 'pending' && (
                        <>
                          <DropdownMenuItem onClick={() => handleUserAction(user.id, "approve")}>
                            Approve
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleUserAction(user.id, "reject")}>
                            Reject
                          </DropdownMenuItem>
                        </>
                      )}
                      <DropdownMenuItem onClick={() => handleUserAction(user.id, "edit")}>
                        Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleUserAction(user.id, "suspend")}>
                        Suspend
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
}