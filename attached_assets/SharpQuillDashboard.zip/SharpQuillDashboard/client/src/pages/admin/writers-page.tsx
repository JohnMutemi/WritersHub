import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { DashboardLayout } from "@/components/ui/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";

export default function WritersPage() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [filter, setFilter] = useState<string>("all");
  const [selectedWriter, setSelectedWriter] = useState<any>(null);
  const [isProfileDialogOpen, setIsProfileDialogOpen] = useState<boolean>(false);

  // Fetch all writers
  const { data: writers = [], isLoading: isLoadingWriters } = useQuery({
    queryKey: ["/api/admin/writers"],
  });

  // Fetch pending verification writers
  const { data: pendingWriters = [], isLoading: isLoadingPending } = useQuery({
    queryKey: ["/api/admin/writers/pending"],
  });

  // Approve writer mutation
  const approveWriterMutation = useMutation({
    mutationFn: async (writerId: number) => {
      const res = await apiRequest("POST", `/api/admin/writers/${writerId}/approve`, {});
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Writer approved",
        description: "The writer has been approved successfully",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/writers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/writers/pending"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to approve writer",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Reject writer mutation
  const rejectWriterMutation = useMutation({
    mutationFn: async (writerId: number) => {
      const res = await apiRequest("POST", `/api/admin/writers/${writerId}/reject`, {});
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Writer rejected",
        description: "The writer has been rejected",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/writers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/writers/pending"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to reject writer",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Filter and search writers
  const filteredWriters = writers.filter((writer: any) => {
    // Skip filtering if no search query
    if (!searchQuery) return true;
    
    // Search in name and email
    return writer.fullName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
           writer.email?.toLowerCase().includes(searchQuery.toLowerCase());
  }).filter((writer: any) => {
    if (filter === "all") return true;
    if (filter === "active") return writer.isActive;
    if (filter === "inactive") return !writer.isActive;
    return true;
  });

  // Filter and search pending writers
  const filteredPendingWriters = pendingWriters.filter((writer: any) => {
    if (!searchQuery) return true;
    return writer.fullName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
           writer.email?.toLowerCase().includes(searchQuery.toLowerCase());
  });

  const handleApproveWriter = (writerId: number) => {
    if (window.confirm("Are you sure you want to approve this writer?")) {
      approveWriterMutation.mutate(writerId);
    }
  };

  const handleRejectWriter = (writerId: number) => {
    if (window.confirm("Are you sure you want to reject this writer?")) {
      rejectWriterMutation.mutate(writerId);
    }
  };

  const openWriterProfile = (writer: any) => {
    setSelectedWriter(writer);
    setIsProfileDialogOpen(true);
  };

  return (
    <DashboardLayout title="Manage Writers">
      <div className="space-y-6">
        {/* Search and Filter */}
        <div className="flex flex-col md:flex-row items-start md:items-center gap-4">
          <div className="w-full md:w-1/3">
            <Input
              placeholder="Search writers..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full"
            />
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant={filter === "all" ? "default" : "outline"}
              onClick={() => setFilter("all")}
              size="sm"
            >
              All
            </Button>
            <Button
              variant={filter === "active" ? "default" : "outline"}
              onClick={() => setFilter("active")}
              size="sm"
            >
              Active
            </Button>
            <Button
              variant={filter === "inactive" ? "default" : "outline"}
              onClick={() => setFilter("inactive")}
              size="sm"
            >
              Inactive
            </Button>
          </div>
        </div>

        {/* Writers Tabs */}
        <Tabs defaultValue="all" className="space-y-4">
          <TabsList>
            <TabsTrigger value="all">All Writers ({writers.length})</TabsTrigger>
            <TabsTrigger value="pending">Pending Approval ({pendingWriters.length})</TabsTrigger>
          </TabsList>

          {/* All Writers Tab */}
          <TabsContent value="all">
            <Card>
              <CardHeader className="px-6 py-4 border-b border-neutral-200">
                <CardTitle className="text-xl font-semibold">Writers</CardTitle>
                <CardDescription>Manage and review all writers on the platform</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                {isLoadingWriters ? (
                  <div className="flex justify-center items-center h-64">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                  </div>
                ) : filteredWriters.length === 0 ? (
                  <div className="flex items-center justify-center h-64 text-neutral-500">
                    <p>No writers found matching your criteria</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full divide-y divide-neutral-200">
                      <thead className="bg-neutral-50">
                        <tr>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Writer</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Rating</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Orders</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Earnings</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Status</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-neutral-200">
                        {filteredWriters.map((writer: any) => (
                          <tr key={writer.id} className="hover:bg-neutral-50">
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                <div className="h-10 w-10 rounded-full bg-neutral-200 flex items-center justify-center text-neutral-600 font-semibold">
                                  {writer.fullName?.charAt(0) || "W"}
                                </div>
                                <div className="ml-3">
                                  <p className="text-sm font-medium text-neutral-800">{writer.fullName}</p>
                                  <p className="text-xs text-neutral-500">{writer.email}</p>
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                              {writer.rating ? `${writer.rating}/5` : "Not rated"}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                              {writer.completedOrders || 0}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                              ${writer.earnings?.toFixed(2) || "0.00"}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <Badge className={
                                writer.isActive 
                                  ? "bg-green-100 text-green-800 border-green-200" 
                                  : "bg-neutral-100 text-neutral-800 border-neutral-200"
                              }>
                                {writer.isActive ? "Active" : "Inactive"}
                              </Badge>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-right">
                              <Button 
                                size="sm" 
                                variant="outline" 
                                onClick={() => openWriterProfile(writer)}
                              >
                                View Profile
                              </Button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Pending Approval Tab */}
          <TabsContent value="pending">
            <Card>
              <CardHeader className="px-6 py-4 border-b border-neutral-200">
                <CardTitle className="text-xl font-semibold">Pending Approval</CardTitle>
                <CardDescription>Writers waiting for approval to join the platform</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                {isLoadingPending ? (
                  <div className="flex justify-center items-center h-64">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                  </div>
                ) : filteredPendingWriters.length === 0 ? (
                  <div className="flex items-center justify-center h-64 text-neutral-500">
                    <p>No pending writers found</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full divide-y divide-neutral-200">
                      <thead className="bg-neutral-50">
                        <tr>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Writer</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Applied On</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Specializations</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Status</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-neutral-200">
                        {filteredPendingWriters.map((writer: any) => (
                          <tr key={writer.id} className="hover:bg-neutral-50">
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                <div className="h-10 w-10 rounded-full bg-neutral-200 flex items-center justify-center text-neutral-600 font-semibold">
                                  {writer.fullName?.charAt(0) || "W"}
                                </div>
                                <div className="ml-3">
                                  <p className="text-sm font-medium text-neutral-800">{writer.fullName}</p>
                                  <p className="text-xs text-neutral-500">{writer.email}</p>
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                              {new Date(writer.createdAt).toLocaleDateString()}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                              <div className="flex flex-wrap gap-1">
                                {writer.specializations?.map((spec: string, index: number) => (
                                  <Badge key={index} variant="outline" className="bg-neutral-50">
                                    {spec}
                                  </Badge>
                                )) || "None specified"}
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200">
                                Pending
                              </Badge>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex space-x-2">
                                <Button 
                                  size="sm" 
                                  onClick={() => handleApproveWriter(writer.id)}
                                >
                                  Approve
                                </Button>
                                <Button 
                                  size="sm" 
                                  variant="outline" 
                                  onClick={() => handleRejectWriter(writer.id)}
                                >
                                  Reject
                                </Button>
                                <Link href={`/writer-quiz/${writer.id}`}>
                                  <Button size="sm" variant="outline">Quiz</Button>
                                </Link>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Writer Profile Dialog */}
        {selectedWriter && (
          <Dialog open={isProfileDialogOpen} onOpenChange={setIsProfileDialogOpen}>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Writer Profile</DialogTitle>
                <DialogDescription>
                  View complete writer details and performance
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="flex items-center">
                  <div className="h-16 w-16 rounded-full bg-neutral-200 flex items-center justify-center text-neutral-600 font-semibold text-xl">
                    {selectedWriter.fullName?.charAt(0) || "W"}
                  </div>
                  <div className="ml-4">
                    <h3 className="text-lg font-semibold">{selectedWriter.fullName}</h3>
                    <p className="text-neutral-500">{selectedWriter.email}</p>
                    <div className="flex items-center mt-1">
                      <Badge className={
                        selectedWriter.isActive
                          ? "bg-green-100 text-green-800 border-green-200"
                          : "bg-neutral-100 text-neutral-800 border-neutral-200"
                      }>
                        {selectedWriter.isActive ? "Active" : "Inactive"}
                      </Badge>
                      {selectedWriter.rating && (
                        <Badge className="ml-2 bg-yellow-100 text-yellow-800 border-yellow-200">
                          {selectedWriter.rating}/5 Rating
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                  <div className="bg-neutral-50 p-4 rounded-md">
                    <p className="text-sm text-neutral-500">Completed Orders</p>
                    <p className="text-xl font-semibold">{selectedWriter.completedOrders || 0}</p>
                  </div>
                  <div className="bg-neutral-50 p-4 rounded-md">
                    <p className="text-sm text-neutral-500">Total Earnings</p>
                    <p className="text-xl font-semibold">${selectedWriter.earnings?.toFixed(2) || "0.00"}</p>
                  </div>
                  <div className="bg-neutral-50 p-4 rounded-md">
                    <p className="text-sm text-neutral-500">Member Since</p>
                    <p className="text-xl font-semibold">{new Date(selectedWriter.createdAt).toLocaleDateString()}</p>
                  </div>
                </div>

                {selectedWriter.bio && (
                  <div className="mt-4">
                    <h3 className="text-sm font-medium text-neutral-700 mb-2">Bio</h3>
                    <p className="text-neutral-600 text-sm">{selectedWriter.bio}</p>
                  </div>
                )}

                {selectedWriter.specializations && selectedWriter.specializations.length > 0 && (
                  <div className="mt-4">
                    <h3 className="text-sm font-medium text-neutral-700 mb-2">Specializations</h3>
                    <div className="flex flex-wrap gap-2">
                      {selectedWriter.specializations.map((spec: string, index: number) => (
                        <Badge key={index} variant="outline">
                          {spec}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                <div className="mt-4 pt-4 border-t flex justify-between">
                  <Button variant="outline" onClick={() => setIsProfileDialogOpen(false)}>
                    Close
                  </Button>
                  
                  <div className="space-x-2">
                    <Button variant={selectedWriter.isActive ? "destructive" : "default"}>
                      {selectedWriter.isActive ? "Deactivate Account" : "Activate Account"}
                    </Button>
                  </div>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </DashboardLayout>
  );
}