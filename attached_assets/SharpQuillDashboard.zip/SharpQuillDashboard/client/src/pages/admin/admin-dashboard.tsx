import React, { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { DashboardLayout } from "@/components/ui/dashboard-layout";
import { StatCard } from "@/components/ui/stat-card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  User, 
  Job, 
  Order, 
  Dispute, 
  Transaction 
} from "@shared/schema";
import { 
  Users, 
  FileText, 
  AlertTriangle, 
  DollarSign, 
  BarChart2,
  CheckCircle,
  XCircle,
  ClipboardCheck,
  Clock,
  Shield,
  Search
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from "recharts";

// Chart component for user growth
function UserGrowthChart() {
  const userGrowthData = [
    { month: "Jan", users: 10 },
    { month: "Feb", users: 15 },
    { month: "Mar", users: 22 },
    { month: "Apr", users: 35 },
    { month: "May", users: 42 },
    { month: "Jun", users: 55 },
    { month: "Jul", users: 65 },
    { month: "Aug", users: 78 },
    { month: "Sep", users: 92 },
    { month: "Oct", users: 108 },
    { month: "Nov", users: 120 },
    { month: "Dec", users: 135 },
  ];

  return (
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart
        data={userGrowthData}
        margin={{
          top: 10,
          right: 30,
          left: 0,
          bottom: 0,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
        <XAxis 
          dataKey="month" 
          tick={{ fontSize: 12 }}
        />
        <YAxis 
          tick={{ fontSize: 12 }}
          width={35}
        />
        <Tooltip />
        <Area
          type="monotone"
          dataKey="users"
          stroke="#6366f1"
          fill="#6366f1"
          fillOpacity={0.2}
          activeDot={{ r: 8 }}
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}

// Chart component for revenue overview
function RevenueChart() {
  const revenueData = [
    { month: "Jan", earned: 500, withdrawn: 400 },
    { month: "Feb", earned: 750, withdrawn: 600 },
    { month: "Mar", earned: 1200, withdrawn: 950 },
    { month: "Apr", earned: 1800, withdrawn: 1500 },
    { month: "May", earned: 2100, withdrawn: 1850 },
    { month: "Jun", earned: 2500, withdrawn: 2000 },
    { month: "Jul", earned: 3000, withdrawn: 2400 },
    { month: "Aug", earned: 3400, withdrawn: 2900 },
    { month: "Sep", earned: 4000, withdrawn: 3500 },
    { month: "Oct", earned: 4200, withdrawn: 3600 },
    { month: "Nov", earned: 4800, withdrawn: 4200 },
    { month: "Dec", earned: 5500, withdrawn: 4800 },
  ];

  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart
        data={revenueData}
        margin={{
          top: 20,
          right: 30,
          left: 0,
          bottom: 0,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
        <XAxis 
          dataKey="month" 
          tick={{ fontSize: 12 }}
        />
        <YAxis 
          tick={{ fontSize: 12 }}
          width={45}
          tickFormatter={(value) => `$${value}`}
        />
        <Tooltip formatter={(value) => [`$${value}`, ""]} />
        <Legend />
        <Bar dataKey="earned" name="Revenue" fill="#6366f1" radius={[4, 4, 0, 0]} />
        <Bar dataKey="withdrawn" name="Writer Payments" fill="#10b981" radius={[4, 4, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}

// Chart component for platform activity
function ActivityChart() {
  const activityData = [
    { name: "Week 1", jobs: 15, orders: 10, disputes: 1 },
    { name: "Week 2", jobs: 22, orders: 18, disputes: 2 },
    { name: "Week 3", jobs: 28, orders: 24, disputes: 0 },
    { name: "Week 4", jobs: 35, orders: 30, disputes: 3 },
    { name: "Week 5", jobs: 30, orders: 25, disputes: 1 },
    { name: "Week 6", jobs: 40, orders: 35, disputes: 2 },
    { name: "Week 7", jobs: 45, orders: 40, disputes: 0 },
    { name: "Week 8", jobs: 50, orders: 45, disputes: 1 },
  ];

  return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart
        data={activityData}
        margin={{
          top: 20,
          right: 30,
          left: 0,
          bottom: 0,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
        <XAxis 
          dataKey="name" 
          tick={{ fontSize: 12 }}
        />
        <YAxis 
          tick={{ fontSize: 12 }}
          width={30}
        />
        <Tooltip />
        <Legend />
        <Line
          type="monotone"
          dataKey="jobs"
          name="Jobs Posted"
          stroke="#6366f1"
          strokeWidth={2}
          activeDot={{ r: 8 }}
        />
        <Line
          type="monotone"
          dataKey="orders"
          name="Orders Completed"
          stroke="#10b981"
          strokeWidth={2}
        />
        <Line
          type="monotone"
          dataKey="disputes"
          name="Disputes"
          stroke="#f43f5e"
          strokeWidth={2}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}

// Chart component for user distribution
function UserDistributionChart() {
  const userDistributionData = [
    { name: "Clients", value: 62, fill: "#10b981" },
    { name: "Writers", value: 35, fill: "#6366f1" },
    { name: "Admins", value: 3, fill: "#f43f5e" },
  ];

  const RADIAN = Math.PI / 180;
  const renderCustomizedLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent, index }: any) => {
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    return (
      <text x={x} y={y} fill="white" textAnchor={x > cx ? 'start' : 'end'} dominantBaseline="central">
        {`${userDistributionData[index].name} ${(percent * 100).toFixed(0)}%`}
      </text>
    );
  };

  return (
    <ResponsiveContainer width="100%" height="60%">
      <PieChart>
        <Pie
          data={userDistributionData}
          cx="50%"
          cy="50%"
          labelLine={false}
          label={renderCustomizedLabel}
          outerRadius={80}
          fill="#8884d8"
          dataKey="value"
        >
          {userDistributionData.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={entry.fill} />
          ))}
        </Pie>
        <Tooltip formatter={(value) => [`${value} users`, ""]} />
      </PieChart>
    </ResponsiveContainer>
  );
}

// Function to generate top writers data
function generateTopWriters() {
  return [
    { name: "John Smith", rating: 4.9, earnings: "2,450" },
    { name: "Sarah Johnson", rating: 4.8, earnings: "2,100" },
    { name: "Michael Williams", rating: 4.7, earnings: "1,950" },
    { name: "Emma Brown", rating: 4.7, earnings: "1,800" },
  ];
}

export default function AdminDashboard() {
  const { user, isLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState("");

  // Fetch admin stats
  const { data: stats = {} } = useQuery<{
    totalUsers: number,
    totalWriters: number,
    totalClients: number,
    pendingVerifications: number,
    activeJobs: number,
    completedJobs: number,
    totalDisputes: number,
    totalTransactions: number,
    totalRevenue: number,
    usersGrowth: number,
    revenueGrowth: number
  }>({
    queryKey: ["/api/admin/stats"],
    enabled: !!user && user.role === "admin",
  });

  // Fetch pending writer verifications
  const { data: pendingWriters = [] } = useQuery<User[]>({
    queryKey: ["/api/admin/writers/pending"],
    enabled: !!user && user.role === "admin",
  });

  // Fetch recent disputes
  const { data: disputes = [] } = useQuery<Dispute[]>({
    queryKey: ["/api/disputes"],
    enabled: !!user && user.role === "admin",
  });

  // Fetch recent transactions
  const { data: transactions = [] } = useQuery<Transaction[]>({
    queryKey: ["/api/admin/transactions"],
    enabled: !!user && user.role === "admin",
  });

  // Fetch all users for the user management tab
  const { data: allUsers = [] } = useQuery<User[]>({
    queryKey: ["/api/admin/users"],
    enabled: !!user && user.role === "admin",
  });

  // Filter users based on search term
  const filteredUsers = allUsers.filter(u => 
    u.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.username.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Mutation for approving a writer
  const approveWriterMutation = useMutation({
    mutationFn: async (writerId: number) => {
      const res = await apiRequest("POST", `/api/admin/writers/${writerId}/approve`, {});
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Writer Approved",
        description: "The writer has been successfully approved.",
      });
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ["/api/admin/writers/pending"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Approval Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Mutation for rejecting a writer
  const rejectWriterMutation = useMutation({
    mutationFn: async (writerId: number) => {
      const res = await apiRequest("POST", `/api/admin/writers/${writerId}/reject`, {});
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Writer Rejected",
        description: "The writer has been rejected.",
      });
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ["/api/admin/writers/pending"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Rejection Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Loading state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin h-10 w-10 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  // Redirect if not admin
  if (!user || user.role !== "admin") {
    return <Redirect to="/auth" />;
  }

  return (
    <DashboardLayout>
      <div className="container mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold mb-6">Admin Dashboard</h1>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatCard
            label="Total Users"
            value={stats.totalUsers || 0}
            icon={<Users className="h-6 w-6" />}
            change={`${stats.usersGrowth || 0}%`}
            changeType={stats.usersGrowth > 0 ? "positive" : "negative"}
          />
          <StatCard
            label="Active Jobs"
            value={stats.activeJobs || 0}
            icon={<FileText className="h-6 w-6" />}
            changeType="neutral"
          />
          <StatCard
            label="Open Disputes"
            value={stats.totalDisputes || 0}
            icon={<AlertTriangle className="h-6 w-6" />}
            changeType={stats.totalDisputes > 0 ? "negative" : "positive"}
          />
          <StatCard
            label="Total Revenue"
            value={`$${(stats.totalRevenue || 0).toFixed(2)}`}
            icon={<DollarSign className="h-6 w-6" />}
            change={`${stats.revenueGrowth || 0}%`}
            changeType={stats.revenueGrowth > 0 ? "positive" : "negative"}
          />
        </div>

        {/* KPI Dashboard Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle>User Growth</CardTitle>
              <CardDescription>New user registrations over time</CardDescription>
            </CardHeader>
            <CardContent className="h-80">
              <UserGrowthChart />
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Revenue Overview</CardTitle>
              <CardDescription>Platform earnings and transactions</CardDescription>
            </CardHeader>
            <CardContent className="h-80">
              <RevenueChart />
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="writer-approval" className="w-full">
          <TabsList className="grid grid-cols-5 mb-6">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="writer-approval">Writer Approval</TabsTrigger>
            <TabsTrigger value="disputes">Disputes</TabsTrigger>
            <TabsTrigger value="transactions">Transactions</TabsTrigger>
            <TabsTrigger value="user-management">User Management</TabsTrigger>
          </TabsList>
          
          {/* Dashboard Overview Tab - Detailed Analytics */}
          <TabsContent value="dashboard">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card className="lg:col-span-2">
                <CardHeader className="pb-2">
                  <CardTitle>Platform Activity</CardTitle>
                  <CardDescription>Jobs, orders, and user interactions</CardDescription>
                </CardHeader>
                <CardContent className="h-96">
                  <ActivityChart />
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle>User Distribution</CardTitle>
                  <CardDescription>Breakdown by role</CardDescription>
                </CardHeader>
                <CardContent className="h-96 flex flex-col justify-between">
                  <UserDistributionChart />
                  
                  <div className="border-t pt-4 mt-4">
                    <h4 className="text-sm font-medium mb-3">Top Writers</h4>
                    <div className="space-y-3">
                      {generateTopWriters().map((writer, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <div className="flex items-center">
                            <div className="h-8 w-8 rounded-full bg-primary-50 flex items-center justify-center text-xs font-medium text-primary-600">
                              {writer.name.split(' ').map(n => n[0]).join('')}
                            </div>
                            <div className="ml-2">
                              <p className="text-sm font-medium">{writer.name}</p>
                              <div className="flex text-xs text-yellow-400">
                                {'★'.repeat(Math.floor(writer.rating))}
                                {'☆'.repeat(5 - Math.floor(writer.rating))}
                              </div>
                            </div>
                          </div>
                          <div className="text-sm font-medium">${writer.earnings}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Writer Approval Tab */}
          <TabsContent value="writer-approval">
            <Card>
              <CardHeader>
                <CardTitle>Pending Writer Approvals</CardTitle>
                <CardDescription>
                  Review and approve new writer applications
                </CardDescription>
              </CardHeader>
              <CardContent>
                {pendingWriters.length === 0 ? (
                  <div className="text-center py-6">
                    <p className="text-neutral-500">No pending writer approvals</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Name</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Specializations</TableHead>
                          <TableHead>Quiz Score</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {pendingWriters.map((writer) => (
                          <TableRow key={writer.id}>
                            <TableCell className="font-medium">{writer.fullName}</TableCell>
                            <TableCell>{writer.email}</TableCell>
                            <TableCell>
                              {writer.specializations?.join(", ") || "None specified"}
                            </TableCell>
                            <TableCell>
                              {writer.quizScore ? (
                                <Badge className={
                                  writer.quizScore >= 80 ? "bg-green-100 text-green-800" :
                                  writer.quizScore >= 60 ? "bg-yellow-100 text-yellow-800" :
                                  "bg-red-100 text-red-800"
                                }>
                                  {writer.quizScore}%
                                </Badge>
                              ) : (
                                <Badge variant="outline">Not taken</Badge>
                              )}
                            </TableCell>
                            <TableCell>
                              <div className="flex space-x-2">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="flex items-center text-green-600 hover:text-green-700"
                                  onClick={() => approveWriterMutation.mutate(writer.id)}
                                  disabled={approveWriterMutation.isPending || rejectWriterMutation.isPending}
                                >
                                  <CheckCircle className="h-4 w-4 mr-1" />
                                  Approve
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="flex items-center text-red-600 hover:text-red-700"
                                  onClick={() => rejectWriterMutation.mutate(writer.id)}
                                  disabled={approveWriterMutation.isPending || rejectWriterMutation.isPending}
                                >
                                  <XCircle className="h-4 w-4 mr-1" />
                                  Reject
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Disputes Tab */}
          <TabsContent value="disputes">
            <Card>
              <CardHeader>
                <CardTitle>Open Disputes</CardTitle>
                <CardDescription>
                  Manage and resolve order disputes
                </CardDescription>
              </CardHeader>
              <CardContent>
                {disputes.length === 0 ? (
                  <div className="text-center py-6">
                    <p className="text-neutral-500">No open disputes</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Order ID</TableHead>
                          <TableHead>Raised By</TableHead>
                          <TableHead>Reason</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {disputes.map((dispute) => (
                          <TableRow key={dispute.id}>
                            <TableCell>#{dispute.orderId}</TableCell>
                            <TableCell>{dispute.raisedBy}</TableCell>
                            <TableCell className="max-w-xs truncate">
                              {dispute.reason}
                            </TableCell>
                            <TableCell>
                              {dispute.createdAt ? 
                                format(new Date(dispute.createdAt), 'MMM dd, yyyy') : 
                                'Unknown date'}
                            </TableCell>
                            <TableCell>
                              <Badge className={
                                dispute.status === "resolved" ? "bg-green-100 text-green-800" :
                                dispute.status === "in_review" ? "bg-blue-100 text-blue-800" :
                                "bg-yellow-100 text-yellow-800"
                              }>
                                {dispute.status}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Button size="sm">Review</Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Transactions Tab */}
          <TabsContent value="transactions">
            <Card>
              <CardHeader>
                <CardTitle>Recent Transactions</CardTitle>
                <CardDescription>
                  Monitor payment activity across the platform
                </CardDescription>
              </CardHeader>
              <CardContent>
                {transactions.length === 0 ? (
                  <div className="text-center py-6">
                    <p className="text-neutral-500">No transactions found</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>User</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Amount</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {transactions.map((transaction) => (
                          <TableRow key={transaction.id}>
                            <TableCell>#{transaction.id}</TableCell>
                            <TableCell>{transaction.description}</TableCell>
                            <TableCell>
                              <Badge className={
                                transaction.type === "deposit" ? "bg-green-100 text-green-800" :
                                transaction.type === "withdrawal" ? "bg-blue-100 text-blue-800" :
                                transaction.type === "refund" ? "bg-red-100 text-red-800" :
                                "bg-neutral-100 text-neutral-800"
                              }>
                                {transaction.type}
                              </Badge>
                            </TableCell>
                            <TableCell>${transaction.amount.toFixed(2)}</TableCell>
                            <TableCell>
                              {transaction.createdAt ? 
                                format(new Date(transaction.createdAt), 'MMM dd, yyyy') : 
                                'Unknown date'}
                            </TableCell>
                            <TableCell>
                              <Badge className={
                                transaction.status === "completed" ? "bg-green-100 text-green-800" :
                                transaction.status === "pending" ? "bg-yellow-100 text-yellow-800" :
                                transaction.status === "failed" ? "bg-red-100 text-red-800" :
                                "bg-neutral-100 text-neutral-800"
                              }>
                                {transaction.status}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Button size="sm" variant="outline">Details</Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* User Management Tab */}
          <TabsContent value="user-management">
            <Card>
              <CardHeader>
                <CardTitle>User Management</CardTitle>
                <CardDescription>
                  Manage all users of the platform
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex mb-4">
                  <div className="relative w-full max-w-sm">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                    <Input
                      placeholder="Search users..."
                      className="pl-10"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Username</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Role</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Joined</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredUsers.map((user) => (
                        <TableRow key={user.id}>
                          <TableCell className="font-medium">{user.fullName}</TableCell>
                          <TableCell>{user.username}</TableCell>
                          <TableCell>{user.email}</TableCell>
                          <TableCell>
                            <Badge className={
                              user.role === "admin" ? "bg-purple-100 text-purple-800" :
                              user.role === "writer" ? "bg-blue-100 text-blue-800" :
                              "bg-green-100 text-green-800"
                            }>
                              {user.role}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge className={user.isActive ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>
                              {user.isActive ? "Active" : "Inactive"}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {user.createdAt ? 
                              format(new Date(user.createdAt), 'MMM dd, yyyy') : 
                              'Unknown date'}
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button size="sm" variant="outline">View</Button>
                              {user.role !== "admin" && (
                                <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700">
                                  Suspend
                                </Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}