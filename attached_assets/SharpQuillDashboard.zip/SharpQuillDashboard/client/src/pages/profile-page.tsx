import React, { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { DashboardLayout } from "@/components/ui/dashboard-layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";

// Form schema for profile update
const profileUpdateSchema = z.object({
  fullName: z.string().min(1, "Name is required"),
  email: z.string().email("Invalid email address"),
  bio: z.string().optional(),
  specializations: z.string().optional()
});

type ProfileFormValues = z.infer<typeof profileUpdateSchema>;

export default function ProfilePage() {
  const { user, isLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [profileImage, setProfileImage] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  // Form setup
  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileUpdateSchema),
    defaultValues: {
      fullName: user?.fullName || "",
      email: user?.email || "",
      bio: user?.bio || "",
      specializations: user?.specializations?.join(", ") || ""
    }
  });

  // Handle profile update
  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileFormValues) => {
      // Create a FormData object to handle file upload
      const formData = new FormData();
      
      // Add form fields to FormData
      formData.append("fullName", data.fullName);
      formData.append("email", data.email);
      formData.append("bio", data.bio || "");
      
      // Convert specializations string to array
      const specializations = data.specializations
        ? data.specializations.split(",").map(item => item.trim())
        : [];
      
      formData.append("specializations", JSON.stringify(specializations));
      
      // Add profile image if selected
      if (profileImage) {
        formData.append("profileImage", profileImage);
      }
      
      const res = await apiRequest("PATCH", `/api/users/${user?.id}`, formData, true);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Profile updated successfully",
        description: "Your profile information has been updated.",
      });
      // Invalidate user data query to refresh the UI
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update profile",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Handle image change
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setProfileImage(file);
      
      // Create preview URL
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle form submission
  const onSubmit = (data: ProfileFormValues) => {
    updateProfileMutation.mutate(data);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return <Redirect to="/auth" />;
  }

  return (
    <DashboardLayout>
      <div className="container mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold mb-6">My Profile</h1>
        
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex flex-col lg:flex-row">
            {/* Profile Image Section */}
            <div className="w-full lg:w-1/3 flex flex-col items-center mb-6 lg:mb-0">
              <div className="w-40 h-40 rounded-full overflow-hidden mb-4 bg-gray-200">
                <img 
                  src={previewUrl || user?.profilePicture || "https://via.placeholder.com/150"} 
                  alt={user?.fullName}
                  className="w-full h-full object-cover"
                />
              </div>
              <label className="cursor-pointer">
                <span className="bg-primary hover:bg-primary-dark text-white py-2 px-4 rounded inline-block">
                  Change Photo
                </span>
                <input 
                  type="file" 
                  accept="image/*" 
                  className="hidden" 
                  onChange={handleImageChange}
                />
              </label>
              
              <div className="mt-6 text-center">
                <h2 className="text-xl font-semibold">{user.fullName}</h2>
                <p className="text-gray-600">{user.role}</p>
                {user.rating && (
                  <div className="flex items-center justify-center mt-2">
                    <span className="text-yellow-500 mr-1">★</span>
                    <span>{user.rating.toFixed(1)}</span>
                  </div>
                )}
              </div>
            </div>
            
            {/* Profile Form Section */}
            <div className="lg:w-2/3 lg:pl-8">
              <form onSubmit={form.handleSubmit(onSubmit)}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Full Name
                    </label>
                    <Input
                      placeholder="Full Name"
                      {...form.register("fullName")}
                      className="w-full"
                    />
                    {form.formState.errors.fullName && (
                      <p className="text-red-500 text-xs mt-1">
                        {form.formState.errors.fullName.message}
                      </p>
                    )}
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Email
                    </label>
                    <Input
                      placeholder="Email"
                      type="email"
                      {...form.register("email")}
                      className="w-full"
                    />
                    {form.formState.errors.email && (
                      <p className="text-red-500 text-xs mt-1">
                        {form.formState.errors.email.message}
                      </p>
                    )}
                  </div>
                </div>
                
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Bio
                  </label>
                  <Textarea
                    placeholder="Tell us about yourself"
                    {...form.register("bio")}
                    className="w-full h-32"
                  />
                </div>
                
                {user.role === "writer" && (
                  <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Specializations (comma separated)
                    </label>
                    <Input
                      placeholder="E.g. Academic Writing, Technical Writing, Creative Writing"
                      {...form.register("specializations")}
                      className="w-full"
                    />
                  </div>
                )}
                
                <Button 
                  type="submit" 
                  className="mt-2"
                  disabled={updateProfileMutation.isPending}
                >
                  {updateProfileMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Updating...
                    </>
                  ) : (
                    "Save Changes"
                  )}
                </Button>
              </form>
            </div>
          </div>
          
          {/* Additional Writer-specific sections */}
          {user.role === "writer" && (
            <div className="mt-8 pt-6 border-t">
              <h3 className="text-lg font-semibold mb-4">Writer Information</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Total Earnings</h4>
                  <p className="text-2xl font-bold text-primary">${user.earnings?.toFixed(2) || "0.00"}</p>
                </div>
                
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Experience Level</h4>
                  <div className="flex items-center">
                    <div className="h-2 flex-grow bg-gray-200 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-primary" 
                        style={{ width: `${Math.min((user.rating || 0) * 20, 100)}%` }}
                      ></div>
                    </div>
                    <span className="ml-2 text-sm font-medium">{Math.floor((user.rating || 0) * 20)}%</span>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {/* Security Section */}
          <div className="mt-8 pt-6 border-t">
            <h3 className="text-lg font-semibold mb-4">Security</h3>
            <Button variant="outline" className="mr-4">
              Change Password
            </Button>
            <Button variant="destructive">
              Delete Account
            </Button>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}