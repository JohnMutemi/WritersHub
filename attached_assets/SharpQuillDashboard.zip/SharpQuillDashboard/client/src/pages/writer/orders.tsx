import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { DashboardLayout } from "@/components/ui/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { ChatModal } from "@/components/chat-modal";
import { formatDistanceToNow } from "date-fns";
import {
  CheckCircle,
  Clock,
  AlertCircle,
  MessageSquare,
  Upload,
  FileText,
  Download,
  Search,
  Filter
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";

export default function WriterOrders() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedOrderId, setSelectedOrderId] = useState<number | null>(null);
  const [showSubmitDialog, setShowSubmitDialog] = useState(false);
  const [submittedWork, setSubmittedWork] = useState("");
  const [showChatModal, setShowChatModal] = useState(false);
  const [selectedClientId, setSelectedClientId] = useState<number | null>(null);
  const [selectedClientName, setSelectedClientName] = useState("");
  const [selectedOrderTitle, setSelectedOrderTitle] = useState("");

  // Fetch all orders
  const { data: orders = [], isLoading } = useQuery({
    queryKey: ["/api/orders"],
  });

  // Fetch clients for chat
  const { data: clients = [] } = useQuery({
    queryKey: ["/api/users"],
    select: (data) => data.filter((user: any) => user.role === "client"),
  });

  // Mutation for submitting completed work
  const submitWorkMutation = useMutation({
    mutationFn: async ({ id, work }: { id: number; work: string }) => {
      const response = await apiRequest(
        "PUT",
        `/api/orders/${id}/complete`,
        { submittedWork: work }
      );
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      toast({
        title: "Work submitted successfully",
        description: "Your work has been submitted to the client for review.",
      });
      setShowSubmitDialog(false);
    },
    onError: (error: any) => {
      toast({
        title: "Failed to submit work",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Filter orders based on status
  const inProgressOrders = orders.filter((order: any) => order.status === "in_progress");
  const completedOrders = orders.filter((order: any) => order.status === "completed");
  const disputedOrders = orders.filter((order: any) => order.status === "disputed");

  // Filter orders based on search query within current tab
  const filterOrdersBySearch = (orderList: any[]) => {
    if (!searchQuery) return orderList;
    
    return orderList.filter((order: any) => 
      order.id.toString().includes(searchQuery) || 
      (order.title && order.title.toLowerCase().includes(searchQuery.toLowerCase()))
    );
  };

  // Open chat with client
  const openChat = (orderId: number) => {
    const order = orders.find((o: any) => o.id === orderId);
    if (order) {
      const client = clients.find((c: any) => c.id === order.clientId);
      if (client) {
        setSelectedClientId(client.id);
        setSelectedClientName(client.fullName);
        setSelectedOrderId(orderId);
        setSelectedOrderTitle(order.title || `Order #${orderId}`);
        setShowChatModal(true);
      } else {
        toast({
          title: "Error",
          description: "Could not find client information",
          variant: "destructive",
        });
      }
    }
  };

  // Open submit work dialog
  const openSubmitDialog = (orderId: number) => {
    setSelectedOrderId(orderId);
    setSubmittedWork("");
    setShowSubmitDialog(true);
  };

  // Handle submit work
  const handleSubmitWork = () => {
    if (!selectedOrderId) return;
    
    if (!submittedWork.trim()) {
      toast({
        title: "Missing content",
        description: "Please provide the completed work",
        variant: "destructive",
      });
      return;
    }
    
    submitWorkMutation.mutate({
      id: selectedOrderId,
      work: submittedWork,
    });
  };

  // Get status badge based on order status
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "in_progress":
        return <span className="px-2 py-1 text-xs rounded-full bg-yellow-100 text-yellow-800">In Progress</span>;
      case "completed":
        return <span className="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800">Completed</span>;
      case "disputed":
        return <span className="px-2 py-1 text-xs rounded-full bg-red-100 text-red-800">Disputed</span>;
      default:
        return <span className="px-2 py-1 text-xs rounded-full bg-neutral-100 text-neutral-800">{status}</span>;
    }
  };

  return (
    <DashboardLayout title="My Orders">
      <div className="space-y-6">
        {/* Search and filter bar */}
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-grow">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-neutral-400" />
            </div>
            <Input
              type="text"
              placeholder="Search orders by ID or title..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button variant="outline" className="md:w-auto" disabled>
            <Filter className="h-4 w-4 mr-2" /> Filter
          </Button>
        </div>

        {/* Orders tabs */}
        <Tabs defaultValue="in-progress">
          <TabsList className="grid grid-cols-3 w-full md:w-auto">
            <TabsTrigger value="in-progress" className="flex items-center">
              <Clock className="h-4 w-4 mr-2" /> In Progress ({inProgressOrders.length})
            </TabsTrigger>
            <TabsTrigger value="completed" className="flex items-center">
              <CheckCircle className="h-4 w-4 mr-2" /> Completed ({completedOrders.length})
            </TabsTrigger>
            <TabsTrigger value="disputed" className="flex items-center">
              <AlertCircle className="h-4 w-4 mr-2" /> Disputed ({disputedOrders.length})
            </TabsTrigger>
          </TabsList>

          {/* In Progress Tab */}
          <TabsContent value="in-progress">
            {isLoading ? (
              <div className="flex justify-center items-center h-64">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
              </div>
            ) : filterOrdersBySearch(inProgressOrders).length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center h-64">
                  <p className="text-neutral-500">No in-progress orders found</p>
                  <p className="text-sm text-neutral-400 mt-2">
                    {searchQuery ? "Try adjusting your search query" : "Check available jobs to bid on new assignments"}
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 gap-6">
                {filterOrdersBySearch(inProgressOrders).map((order: any) => (
                  <Card key={order.id}>
                    <CardHeader className="pb-3">
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-lg">{order.title || `Order #${order.id}`}</CardTitle>
                          <CardDescription>
                            Order #{order.id} • Due {formatDistanceToNow(new Date(order.job?.deadline || new Date()))}
                          </CardDescription>
                        </div>
                        <div>{getStatusBadge(order.status)}</div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex flex-wrap gap-3">
                          <div className="bg-blue-50 text-blue-700 px-3 py-1.5 rounded-md text-xs flex items-center">
                            <FileText className="h-4 w-4 mr-1.5" />
                            ${order.bid?.amount || "N/A"}
                          </div>
                          <div className="bg-yellow-50 text-yellow-700 px-3 py-1.5 rounded-md text-xs flex items-center">
                            <Clock className="h-4 w-4 mr-1.5" />
                            Deadline: {new Date(order.job?.deadline || new Date()).toLocaleDateString()}
                          </div>
                        </div>
                        
                        <div className="flex flex-wrap md:flex-nowrap gap-2 mt-4">
                          <Button 
                            variant="outline" 
                            className="flex-1" 
                            onClick={() => openChat(order.id)}
                          >
                            <MessageSquare className="h-4 w-4 mr-2" /> Message Client
                          </Button>
                          <Button 
                            className="flex-1" 
                            onClick={() => openSubmitDialog(order.id)}
                          >
                            <Upload className="h-4 w-4 mr-2" /> Submit Work
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Completed Tab */}
          <TabsContent value="completed">
            {isLoading ? (
              <div className="flex justify-center items-center h-64">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
              </div>
            ) : filterOrdersBySearch(completedOrders).length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center h-64">
                  <p className="text-neutral-500">No completed orders found</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 gap-6">
                {filterOrdersBySearch(completedOrders).map((order: any) => (
                  <Card key={order.id}>
                    <CardHeader className="pb-3">
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-lg">{order.title || `Order #${order.id}`}</CardTitle>
                          <CardDescription>
                            Order #{order.id} • Completed {order.completedAt ? formatDistanceToNow(new Date(order.completedAt), { addSuffix: true }) : "recently"}
                          </CardDescription>
                        </div>
                        <div>{getStatusBadge(order.status)}</div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex flex-wrap gap-3">
                          <div className="bg-green-50 text-green-700 px-3 py-1.5 rounded-md text-xs flex items-center">
                            <FileText className="h-4 w-4 mr-1.5" />
                            Earned: ${order.bid?.amount || "N/A"}
                          </div>
                          {order.writerRating && (
                            <div className="bg-yellow-50 text-yellow-700 px-3 py-1.5 rounded-md text-xs flex items-center">
                              <svg className="h-4 w-4 mr-1.5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                              </svg>
                              Rating: {order.writerRating}/5
                            </div>
                          )}
                        </div>
                        
                        {order.clientReview && (
                          <div className="mt-4 bg-neutral-50 p-3 rounded-md">
                            <p className="text-sm font-medium mb-1">Client Review:</p>
                            <p className="text-sm text-neutral-600">{order.clientReview}</p>
                          </div>
                        )}
                        
                        <div className="flex flex-wrap md:flex-nowrap gap-2 mt-4">
                          <Button 
                            variant="outline" 
                            className="flex-1"
                            onClick={() => openChat(order.id)}
                          >
                            <MessageSquare className="h-4 w-4 mr-2" /> Message Client
                          </Button>
                          <Button 
                            variant="outline"
                            className="flex-1"
                            disabled={!order.submittedWork}
                          >
                            <Download className="h-4 w-4 mr-2" /> Download Submission
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Disputed Tab */}
          <TabsContent value="disputed">
            {isLoading ? (
              <div className="flex justify-center items-center h-64">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
              </div>
            ) : filterOrdersBySearch(disputedOrders).length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center h-64">
                  <p className="text-neutral-500">No disputed orders found</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 gap-6">
                {filterOrdersBySearch(disputedOrders).map((order: any) => (
                  <Card key={order.id}>
                    <CardHeader className="pb-3 border-b border-red-100">
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-lg">{order.title || `Order #${order.id}`}</CardTitle>
                          <CardDescription>
                            Order #{order.id} • Dispute opened {formatDistanceToNow(new Date(order.dispute?.createdAt || new Date()), { addSuffix: true })}
                          </CardDescription>
                        </div>
                        <div>{getStatusBadge(order.status)}</div>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-4">
                      <div className="space-y-4">
                        <div className="bg-red-50 p-4 rounded-md">
                          <h4 className="text-sm font-medium text-red-800 mb-1">Dispute Reason:</h4>
                          <p className="text-sm text-red-700">{order.dispute?.reason || "No reason provided"}</p>
                          <p className="text-sm text-red-600 mt-2">{order.dispute?.description || ""}</p>
                        </div>
                        
                        <Button 
                          variant="outline" 
                          className="w-full"
                          onClick={() => openChat(order.id)}
                        >
                          <MessageSquare className="h-4 w-4 mr-2" /> Contact Client
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>

        {/* Submit work dialog */}
        <Dialog open={showSubmitDialog} onOpenChange={setShowSubmitDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Submit Completed Work</DialogTitle>
              <DialogDescription>
                Provide your completed work for the client to review. You can include text content, links to external documents, or instructions.
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-2">
              <Textarea
                placeholder="Paste your work here or provide links to your documents..."
                value={submittedWork}
                onChange={(e) => setSubmittedWork(e.target.value)}
                className="min-h-[200px]"
              />
              <p className="text-sm text-neutral-500">
                Tip: For large documents, consider uploading to Google Drive or Dropbox and sharing the link here.
              </p>
            </div>
            
            <DialogFooter>
              <Button 
                variant="outline" 
                onClick={() => setShowSubmitDialog(false)}
              >
                Cancel
              </Button>
              <Button 
                onClick={handleSubmitWork}
                disabled={submitWorkMutation.isPending}
              >
                {submitWorkMutation.isPending ? "Submitting..." : "Submit Work"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Chat modal */}
        {showChatModal && selectedClientId && (
          <ChatModal
            recipientId={selectedClientId}
            recipientName={selectedClientName}
            recipientAvatar={`https://ui-avatars.com/api/?name=${encodeURIComponent(selectedClientName)}&background=22C55E&color=fff`}
            orderId={selectedOrderId || undefined}
            orderTitle={selectedOrderTitle}
            onClose={() => setShowChatModal(false)}
          />
        )}
      </div>
    </DashboardLayout>
  );
}
