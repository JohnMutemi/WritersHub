import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { 
  DollarSign, 
  CheckCircle, 
  Star, 
  FileText, 
  Briefcase, 
  Clock, 
  Calendar, 
  ArrowUpRight, 
  ExternalLink, 
  Send, 
  Download,
  Bell
} from "lucide-react";
import { StatCard } from "@/components/ui/stat-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter, CardDescription } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { formatDistanceToNow } from "date-fns";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { InsertBid } from "@shared/schema";
import { DashboardLayout } from "@/components/ui/dashboard-layout";

interface BidDialogProps {
  jobId: number;
  jobTitle: string;
  jobBudget: number;
  jobDeadline: string;
  isOpen: boolean;
  onClose: () => void;
}

function BidDialog({ jobId, jobTitle, jobBudget, jobDeadline, isOpen, onClose }: BidDialogProps) {
  const { toast } = useToast();
  const [bidAmount, setBidAmount] = useState<number>(jobBudget);
  const [deliveryDate, setDeliveryDate] = useState<string>(
    new Date(jobDeadline).toISOString().split("T")[0]
  );
  const [message, setMessage] = useState<string>("");

  const createBidMutation = useMutation({
    mutationFn: async (bidData: Partial<InsertBid>) => {
      const res = await apiRequest("POST", `/api/jobs/${jobId}/bids`, bidData);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Bid submitted successfully",
        description: "Your bid has been sent to the client for review",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to submit bid",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createBidMutation.mutate({
      amount: bidAmount,
      deliveryDate: deliveryDate, // Send as string, schema will convert
      message,
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Place a Bid</DialogTitle>
          <DialogDescription>
            You're bidding on: <span className="font-semibold">{jobTitle}</span>
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="amount">Your Bid (USD)</Label>
              <Input
                id="amount"
                type="number"
                step="0.01"
                min="1"
                max={jobBudget * 1.5}
                value={bidAmount}
                onChange={(e) => setBidAmount(parseFloat(e.target.value))}
                required
              />
              <p className="text-xs text-muted-foreground">Client's budget: ${jobBudget}</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="deliveryDate">Delivery Date</Label>
              <Input
                id="deliveryDate"
                type="date"
                value={deliveryDate}
                onChange={(e) => setDeliveryDate(e.target.value)}
                min={new Date().toISOString().split("T")[0]}
                max={new Date(jobDeadline).toISOString().split("T")[0]}
                required
              />
              <p className="text-xs text-muted-foreground">
                Client's deadline: {new Date(jobDeadline).toLocaleDateString()}
              </p>
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="message">Cover Message</Label>
            <Textarea
              id="message"
              placeholder="Explain why you're the best writer for this job..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={4}
              required
            />
          </div>
          <DialogFooter>
            <Button variant="outline" type="button" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={createBidMutation.isPending}>
              {createBidMutation.isPending ? "Submitting..." : "Submit Bid"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

interface WithdrawDialogProps {
  isOpen: boolean;
  onClose: () => void;
  currentBalance: number;
}

function WithdrawDialog({ isOpen, onClose, currentBalance }: WithdrawDialogProps) {
  const { toast } = useToast();
  const [amount, setAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<string>("paypal");
  const [accountInfo, setAccountInfo] = useState<string>("");

  const withdrawMutation = useMutation({
    mutationFn: async (withdrawData: any) => {
      const res = await apiRequest("POST", `/api/transactions/withdraw`, withdrawData);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Withdrawal request submitted",
        description: "Your funds will be processed shortly",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to withdraw funds",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (amount <= 0) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid withdrawal amount",
        variant: "destructive",
      });
      return;
    }
    
    if (amount > currentBalance) {
      toast({
        title: "Insufficient balance",
        description: "You cannot withdraw more than your available balance",
        variant: "destructive",
      });
      return;
    }
    
    withdrawMutation.mutate({
      amount,
      paymentMethod,
      accountInfo
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Withdraw Funds</DialogTitle>
          <DialogDescription>
            Your current balance: <span className="font-semibold">${currentBalance.toFixed(2)}</span>
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="amount">Amount to Withdraw (USD)</Label>
            <Input
              id="amount"
              type="number"
              step="0.01"
              min="1"
              max={currentBalance}
              value={amount}
              onChange={(e) => setAmount(parseFloat(e.target.value) || 0)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="paymentMethod">Payment Method</Label>
            <select
              id="paymentMethod"
              className="w-full p-2 border rounded-md"
              value={paymentMethod}
              onChange={(e) => setPaymentMethod(e.target.value)}
              required
            >
              <option value="paypal">PayPal</option>
              <option value="bank">Bank Transfer</option>
              <option value="mpesa">M-Pesa</option>
            </select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="accountInfo">
              {paymentMethod === "paypal" ? "PayPal Email" : 
               paymentMethod === "bank" ? "Bank Account Details" : 
               "M-Pesa Phone Number"}
            </Label>
            <Textarea
              id="accountInfo"
              placeholder={
                paymentMethod === "paypal" ? "Enter your PayPal email" :
                paymentMethod === "bank" ? "Enter your bank account details" :
                "Enter your M-Pesa phone number"
              }
              value={accountInfo}
              onChange={(e) => setAccountInfo(e.target.value)}
              rows={2}
              required
            />
          </div>
          <DialogFooter>
            <Button variant="outline" type="button" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={withdrawMutation.isPending}>
              {withdrawMutation.isPending ? "Processing..." : "Withdraw Funds"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function WriterDashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedJob, setSelectedJob] = useState<any>(null);
  const [isBidDialogOpen, setIsBidDialogOpen] = useState(false);
  const [isWithdrawDialogOpen, setIsWithdrawDialogOpen] = useState(false);

  // Fetch writer stats
  const { data: stats, isLoading: isLoadingStats } = useQuery({
    queryKey: ["/api/stats"],
    enabled: !!user,
  });

  // Fetch in-progress orders
  const { data: orders = [], isLoading: isLoadingOrders } = useQuery({
    queryKey: ["/api/orders"],
    enabled: !!user,
  });

  // Fetch available jobs
  const { data: jobs = [], isLoading: isLoadingJobs } = useQuery({
    queryKey: ["/api/jobs"],
    enabled: !!user,
  });

  // Fetch my bids
  const { data: myBids = [], isLoading: isLoadingBids } = useQuery({
    queryKey: ["/api/writers/bids"],
    enabled: !!user,
  });

  // Fetch notifications for recent activity
  const { data: notifications = [], isLoading: isLoadingNotifications } = useQuery({
    queryKey: ["/api/notifications"],
    enabled: !!user,
  });

  // Filter active orders
  const activeOrders = orders.filter((order: any) => order.status === "in_progress").slice(0, 3);
  
  // Get available jobs (limit to 3)
  const availableJobs = jobs.slice(0, 3);

  // Get pending bids (limit to 3)
  const pendingBids = myBids
    .filter((bid: any) => bid.status === "pending")
    .slice(0, 3);

  // Get recent activity from notifications (limit to 4)
  const recentActivity = notifications.slice(0, 4);

  const openBidDialog = (job: any) => {
    setSelectedJob(job);
    setIsBidDialogOpen(true);
  };

  const completeMutation = useMutation({
    mutationFn: async ({ orderId, submittedWork }: { orderId: number, submittedWork: string }) => {
      const res = await apiRequest("PUT", `/api/orders/${orderId}/complete`, { submittedWork });
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Order completed successfully",
        description: "The client will be notified to review your work",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to complete order",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleCompleteOrder = (orderId: number) => {
    // In a real implementation, this would include a form for the submittedWork
    // For this demo, we're simplifying with a direct mutation
    const submittedWork = "https://example.com/completed-work.pdf";
    
    completeMutation.mutate({
      orderId,
      submittedWork,
    });
  };

  return (
    <DashboardLayout title="Writer Dashboard">
      <div className="space-y-6">
      {/* Quick Stats Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        <StatCard
          label="Orders in Progress"
          value={isLoadingStats ? "..." : stats?.ordersInProgress || 0}
          icon={<FileText className="h-5 w-5" />}
          change={stats?.ordersChange || "+2 this week"}
          changeType="positive"
        />
        <StatCard
          label="Completed Orders"
          value={isLoadingStats ? "..." : stats?.completedOrders || 0}
          icon={<CheckCircle className="h-5 w-5" />}
          change={stats?.completedOrdersChange || "+5 this month"}
          changeType="positive"
        />
        <StatCard
          label="Current Rating"
          value={isLoadingStats ? "..." : `${stats?.rating?.toFixed(1) || 0}/5`}
          icon={<Star className="h-5 w-5" />}
          change={stats?.ratingChange || "Stable"}
          changeType="neutral"
        />
        <StatCard
          label="Available Balance"
          value={isLoadingStats ? "..." : `$${stats?.earnings?.toFixed(2) || 0}`}
          icon={<DollarSign className="h-5 w-5" />}
          change={stats?.earningsChange || "+$240 this month"}
          changeType="positive"
          action={
            <Button 
              size="sm" 
              variant="outline" 
              className="mt-2"
              onClick={() => setIsWithdrawDialogOpen(true)}
            >
              Withdraw
            </Button>
          }
        />
      </div>

      {/* Orders in Progress & Pending Bids */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Orders in Progress */}
        <Card>
          <CardHeader className="px-5 py-4 border-b border-neutral-200 flex flex-row items-center justify-between">
            <CardTitle className="text-lg font-semibold">Orders in Progress</CardTitle>
            <Link href="/orders">
              <Button variant="ghost" className="text-primary-600 text-sm hover:text-primary-700">
                View All
              </Button>
            </Link>
          </CardHeader>
          <CardContent className="p-0">
            {isLoadingOrders ? (
              <div className="flex justify-center items-center h-48">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : activeOrders.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-48 text-neutral-500">
                <p>No orders in progress</p>
                <Link href="/jobs">
                  <Button variant="link" className="mt-2">Browse available jobs</Button>
                </Link>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-neutral-200">
                  <thead className="bg-neutral-50">
                    <tr>
                      <th scope="col" className="px-5 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Order</th>
                      <th scope="col" className="px-5 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Deadline</th>
                      <th scope="col" className="px-5 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Client</th>
                      <th scope="col" className="px-5 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-neutral-200">
                    {activeOrders.map((order: any) => (
                      <tr key={order.id} className="hover:bg-neutral-50">
                        <td className="px-5 py-4 whitespace-nowrap text-sm text-neutral-600">
                          <Link href={`/orders/${order.id}`} className="hover:text-primary-600 font-medium">
                            {order.title || `Order #${order.id}`}
                          </Link>
                          <div className="text-xs text-neutral-500 mt-1">#{order.id}</div>
                        </td>
                        <td className="px-5 py-4 whitespace-nowrap text-sm text-neutral-600">
                          <div className="flex items-center">
                            <Calendar className="h-4 w-4 mr-1 text-neutral-400" />
                            <span>{new Date(order.deadline).toLocaleDateString()}</span>
                          </div>
                          <div className="text-xs text-neutral-500 mt-1 ml-5">
                            {formatDistanceToNow(new Date(order.deadline), { addSuffix: true })}
                          </div>
                        </td>
                        <td className="px-5 py-4 whitespace-nowrap text-sm text-neutral-600">
                          <div className="flex items-center">
                            <img 
                              src={order.client?.profilePicture || `https://ui-avatars.com/api/?name=${encodeURIComponent(order.client?.fullName || "Client")}&background=0D8ABC&color=fff`} 
                              alt={order.client?.fullName || "Client"} 
                              className="w-6 h-6 rounded-full mr-2" 
                            />
                            {order.client?.fullName || "Client"}
                          </div>
                        </td>
                        <td className="px-5 py-4 whitespace-nowrap">
                          <div className="flex space-x-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleCompleteOrder(order.id)}
                              disabled={completeMutation.isPending}
                            >
                              {completeMutation.isPending ? 
                                "Submitting..." : 
                                <><Send className="h-4 w-4 mr-1" /> Submit</>
                              }
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Pending Bids */}
        <Card>
          <CardHeader className="px-5 py-4 border-b border-neutral-200 flex flex-row items-center justify-between">
            <CardTitle className="text-lg font-semibold">My Pending Bids</CardTitle>
            <Link href="/bids">
              <Button variant="ghost" className="text-primary-600 text-sm hover:text-primary-700">
                View All
              </Button>
            </Link>
          </CardHeader>
          <CardContent className="p-0">
            {isLoadingBids ? (
              <div className="flex justify-center items-center h-48">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : pendingBids.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-48 text-neutral-500">
                <p>No pending bids</p>
                <Link href="/jobs">
                  <Button variant="link" className="mt-2">Find jobs to bid on</Button>
                </Link>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-neutral-200">
                  <thead className="bg-neutral-50">
                    <tr>
                      <th scope="col" className="px-5 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Job</th>
                      <th scope="col" className="px-5 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Bid Amount</th>
                      <th scope="col" className="px-5 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Your Delivery</th>
                      <th scope="col" className="px-5 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Status</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-neutral-200">
                    {pendingBids.map((bid: any) => (
                      <tr key={bid.id} className="hover:bg-neutral-50">
                        <td className="px-5 py-4 text-sm text-neutral-600">
                          <Link href={`/jobs/${bid.jobId}`} className="hover:text-primary-600 font-medium">
                            {bid.job?.title || `Job #${bid.jobId}`}
                          </Link>
                          <div className="text-xs text-neutral-500 mt-1">Client: {bid.job?.client?.fullName || "Client"}</div>
                        </td>
                        <td className="px-5 py-4 whitespace-nowrap text-sm font-medium text-neutral-800">
                          ${bid.amount.toFixed(2)}
                        </td>
                        <td className="px-5 py-4 whitespace-nowrap text-sm text-neutral-600">
                          <div className="flex items-center">
                            <Clock className="h-4 w-4 mr-1 text-neutral-400" />
                            {new Date(bid.deliveryDate).toLocaleDateString()}
                          </div>
                        </td>
                        <td className="px-5 py-4 whitespace-nowrap">
                          <Badge variant="outline" className="bg-blue-100 text-blue-800 hover:bg-blue-100">
                            Pending
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Available Jobs - Full Width */}
      <div className="mb-6">
        {/* Available Jobs */}
        <Card>
          <CardHeader className="px-5 py-4 border-b border-neutral-200 flex flex-row items-center justify-between">
            <CardTitle className="text-lg font-semibold">Available Jobs</CardTitle>
            <div className="flex items-center gap-4">
              <Link href="/activity">
                <Button variant="outline" size="sm" className="text-sm">
                  <Bell className="h-4 w-4 mr-1" /> Recent Activity
                </Button>
              </Link>
              <Link href="/jobs">
                <Button variant="ghost" className="text-primary-600 text-sm hover:text-primary-700">
                  View All Jobs
                </Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {isLoadingJobs ? (
              <div className="flex justify-center items-center h-48">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : availableJobs.length === 0 ? (
              <div className="flex items-center justify-center h-48 text-neutral-500">
                <p>No available jobs found</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-neutral-200">
                  <thead className="bg-neutral-50">
                    <tr>
                      <th scope="col" className="px-5 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Title</th>
                      <th scope="col" className="px-5 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Subject</th>
                      <th scope="col" className="px-5 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Details</th>
                      <th scope="col" className="px-5 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Budget</th>
                      <th scope="col" className="px-5 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Deadline</th>
                      <th scope="col" className="px-5 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Action</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-neutral-200">
                    {availableJobs.map((job: any) => {
                      // Check if the writer has already bid on this job
                      const hasBid = myBids.some((bid: any) => bid.jobId === job.id);
                      
                      return (
                        <tr key={job.id} className="hover:bg-neutral-50">
                          <td className="px-5 py-4 text-sm text-neutral-600">
                            <Link href={`/jobs/${job.id}`} className="hover:text-primary-600 font-medium">
                              {job.title}
                            </Link>
                          </td>
                          <td className="px-5 py-4 whitespace-nowrap text-sm text-neutral-600">{job.subject}</td>
                          <td className="px-5 py-4 whitespace-nowrap text-sm text-neutral-600">
                            <div className="flex flex-col text-xs">
                              <span>{job.pages} pages / {job.wordCount} words</span>
                              <span>Level: {job.academicLevel}</span>
                            </div>
                          </td>
                          <td className="px-5 py-4 whitespace-nowrap text-sm font-medium text-neutral-800">${job.budget}</td>
                          <td className="px-5 py-4 whitespace-nowrap text-sm text-neutral-600">
                            {new Date(job.deadline).toLocaleDateString()}
                          </td>
                          <td className="px-5 py-4 whitespace-nowrap">
                            {hasBid ? (
                              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                                Bid Placed
                              </Badge>
                            ) : (
                              <Button 
                                size="sm" 
                                onClick={() => openBidDialog(job)}
                              >
                                Place Bid
                              </Button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
          <div className="p-4 border-t border-neutral-200 text-center">
            <Link href="/jobs">
              <Button>Browse All Available Jobs</Button>
            </Link>
          </div>
        </Card>
      </div>

      {/* Earnings Overview */}
      <Card>
        <CardHeader className="px-5 py-4 border-b border-neutral-200">
          <CardTitle className="text-lg font-semibold">Earnings Overview</CardTitle>
          <CardDescription>Your earnings in the last 30 days</CardDescription>
        </CardHeader>
        <CardContent className="p-5">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-neutral-50 p-4 rounded-lg">
              <div className="text-sm text-neutral-500 mb-1">Total Earned</div>
              <div className="text-2xl font-bold">${isLoadingStats ? "..." : stats?.monthlyEarnings?.toFixed(2) || "0.00"}</div>
              <div className="text-xs text-green-600 mt-1">+12.5% from last month</div>
            </div>
            <div className="bg-neutral-50 p-4 rounded-lg">
              <div className="text-sm text-neutral-500 mb-1">Pending Payments</div>
              <div className="text-2xl font-bold">${isLoadingStats ? "..." : stats?.pendingPayments?.toFixed(2) || "0.00"}</div>
              <div className="text-xs text-yellow-600 mt-1">From 3 completed orders</div>
            </div>
            <div className="bg-neutral-50 p-4 rounded-lg">
              <div className="text-sm text-neutral-500 mb-1">Available for Withdrawal</div>
              <div className="text-2xl font-bold">${isLoadingStats ? "..." : stats?.earnings?.toFixed(2) || "0.00"}</div>
              <Button 
                size="sm" 
                variant="outline" 
                className="mt-2"
                onClick={() => setIsWithdrawDialogOpen(true)}
              >
                Withdraw Funds
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Bid Dialog */}
      {selectedJob && (
        <BidDialog
          jobId={selectedJob.id}
          jobTitle={selectedJob.title}
          jobBudget={selectedJob.budget}
          jobDeadline={selectedJob.deadline}
          isOpen={isBidDialogOpen}
          onClose={() => setIsBidDialogOpen(false)}
        />
      )}

      {/* Withdraw Dialog */}
      <WithdrawDialog
        isOpen={isWithdrawDialogOpen}
        onClose={() => setIsWithdrawDialogOpen(false)}
        currentBalance={stats?.earnings || 0}
      />
    </div>
    </DashboardLayout>
  );
}
