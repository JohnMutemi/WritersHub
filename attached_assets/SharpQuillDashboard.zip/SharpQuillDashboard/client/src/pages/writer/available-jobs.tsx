import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { DashboardLayout } from "@/components/ui/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { insertBidSchema } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";
import { Search, Filter, Calendar, DollarSign } from "lucide-react";

export default function AvailableJobs() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedJobId, setSelectedJobId] = useState<number | null>(null);
  const [showBidDialog, setShowBidDialog] = useState(false);

  // Fetch available jobs
  const { data: jobs = [], isLoading } = useQuery({
    queryKey: ["/api/jobs"],
  });

  // Mutation for placing a bid
  const bidMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest(
        "POST", 
        `/api/jobs/${selectedJobId}/bids`, 
        data
      );
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
      toast({
        title: "Bid placed successfully",
        description: "Your bid has been submitted.",
      });
      setShowBidDialog(false);
    },
    onError: (error: any) => {
      toast({
        title: "Failed to place bid",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Define bid form schema
  const bidFormSchema = z.object({
    amount: z.coerce.number().positive("Bid amount must be positive"),
    deliveryDate: z.string().min(1, "Delivery date is required"),
    message: z.string().min(10, "Message must be at least 10 characters"),
  });

  // Initialize form
  const form = useForm<z.infer<typeof bidFormSchema>>({
    resolver: zodResolver(bidFormSchema),
    defaultValues: {
      amount: 0,
      deliveryDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 7 days from now
      message: "",
    },
  });

  // Open bid dialog for a job
  const openBidDialog = (jobId: number) => {
    const job = jobs.find((j: any) => j.id === jobId);
    
    if (job) {
      setSelectedJobId(jobId);
      form.setValue("amount", job.budget);
      form.setValue("deliveryDate", new Date(job.deadline).toISOString().split('T')[0]);
      setShowBidDialog(true);
    }
  };

  // Handle bid form submission
  const onSubmitBid = (data: z.infer<typeof bidFormSchema>) => {
    bidMutation.mutate({
      ...data,
      deliveryDate: data.deliveryDate // Just send the date string, the schema will handle conversion
    });
  };

  // Filter jobs based on search query
  const filteredJobs = jobs.filter((job: any) => 
    job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    job.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
    job.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <DashboardLayout title="Available Jobs">
      <div className="space-y-6">
        {/* Search and filter bar */}
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-grow">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-neutral-400" />
            </div>
            <Input
              type="text"
              placeholder="Search jobs..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button variant="outline" className="md:w-auto" disabled>
            <Filter className="h-4 w-4 mr-2" /> Filter
          </Button>
        </div>

        {/* Job listings */}
        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          </div>
        ) : filteredJobs.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center h-64">
              <p className="text-neutral-500">No available jobs found</p>
              <p className="text-sm text-neutral-400 mt-2">Try adjusting your search query</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 gap-6">
            {filteredJobs.map((job: any) => (
              <Card key={job.id} className="overflow-hidden">
                <CardHeader className="bg-white border-b border-neutral-100 py-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg font-semibold">
                        <Link href={`/jobs/${job.id}`} className="hover:text-primary-600">
                          {job.title}
                        </Link>
                      </CardTitle>
                      <div className="mt-1 flex items-center text-sm text-neutral-500">
                        <span className="bg-neutral-100 px-2 py-0.5 rounded-full text-xs mr-2">
                          {job.subject}
                        </span>
                        <span className="text-xs">
                          Posted {formatDistanceToNow(new Date(job.createdAt), { addSuffix: true })}
                        </span>
                      </div>
                    </div>
                    <div className="flex flex-col items-end">
                      <div className="flex items-center text-green-600 font-medium">
                        <DollarSign className="h-4 w-4 mr-1" />
                        <span>${job.budget}</span>
                      </div>
                      <div className="flex items-center text-orange-600 text-sm mt-1">
                        <Calendar className="h-4 w-4 mr-1" />
                        <span>Due {formatDistanceToNow(new Date(job.deadline))}</span>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="py-4">
                  <div className="mb-4">
                    <p className="text-neutral-600 line-clamp-3">{job.description}</p>
                  </div>
                  <div className="flex flex-wrap gap-2 mb-4">
                    <div className="bg-blue-50 text-blue-700 px-2 py-1 rounded-md text-xs flex items-center">
                      <span className="font-medium mr-1">Pages:</span> {job.pages}
                    </div>
                    <div className="bg-purple-50 text-purple-700 px-2 py-1 rounded-md text-xs flex items-center">
                      <span className="font-medium mr-1">Words:</span> {job.wordCount}
                    </div>
                    <div className="bg-amber-50 text-amber-700 px-2 py-1 rounded-md text-xs flex items-center">
                      <span className="font-medium mr-1">Level:</span> {job.academicLevel}
                    </div>
                    {job.citationStyle && (
                      <div className="bg-teal-50 text-teal-700 px-2 py-1 rounded-md text-xs flex items-center">
                        <span className="font-medium mr-1">Citation:</span> {job.citationStyle}
                      </div>
                    )}
                  </div>
                  <div className="flex justify-end">
                    <Button onClick={() => openBidDialog(job.id)}>
                      Place Bid
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Bid dialog */}
        <Dialog open={showBidDialog} onOpenChange={setShowBidDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Place a Bid</DialogTitle>
              <DialogDescription>
                Submit your proposal for this job. Make sure to provide a competitive price and realistic delivery date.
              </DialogDescription>
            </DialogHeader>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmitBid)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="amount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Bid Amount ($)</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <DollarSign className="h-5 w-5 text-neutral-400" />
                          </div>
                          <Input type="number" step="0.01" className="pl-10" {...field} />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="deliveryDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Delivery Date</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Cover Message</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Describe why you're the best fit for this job..."
                          className="min-h-[120px]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <DialogFooter>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setShowBidDialog(false)}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit"
                    disabled={bidMutation.isPending}
                  >
                    {bidMutation.isPending ? "Submitting..." : "Submit Bid"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
