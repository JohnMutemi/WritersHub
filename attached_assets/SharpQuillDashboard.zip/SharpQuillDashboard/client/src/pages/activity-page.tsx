import { useQuery } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";
import { DashboardLayout } from "@/components/ui/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  FileText,
  DollarSign,
  Briefcase,
  Star,
  CheckCircle,
  ExternalLink,
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";

export default function ActivityPage() {
  const { user } = useAuth();

  // Fetch notifications for recent activity
  const { data: notifications = [], isLoading: isLoadingNotifications } = useQuery({
    queryKey: ["/api/notifications"],
    enabled: !!user,
  });

  return (
    <DashboardLayout title="Recent Activity">
      <div className="space-y-6">
        <Card>
          <CardHeader className="border-b border-neutral-200">
            <CardTitle className="text-xl font-semibold">All Activity</CardTitle>
          </CardHeader>
          <CardContent className="p-5">
            {isLoadingNotifications ? (
              <div className="flex justify-center items-center h-64">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : notifications.length === 0 ? (
              <div className="flex items-center justify-center h-64 text-neutral-500">
                <p>No activity found</p>
              </div>
            ) : (
              <div className="flow-root">
                <ul className="-mb-8">
                  {notifications.map((activity: any, index: number) => (
                    <li key={activity.id}>
                      <div className="relative pb-8">
                        {index < notifications.length - 1 && (
                          <span className="absolute top-5 left-5 -ml-px h-full w-0.5 bg-neutral-200" aria-hidden="true"></span>
                        )}
                        <div className="relative flex items-start space-x-3">
                          <div className="relative">
                            <div className="h-10 w-10 rounded-full bg-primary-50 flex items-center justify-center ring-8 ring-white">
                              {activity.type.includes('order') ? (
                                <FileText className="h-5 w-5 text-primary-500" />
                              ) : activity.type.includes('payment') ? (
                                <DollarSign className="h-5 w-5 text-green-500" />
                              ) : activity.type.includes('bid') ? (
                                <Briefcase className="h-5 w-5 text-blue-500" />
                              ) : activity.type.includes('rating') ? (
                                <Star className="h-5 w-5 text-yellow-500" />
                              ) : (
                                <CheckCircle className="h-5 w-5 text-green-500" />
                              )}
                            </div>
                          </div>
                          <div className="min-w-0 flex-1">
                            <div>
                              <div className="text-sm text-neutral-800">
                                {activity.message}
                              </div>
                              <p className="mt-0.5 text-sm text-neutral-500">
                                {formatDistanceToNow(new Date(activity.createdAt), { addSuffix: true })}
                              </p>
                              {activity.relatedId && (
                                <div className="mt-2">
                                  <Button variant="outline" size="sm" className="text-xs">
                                    <ExternalLink className="h-3 w-3 mr-1" />
                                    {activity.type.includes('order') ? "View Order" :
                                     activity.type.includes('bid') ? "View Bid" :
                                     activity.type.includes('payment') ? "View Payment" :
                                     "View Details"}
                                  </Button>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}