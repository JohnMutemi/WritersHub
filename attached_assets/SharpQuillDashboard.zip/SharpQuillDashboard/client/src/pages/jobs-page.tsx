import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { DashboardLayout } from "@/components/ui/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { InsertBid } from "@shared/schema";

interface BidDialogProps {
  jobId: number;
  jobTitle: string;
  jobBudget: number;
  jobDeadline: string;
  isOpen: boolean;
  onClose: () => void;
}

function BidDialog({ jobId, jobTitle, jobBudget, jobDeadline, isOpen, onClose }: BidDialogProps) {
  const { toast } = useToast();
  const [bidAmount, setBidAmount] = useState<number>(jobBudget);
  const [deliveryDate, setDeliveryDate] = useState<string>(
    new Date(jobDeadline).toISOString().split("T")[0]
  );
  const [message, setMessage] = useState<string>("");

  const createBidMutation = useMutation({
    mutationFn: async (bidData: Partial<InsertBid>) => {
      const res = await apiRequest("POST", `/api/jobs/${jobId}/bids`, bidData);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Bid submitted successfully",
        description: "Your bid has been sent to the client for review",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to submit bid",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createBidMutation.mutate({
      amount: bidAmount,
      deliveryDate: deliveryDate, // Send as string, schema will convert
      message,
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Place a Bid</DialogTitle>
          <DialogDescription>
            You're bidding on: <span className="font-semibold">{jobTitle}</span>
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="amount">Your Bid (USD)</Label>
              <Input
                id="amount"
                type="number"
                step="0.01"
                min="1"
                max={jobBudget * 1.5}
                value={bidAmount}
                onChange={(e) => setBidAmount(parseFloat(e.target.value))}
                required
              />
              <p className="text-xs text-muted-foreground">Client's budget: ${jobBudget}</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="deliveryDate">Delivery Date</Label>
              <Input
                id="deliveryDate"
                type="date"
                value={deliveryDate}
                onChange={(e) => setDeliveryDate(e.target.value)}
                min={new Date().toISOString().split("T")[0]}
                max={new Date(jobDeadline).toISOString().split("T")[0]}
                required
              />
              <p className="text-xs text-muted-foreground">
                Client's deadline: {new Date(jobDeadline).toLocaleDateString()}
              </p>
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="message">Cover Message</Label>
            <Textarea
              id="message"
              placeholder="Explain why you're the best writer for this job..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={4}
              required
            />
          </div>
          <DialogFooter>
            <Button variant="outline" type="button" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={createBidMutation.isPending}>
              {createBidMutation.isPending ? "Submitting..." : "Submit Bid"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function JobsPage() {
  const { user } = useAuth();
  const [selectedJob, setSelectedJob] = useState<any>(null);
  const [isBidDialogOpen, setIsBidDialogOpen] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [filterType, setFilterType] = useState<string>("all");

  // Fetch available jobs
  const { data: jobs = [], isLoading } = useQuery({
    queryKey: ["/api/jobs"],
    enabled: !!user,
  });

  // Fetch my bids for filtering jobs I've already bid on
  const { data: myBids = [] } = useQuery({
    queryKey: ["/api/writers/bids"],
    enabled: !!user?.role === "writer",
  });

  const openBidDialog = (job: any) => {
    setSelectedJob(job);
    setIsBidDialogOpen(true);
  };

  // Filter jobs based on search and filters
  const filteredJobs = jobs.filter((job: any) => {
    const matchesSearch = searchQuery 
      ? job.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
        job.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        job.subject.toLowerCase().includes(searchQuery.toLowerCase())
      : true;

    if (filterType === "all") return matchesSearch;
    if (filterType === "unbidded") {
      // Show only jobs I haven't bid on yet
      const alreadyBid = myBids.some((bid: any) => bid.jobId === job.id);
      return matchesSearch && !alreadyBid;
    }

    return matchesSearch;
  });

  return (
    <DashboardLayout title="Available Jobs">
      <div className="space-y-6">
        {/* Search and Filters */}
        <div className="flex flex-col md:flex-row items-start md:items-center gap-4 mb-6">
          <div className="w-full md:w-1/3">
            <Input
              placeholder="Search jobs..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full"
            />
          </div>
          <div className="flex items-center space-x-2">
            <Button 
              variant={filterType === "all" ? "default" : "outline"}
              onClick={() => setFilterType("all")}
              size="sm"
            >
              All Jobs
            </Button>
            {user?.role === "writer" && (
              <Button 
                variant={filterType === "unbidded" ? "default" : "outline"}
                onClick={() => setFilterType("unbidded")}
                size="sm"
              >
                Not Bid Yet
              </Button>
            )}
          </div>
        </div>

        {/* Jobs List */}
        <Card>
          <CardHeader className="px-6 py-4 border-b border-neutral-200">
            <CardTitle className="text-xl font-semibold">Jobs ({filteredJobs.length})</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {isLoading ? (
              <div className="flex justify-center items-center h-64">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : filteredJobs.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-64 text-neutral-500">
                <p className="mb-2">No jobs match your criteria</p>
                {searchQuery && (
                  <Button variant="outline" onClick={() => setSearchQuery("")}>
                    Clear Search
                  </Button>
                )}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full divide-y divide-neutral-200">
                  <thead className="bg-neutral-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Title</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Subject</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Details</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Budget</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Deadline</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Action</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-neutral-200">
                    {filteredJobs.map((job: any) => {
                      const hasBid = myBids.some((bid: any) => bid.jobId === job.id);
                      
                      return (
                        <tr key={job.id} className="hover:bg-neutral-50">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <Link href={`/jobs/${job.id}`} className="text-primary-600 hover:text-primary-700 font-medium">
                              {job.title}
                            </Link>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                            {job.subject}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                            <div className="flex flex-col">
                              <span>Pages: {job.pages}</span>
                              <span>Words: {job.wordCount}</span>
                              <span>Level: {job.academicLevel}</span>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-neutral-800">
                            ${job.budget}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                            {new Date(job.deadline).toLocaleDateString()}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-right">
                            {user?.role === "writer" ? (
                              hasBid ? (
                                <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                                  Bid Placed
                                </Badge>
                              ) : (
                                <Button size="sm" onClick={() => openBidDialog(job)}>
                                  Place Bid
                                </Button>
                              )
                            ) : (
                              <Link href={`/jobs/${job.id}`}>
                                <Button size="sm" variant="outline">
                                  View Details
                                </Button>
                              </Link>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Bid Dialog */}
        {selectedJob && (
          <BidDialog
            jobId={selectedJob.id}
            jobTitle={selectedJob.title}
            jobBudget={selectedJob.budget}
            jobDeadline={selectedJob.deadline}
            isOpen={isBidDialogOpen}
            onClose={() => setIsBidDialogOpen(false)}
          />
        )}
      </div>
    </DashboardLayout>
  );
}