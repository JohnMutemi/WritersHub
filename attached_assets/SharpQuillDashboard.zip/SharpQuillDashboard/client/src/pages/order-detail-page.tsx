import { useState } from "react";
import { useRoute } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { DashboardLayout } from "@/components/ui/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { 
  Calendar, 
  Clock, 
  FileText, 
  Download, 
  Upload, 
  MessageCircle, 
  Star, 
  ExternalLink, 
  AlertCircle, 
  CheckCircle 
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";

// Rating Dialog Component
interface RatingDialogProps {
  orderId: number;
  isOpen: boolean;
  onClose: () => void;
}

function RatingDialog({ orderId, isOpen, onClose }: RatingDialogProps) {
  const { toast } = useToast();
  const [rating, setRating] = useState<number>(5);
  const [review, setReview] = useState<string>("");

  const rateOrderMutation = useMutation({
    mutationFn: async (data: { rating: number; review: string }) => {
      const res = await apiRequest("POST", `/api/orders/${orderId}/rate`, data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Rating submitted",
        description: "Thank you for your feedback!",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/orders/${orderId}`] });
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to submit rating",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    rateOrderMutation.mutate({
      rating,
      review,
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Rate the Writer</DialogTitle>
          <DialogDescription>
            Please rate the quality of work and your experience with the writer
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="rating">Rating (1-5 stars)</Label>
            <div className="flex items-center space-x-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setRating(star)}
                  className="focus:outline-none"
                >
                  <Star
                    className={`h-8 w-8 ${
                      star <= rating
                        ? "text-yellow-500 fill-yellow-500"
                        : "text-neutral-300"
                    }`}
                  />
                </button>
              ))}
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="review">Review (Optional)</Label>
            <Textarea
              id="review"
              placeholder="Share your experience with the writer..."
              value={review}
              onChange={(e) => setReview(e.target.value)}
              rows={4}
            />
          </div>
          <DialogFooter>
            <Button variant="outline" type="button" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={rateOrderMutation.isPending}>
              {rateOrderMutation.isPending ? "Submitting..." : "Submit Rating"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// Dispute Dialog Component
interface DisputeDialogProps {
  orderId: number;
  isOpen: boolean;
  onClose: () => void;
}

function DisputeDialog({ orderId, isOpen, onClose }: DisputeDialogProps) {
  const { toast } = useToast();
  const [reason, setReason] = useState<string>("");
  const [description, setDescription] = useState<string>("");

  const createDisputeMutation = useMutation({
    mutationFn: async (data: { reason: string; description: string }) => {
      const res = await apiRequest("POST", `/api/orders/${orderId}/dispute`, data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Dispute filed",
        description: "An admin will review your case shortly",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/orders/${orderId}`] });
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to file dispute",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createDisputeMutation.mutate({
      reason,
      description,
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Open a Dispute</DialogTitle>
          <DialogDescription>
            Please provide details about the issue with this order
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="reason">Reason for Dispute</Label>
            <select
              id="reason"
              className="w-full p-2 border rounded-md"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              required
            >
              <option value="">Select a reason</option>
              <option value="quality">Poor Quality Work</option>
              <option value="plagiarism">Plagiarism</option>
              <option value="late">Late Delivery</option>
              <option value="requirements">Did Not Meet Requirements</option>
              <option value="communication">Poor Communication</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">Detailed Description</Label>
            <Textarea
              id="description"
              placeholder="Please provide specific details about the issue..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={6}
              required
            />
          </div>
          <DialogFooter>
            <Button variant="outline" type="button" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" variant="destructive" disabled={createDisputeMutation.isPending}>
              {createDisputeMutation.isPending ? "Filing..." : "File Dispute"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// Upload Work Dialog Component
interface UploadWorkDialogProps {
  orderId: number;
  isOpen: boolean;
  onClose: () => void;
}

function UploadWorkDialog({ orderId, isOpen, onClose }: UploadWorkDialogProps) {
  const { toast } = useToast();
  const [workUrl, setWorkUrl] = useState<string>("");
  const [message, setMessage] = useState<string>("");

  const submitWorkMutation = useMutation({
    mutationFn: async (data: { submittedWork: string; message: string }) => {
      const res = await apiRequest("PUT", `/api/orders/${orderId}/complete`, data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Work submitted",
        description: "The client will be notified to review your work",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/orders/${orderId}`] });
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to submit work",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitWorkMutation.mutate({
      submittedWork: workUrl,
      message,
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Submit Completed Work</DialogTitle>
          <DialogDescription>
            Provide the link to your completed work and any delivery notes
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="workUrl">Work URL/Link</Label>
            <Input
              id="workUrl"
              placeholder="https://drive.google.com/..."
              value={workUrl}
              onChange={(e) => setWorkUrl(e.target.value)}
              required
            />
            <p className="text-xs text-neutral-500">
              Please upload your work to Google Drive, Dropbox, or similar service and share the link here
            </p>
          </div>
          <div className="space-y-2">
            <Label htmlFor="message">Delivery Notes (Optional)</Label>
            <Textarea
              id="message"
              placeholder="Any notes or instructions for the client..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={4}
            />
          </div>
          <DialogFooter>
            <Button variant="outline" type="button" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={submitWorkMutation.isPending}>
              {submitWorkMutation.isPending ? "Submitting..." : "Submit Work"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function OrderDetailPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, params] = useRoute<{ id: string }>("/orders/:id");
  const orderId = parseInt(params?.id || "0");
  
  const [isRatingDialogOpen, setIsRatingDialogOpen] = useState(false);
  const [isDisputeDialogOpen, setIsDisputeDialogOpen] = useState(false);
  const [isUploadWorkDialogOpen, setIsUploadWorkDialogOpen] = useState(false);

  // Fetch order details
  const { data: order, isLoading: isLoadingOrder } = useQuery({
    queryKey: [`/api/orders/${orderId}`],
    enabled: orderId > 0,
  });

  // Fetch messages for this order
  const { data: messages = [], isLoading: isLoadingMessages } = useQuery({
    queryKey: [`/api/orders/${orderId}/messages`],
    enabled: !!order,
  });

  // Accept delivery mutation (for clients)
  const acceptDeliveryMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/orders/${orderId}/accept`, {});
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Delivery accepted",
        description: "The order is now marked as completed",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/orders/${orderId}`] });
      setIsRatingDialogOpen(true);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to accept delivery",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Request revision mutation (for clients)
  const requestRevisionMutation = useMutation({
    mutationFn: async (data: { message: string }) => {
      const res = await apiRequest("POST", `/api/orders/${orderId}/revision`, data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Revision requested",
        description: "The writer has been notified of your request",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/orders/${orderId}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/orders/${orderId}/messages`] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to request revision",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Cancel order mutation
  const cancelOrderMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/orders/${orderId}/cancel`, {});
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Order cancelled",
        description: "The order has been cancelled",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/orders/${orderId}`] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to cancel order",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  if (isLoadingOrder) {
    return (
      <DashboardLayout title="Order Details">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </DashboardLayout>
    );
  }

  if (!order) {
    return (
      <DashboardLayout title="Order Details">
        <div className="flex flex-col items-center justify-center h-64 text-neutral-500">
          <p className="mb-2">Order not found</p>
          <Button variant="outline" onClick={() => window.history.back()}>
            Go Back
          </Button>
        </div>
      </DashboardLayout>
    );
  }

  // Get job details if available
  const job = order.job || {};
  const jobTitle = job.title || `Order #${order.id}`;

  // Format status for display
  const formatStatus = (status: string) => {
    return status.replace('_', ' ').split(' ').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  };

  // Determine if user can take certain actions based on role and order status
  const canRate = user?.role === "client" && order.status === "completed" && !order.writerRating;
  const canDispute = (user?.role === "client" || user?.role === "writer") && 
                    (order.status === "in_progress" || order.status === "completed") &&
                    order.status !== "disputed";
  const canUploadWork = user?.role === "writer" && order.status === "in_progress" && !order.submittedWork;
  const canAcceptDelivery = user?.role === "client" && order.status === "in_progress" && order.submittedWork;
  const canRequestRevision = user?.role === "client" && order.status === "in_progress" && order.submittedWork;
  const canCancelOrder = (user?.role === "client" || user?.id === order.clientId) && 
                         order.status === "in_progress";

  return (
    <DashboardLayout title="Order Details">
      <div className="space-y-6">
        {/* Order Summary */}
        <Card>
          <CardHeader className="px-6 py-5 border-b border-neutral-200">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <Badge className={
                  order.status === "completed" ? "bg-green-100 text-green-800 border-green-200" :
                  order.status === "in_progress" ? "bg-blue-100 text-blue-800 border-blue-200" :
                  order.status === "disputed" ? "bg-red-100 text-red-800 border-red-200" :
                  "bg-neutral-100 text-neutral-800 border-neutral-200"
                }>
                  {formatStatus(order.status)}
                </Badge>
                <CardTitle className="text-2xl font-bold mt-2">{jobTitle}</CardTitle>
              </div>
              <div className="flex flex-wrap gap-2">
                {canRate && (
                  <Button onClick={() => setIsRatingDialogOpen(true)}>
                    <Star className="h-4 w-4 mr-1" /> Rate Writer
                  </Button>
                )}
                {canDispute && (
                  <Button variant="outline" onClick={() => setIsDisputeDialogOpen(true)}>
                    <AlertCircle className="h-4 w-4 mr-1" /> Open Dispute
                  </Button>
                )}
                {canCancelOrder && (
                  <Button variant="outline" onClick={() => {
                    if (window.confirm("Are you sure you want to cancel this order?")) {
                      cancelOrderMutation.mutate();
                    }
                  }}>
                    Cancel Order
                  </Button>
                )}
              </div>
            </div>
            <CardDescription className="flex flex-wrap gap-3 text-sm text-neutral-500 mt-3">
              <div className="flex items-center">
                <Calendar className="h-4 w-4 mr-1" />
                <span>Created: {new Date(order.createdAt).toLocaleDateString()}</span>
              </div>
              {job.deadline && (
                <div className="flex items-center">
                  <Clock className="h-4 w-4 mr-1" />
                  <span>Deadline: {new Date(job.deadline).toLocaleDateString()}</span>
                </div>
              )}
              {order.completedAt && (
                <div className="flex items-center">
                  <CheckCircle className="h-4 w-4 mr-1" />
                  <span>Completed: {new Date(order.completedAt).toLocaleDateString()}</span>
                </div>
              )}
            </CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <div className="border rounded-md p-4 bg-neutral-50">
                <h3 className="font-medium text-neutral-700 mb-2">Payment</h3>
                <p className="text-xl font-semibold">${order.amount || job.budget || "N/A"}</p>
                <Badge className={
                  order.paymentStatus === "paid" ? "bg-green-100 text-green-800 border-green-200" :
                  "bg-yellow-100 text-yellow-800 border-yellow-200"
                }>
                  {order.paymentStatus || "Pending"}
                </Badge>
              </div>
              <div className="border rounded-md p-4 bg-neutral-50">
                <h3 className="font-medium text-neutral-700 mb-2">
                  {user?.role === "writer" ? "Client" : "Writer"}
                </h3>
                <p className="text-xl font-semibold">
                  {user?.role === "writer" 
                    ? order.client?.fullName || "Client" 
                    : order.writer?.fullName || "Writer"}
                </p>
                {order.writer?.rating && (
                  <div className="flex items-center text-sm">
                    <Star className="h-4 w-4 text-yellow-500 fill-yellow-500 mr-1" />
                    <span>{order.writer.rating}/5 Rating</span>
                  </div>
                )}
              </div>
              <div className="border rounded-md p-4 bg-neutral-50">
                <h3 className="font-medium text-neutral-700 mb-2">Order Details</h3>
                {job.wordCount && (
                  <div className="text-sm text-neutral-600">
                    <p>{job.wordCount} words / {job.pages} pages</p>
                    <p>Level: {job.academicLevel}</p>
                    {job.citationStyle && <p>Citation: {job.citationStyle}</p>}
                  </div>
                )}
              </div>
            </div>

            {job.description && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-3">Description</h3>
                <p className="text-neutral-700 whitespace-pre-line">
                  {job.description}
                </p>
              </div>
            )}
            
            {/* Submitted Work Section */}
            {(order.status === "in_progress" || order.status === "completed" || order.status === "disputed") && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-3">Delivery</h3>
                {!order.submittedWork ? (
                  <div className="border border-dashed rounded-md p-6 text-center">
                    {user?.role === "writer" ? (
                      <div>
                        <p className="text-neutral-500 mb-4">Upload your completed work when ready</p>
                        {canUploadWork && (
                          <Button onClick={() => setIsUploadWorkDialogOpen(true)}>
                            <Upload className="h-4 w-4 mr-1" /> Submit Work
                          </Button>
                        )}
                      </div>
                    ) : (
                      <p className="text-neutral-500">The writer has not submitted work yet</p>
                    )}
                  </div>
                ) : (
                  <div className="border rounded-md p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <FileText className="h-5 w-5 mr-2 text-primary-600" />
                        <div>
                          <h4 className="font-medium">Completed Work</h4>
                          <p className="text-sm text-neutral-500">
                            Submitted {order.completedAt ? formatDistanceToNow(new Date(order.completedAt), { addSuffix: true }) : "recently"}
                          </p>
                        </div>
                      </div>
                      <a 
                        href={order.submittedWork} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="inline-flex items-center"
                      >
                        <Button variant="outline" size="sm">
                          <Download className="h-4 w-4 mr-1" /> Download
                        </Button>
                      </a>
                    </div>
                    
                    {canAcceptDelivery && (
                      <div className="mt-4 pt-4 border-t">
                        <div className="flex flex-col sm:flex-row gap-3">
                          <Button
                            variant="default"
                            onClick={() => acceptDeliveryMutation.mutate()}
                            disabled={acceptDeliveryMutation.isPending}
                          >
                            <CheckCircle className="h-4 w-4 mr-1" />
                            {acceptDeliveryMutation.isPending ? "Processing..." : "Accept & Complete"}
                          </Button>
                          {canRequestRevision && (
                            <Button
                              variant="outline"
                              onClick={() => {
                                const message = window.prompt("Please provide details for your revision request:");
                                if (message) {
                                  requestRevisionMutation.mutate({ message });
                                }
                              }}
                              disabled={requestRevisionMutation.isPending}
                            >
                              <MessageCircle className="h-4 w-4 mr-1" />
                              Request Revision
                            </Button>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
            
            {/* Client Review Section (if completed and rated) */}
            {order.status === "completed" && order.writerRating && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-3">Client Review</h3>
                <div className="border rounded-md p-4 bg-neutral-50">
                  <div className="flex items-center mb-2">
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-5 w-5 ${
                            i < order.writerRating
                              ? "text-yellow-500 fill-yellow-500"
                              : "text-neutral-300"
                          }`}
                        />
                      ))}
                    </div>
                    <span className="ml-2 font-medium">
                      {order.writerRating}/5
                    </span>
                  </div>
                  {order.clientReview && (
                    <p className="text-neutral-700 whitespace-pre-line">
                      "{order.clientReview}"
                    </p>
                  )}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Communication Tabs */}
        <Card>
          <CardHeader className="px-6 py-4 border-b border-neutral-200">
            <CardTitle className="text-xl font-semibold">Communication</CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            {isLoadingMessages ? (
              <div className="flex justify-center items-center h-48">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : messages.length === 0 ? (
              <div className="text-center py-8 text-neutral-500">
                <MessageCircle className="h-12 w-12 mx-auto mb-4 text-neutral-300" />
                <p>No messages for this order yet</p>
                <p className="text-sm mt-2">
                  Send a message to communicate about order details or revisions
                </p>
              </div>
            ) : (
              <div className="space-y-6">
                {messages.map((message: any) => {
                  const isFromUser = message.senderId === user?.id;
                  
                  return (
                    <div 
                      key={message.id} 
                      className={`flex ${isFromUser ? 'justify-end' : 'justify-start'}`}
                    >
                      <div 
                        className={`max-w-[80%] rounded-lg p-4 ${
                          isFromUser 
                            ? 'bg-primary-100 text-primary-900' 
                            : 'bg-neutral-100 text-neutral-900'
                        }`}
                      >
                        <div className="flex items-center mb-2">
                          <div className={`h-8 w-8 rounded-full bg-${isFromUser ? 'primary' : 'neutral'}-200 flex items-center justify-center text-${isFromUser ? 'primary' : 'neutral'}-600 font-semibold mr-2`}>
                            {isFromUser ? user.fullName?.charAt(0) || "Y" : message.sender?.fullName?.charAt(0) || "O"}
                          </div>
                          <div className="flex-1">
                            <p className="text-sm font-medium">
                              {isFromUser ? 'You' : message.sender?.fullName || 'Other User'}
                            </p>
                            <p className="text-xs text-neutral-500">
                              {new Date(message.createdAt).toLocaleString()}
                            </p>
                          </div>
                        </div>
                        <p className="whitespace-pre-line">{message.content}</p>
                        {message.attachment && (
                          <a 
                            href={message.attachment} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="block mt-2 text-sm text-primary-600 hover:text-primary-700 flex items-center"
                          >
                            <ExternalLink className="h-3 w-3 mr-1" />
                            Attachment
                          </a>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
            
            {/* Message Input */}
            <div className="mt-6 pt-4 border-t">
              <div className="flex items-end gap-2">
                <Textarea
                  placeholder="Type your message here..."
                  className="flex-1"
                  rows={2}
                />
                <Button>
                  Send
                </Button>
              </div>
              <p className="text-xs text-neutral-500 mt-2">
                Use this chat for order-specific communication
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Dialogs */}
        <RatingDialog
          orderId={orderId}
          isOpen={isRatingDialogOpen}
          onClose={() => setIsRatingDialogOpen(false)}
        />
        
        <DisputeDialog
          orderId={orderId}
          isOpen={isDisputeDialogOpen}
          onClose={() => setIsDisputeDialogOpen(false)}
        />
        
        <UploadWorkDialog
          orderId={orderId}
          isOpen={isUploadWorkDialogOpen}
          onClose={() => setIsUploadWorkDialogOpen(false)}
        />
      </div>
    </DashboardLayout>
  );
}