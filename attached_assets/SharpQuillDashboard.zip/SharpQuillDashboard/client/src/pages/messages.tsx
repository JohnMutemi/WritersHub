import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { DashboardLayout } from "@/components/ui/dashboard-layout";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useSocket } from "@/hooks/use-socket";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { 
  Card, 
  CardContent 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
} from "@/components/ui/form";
import { 
  Search, 
  Send, 
  Paperclip, 
  User,
  Users
} from "lucide-react";

// Schema for sending a message
const messageSchema = z.object({
  content: z.string().min(1, "Message cannot be empty"),
});

export default function MessagesPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const socket = useSocket();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [selectedConversation, setSelectedConversation] = useState<any>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [conversations, setConversations] = useState<any[]>([]);

  // Form for sending messages
  const form = useForm<z.infer<typeof messageSchema>>({
    resolver: zodResolver(messageSchema),
    defaultValues: {
      content: "",
    },
  });

  // Fetch conversations with other users
  const { data: users = [], isLoading: isLoadingUsers } = useQuery({
    queryKey: ["/api/users"],
  });

  // Fetch messages for selected conversation
  const { data: messages = [], isLoading: isLoadingMessages } = useQuery({
    queryKey: [`/api/messages/conversation/${selectedConversation?.id}`],
    enabled: !!selectedConversation,
  });

  // Fetch notifications for unread messages
  const { data: notifications = [] } = useQuery({
    queryKey: ["/api/notifications"],
  });

  // Mutation for sending a message
  const sendMessageMutation = useMutation({
    mutationFn: async (data: { receiverId: number, content: string }) => {
      if (socket && socket.readyState === WebSocket.OPEN) {
        // Send via WebSocket
        socket.send(JSON.stringify({
          type: "chat_message",
          data: {
            receiverId: data.receiverId,
            content: data.content,
          }
        }));
        return null;
      } else {
        // Fallback to REST API
        const response = await apiRequest("POST", "/api/messages", {
          senderId: user?.id,
          receiverId: data.receiverId,
          content: data.content,
        });
        return response.json();
      }
    },
    onSuccess: () => {
      form.reset();
      queryClient.invalidateQueries({ queryKey: [`/api/messages/conversation/${selectedConversation?.id}`] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to send message",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Setup conversations based on users
  useEffect(() => {
    if (user && users.length > 0) {
      // Filter users who aren't the current user
      const otherUsers = users.filter((u: any) => u.id !== user.id);
      
      // Create conversation objects
      const newConversations = otherUsers.map((u: any) => {
        // Find unread messages for this user
        const unreadNotifications = notifications.filter(
          (n: any) => 
            n.type === "new_message" && 
            !n.read && 
            n.relatedUser === u.id
        );
        
        return {
          id: u.id,
          name: u.fullName,
          role: u.role,
          avatar: u.profilePicture || `https://ui-avatars.com/api/?name=${encodeURIComponent(u.fullName)}&background=0D8ABC&color=fff`,
          lastMessage: "No messages yet",
          unreadCount: unreadNotifications.length,
        };
      });
      
      setConversations(newConversations);
      
      // Select first conversation if none selected
      if (!selectedConversation && newConversations.length > 0) {
        setSelectedConversation(newConversations[0]);
      }
    }
  }, [user, users, notifications, selectedConversation]);

  // Listen for new messages from WebSocket
  useEffect(() => {
    if (!socket) return;
    
    const handleNewMessage = (data: any) => {
      if (data.type === "new_message") {
        const newMessage = data.data;
        
        // If it's for the current conversation, invalidate the query to refresh
        if (
          selectedConversation && 
          ((newMessage.senderId === selectedConversation.id && newMessage.receiverId === user?.id) ||
           (newMessage.senderId === user?.id && newMessage.receiverId === selectedConversation.id))
        ) {
          queryClient.invalidateQueries({ queryKey: [`/api/messages/conversation/${selectedConversation.id}`] });
        }
        
        // Update conversations with new message info
        setConversations(prevConversations => 
          prevConversations.map(conv => {
            if (conv.id === newMessage.senderId || conv.id === newMessage.receiverId) {
              return {
                ...conv,
                lastMessage: newMessage.content,
                unreadCount: conv.id === newMessage.senderId ? conv.unreadCount + 1 : conv.unreadCount,
              };
            }
            return conv;
          })
        );
      }
    };
    
    socket.addEventListener("message", (event) => {
      try {
        const data = JSON.parse(event.data);
        handleNewMessage(data);
      } catch (error) {
        console.error("Error parsing WebSocket message:", error);
      }
    });
    
    return () => {
      // Clean up if needed
    };
  }, [socket, selectedConversation, user?.id]);

  // Scroll to bottom of messages when new ones arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Filter conversations based on search query
  const filteredConversations = searchQuery
    ? conversations.filter(conv => 
        conv.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        conv.role.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : conversations;

  // Group conversations by role
  const clientConversations = filteredConversations.filter(conv => conv.role === "client");
  const writerConversations = filteredConversations.filter(conv => conv.role === "writer");
  const adminConversations = filteredConversations.filter(conv => conv.role === "admin");

  // Handle form submission for sending messages
  const onSubmit = (data: z.infer<typeof messageSchema>) => {
    if (!selectedConversation) return;
    
    sendMessageMutation.mutate({
      receiverId: selectedConversation.id,
      content: data.content,
    });
  };

  return (
    <DashboardLayout title="Messages">
      <div className="bg-white rounded-lg shadow-sm overflow-hidden h-[calc(100vh-10rem)]">
        <div className="flex h-full">
          {/* Sidebar - Conversations List */}
          <div className="w-80 border-r border-neutral-200 flex flex-col">
            <div className="p-3 border-b border-neutral-200">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-neutral-400" />
                <Input 
                  placeholder="Search messages..." 
                  className="pl-9"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
            
            <Tabs defaultValue="all" className="flex-1 overflow-hidden flex flex-col">
              <div className="px-3 pt-3">
                <TabsList className="w-full">
                  <TabsTrigger value="all" className="flex-1">All</TabsTrigger>
                  <TabsTrigger value="clients" className="flex-1">Clients</TabsTrigger>
                  <TabsTrigger value="writers" className="flex-1">Writers</TabsTrigger>
                </TabsList>
              </div>
              
              <div className="flex-1 overflow-y-auto">
                <TabsContent value="all" className="m-0 h-full">
                  {isLoadingUsers ? (
                    <div className="flex justify-center items-center h-full">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                    </div>
                  ) : filteredConversations.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full text-neutral-500 p-4">
                      <Users className="h-12 w-12 text-neutral-300 mb-2" />
                      <p className="text-center">No conversations found</p>
                      {searchQuery && <p className="text-sm text-center mt-1">Try adjusting your search</p>}
                    </div>
                  ) : (
                    <div className="divide-y divide-neutral-100">
                      {filteredConversations.map((conv) => (
                        <button
                          key={conv.id}
                          className={`w-full text-left p-3 hover:bg-neutral-50 flex items-center ${
                            selectedConversation?.id === conv.id ? "bg-neutral-100" : ""
                          }`}
                          onClick={() => setSelectedConversation(conv)}
                        >
                          <div className="relative">
                            <img 
                              src={conv.avatar} 
                              alt={conv.name} 
                              className="h-10 w-10 rounded-full"
                            />
                            {conv.role === "client" && (
                              <span className="absolute -bottom-1 -right-1 h-4 w-4 bg-blue-500 rounded-full border-2 border-white"></span>
                            )}
                            {conv.role === "writer" && (
                              <span className="absolute -bottom-1 -right-1 h-4 w-4 bg-purple-500 rounded-full border-2 border-white"></span>
                            )}
                            {conv.role === "admin" && (
                              <span className="absolute -bottom-1 -right-1 h-4 w-4 bg-green-500 rounded-full border-2 border-white"></span>
                            )}
                          </div>
                          <div className="ml-3 flex-1 overflow-hidden">
                            <div className="flex justify-between">
                              <p className="font-medium text-sm text-neutral-900 truncate">{conv.name}</p>
                              {conv.unreadCount > 0 && (
                                <span className="bg-primary-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                                  {conv.unreadCount}
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-neutral-500 truncate">{conv.lastMessage}</p>
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </TabsContent>
                
                <TabsContent value="clients" className="m-0 h-full">
                  {clientConversations.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full text-neutral-500 p-4">
                      <User className="h-12 w-12 text-neutral-300 mb-2" />
                      <p className="text-center">No client conversations</p>
                    </div>
                  ) : (
                    <div className="divide-y divide-neutral-100">
                      {clientConversations.map((conv) => (
                        <button
                          key={conv.id}
                          className={`w-full text-left p-3 hover:bg-neutral-50 flex items-center ${
                            selectedConversation?.id === conv.id ? "bg-neutral-100" : ""
                          }`}
                          onClick={() => setSelectedConversation(conv)}
                        >
                          <div className="relative">
                            <img 
                              src={conv.avatar} 
                              alt={conv.name} 
                              className="h-10 w-10 rounded-full"
                            />
                            <span className="absolute -bottom-1 -right-1 h-4 w-4 bg-blue-500 rounded-full border-2 border-white"></span>
                          </div>
                          <div className="ml-3 flex-1 overflow-hidden">
                            <div className="flex justify-between">
                              <p className="font-medium text-sm text-neutral-900 truncate">{conv.name}</p>
                              {conv.unreadCount > 0 && (
                                <span className="bg-primary-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                                  {conv.unreadCount}
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-neutral-500 truncate">{conv.lastMessage}</p>
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </TabsContent>
                
                <TabsContent value="writers" className="m-0 h-full">
                  {writerConversations.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full text-neutral-500 p-4">
                      <User className="h-12 w-12 text-neutral-300 mb-2" />
                      <p className="text-center">No writer conversations</p>
                    </div>
                  ) : (
                    <div className="divide-y divide-neutral-100">
                      {writerConversations.map((conv) => (
                        <button
                          key={conv.id}
                          className={`w-full text-left p-3 hover:bg-neutral-50 flex items-center ${
                            selectedConversation?.id === conv.id ? "bg-neutral-100" : ""
                          }`}
                          onClick={() => setSelectedConversation(conv)}
                        >
                          <div className="relative">
                            <img 
                              src={conv.avatar} 
                              alt={conv.name} 
                              className="h-10 w-10 rounded-full"
                            />
                            <span className="absolute -bottom-1 -right-1 h-4 w-4 bg-purple-500 rounded-full border-2 border-white"></span>
                          </div>
                          <div className="ml-3 flex-1 overflow-hidden">
                            <div className="flex justify-between">
                              <p className="font-medium text-sm text-neutral-900 truncate">{conv.name}</p>
                              {conv.unreadCount > 0 && (
                                <span className="bg-primary-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                                  {conv.unreadCount}
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-neutral-500 truncate">{conv.lastMessage}</p>
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </TabsContent>
              </div>
            </Tabs>
          </div>
          
          {/* Main Chat Area */}
          <div className="flex-1 flex flex-col">
            {!selectedConversation ? (
              <div className="flex flex-col items-center justify-center h-full text-neutral-500">
                <div className="h-16 w-16 rounded-full bg-neutral-100 flex items-center justify-center mb-4">
                  <Users className="h-8 w-8 text-neutral-400" />
                </div>
                <h3 className="text-lg font-medium text-neutral-700">Your Messages</h3>
                <p className="text-center text-sm mt-2 max-w-md">
                  Select a conversation from the sidebar to start messaging
                </p>
              </div>
            ) : (
              <>
                {/* Chat Header */}
                <div className="px-4 py-3 border-b border-neutral-200 flex items-center">
                  <div className="flex items-center">
                    <div className="relative">
                      <img 
                        src={selectedConversation.avatar} 
                        alt={selectedConversation.name} 
                        className="h-10 w-10 rounded-full"
                      />
                      {selectedConversation.role === "client" && (
                        <span className="absolute -bottom-1 -right-1 h-4 w-4 bg-blue-500 rounded-full border-2 border-white"></span>
                      )}
                      {selectedConversation.role === "writer" && (
                        <span className="absolute -bottom-1 -right-1 h-4 w-4 bg-purple-500 rounded-full border-2 border-white"></span>
                      )}
                      {selectedConversation.role === "admin" && (
                        <span className="absolute -bottom-1 -right-1 h-4 w-4 bg-green-500 rounded-full border-2 border-white"></span>
                      )}
                    </div>
                    <div className="ml-3">
                      <p className="font-medium text-neutral-900">{selectedConversation.name}</p>
                      <p className="text-xs text-neutral-500 capitalize">{selectedConversation.role}</p>
                    </div>
                  </div>
                </div>
                
                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {isLoadingMessages ? (
                    <div className="flex justify-center items-center h-full">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                    </div>
                  ) : messages.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full text-neutral-500">
                      <p className="text-center">No messages yet</p>
                      <p className="text-sm text-center mt-1">Start the conversation by sending a message</p>
                    </div>
                  ) : (
                    <>
                      {messages.map((message: any) => {
                        const isSentByCurrentUser = message.senderId === user?.id;
                        return (
                          <div
                            key={message.id}
                            className={`flex items-end ${
                              isSentByCurrentUser ? "justify-end" : ""
                            }`}
                          >
                            {!isSentByCurrentUser && (
                              <img
                                src={selectedConversation.avatar}
                                alt={selectedConversation.name}
                                className="h-8 w-8 rounded-full mr-2"
                              />
                            )}
                            <div
                              className={`px-4 py-2 rounded-lg max-w-md ${
                                isSentByCurrentUser
                                  ? "bg-primary-600 text-white rounded-br-none"
                                  : "bg-neutral-100 text-neutral-800 rounded-bl-none"
                              }`}
                            >
                              <p className={`text-sm ${isSentByCurrentUser ? "text-white" : "text-neutral-800"}`}>
                                {message.content}
                              </p>
                              <p
                                className={`text-xs mt-1 ${
                                  isSentByCurrentUser ? "text-primary-200" : "text-neutral-500"
                                }`}
                              >
                                {formatDistanceToNow(new Date(message.createdAt), {
                                  addSuffix: true,
                                })}
                              </p>
                              {message.attachment && (
                                <div className="mt-2 p-2 bg-white rounded border border-neutral-200">
                                  <div className="flex items-center">
                                    <Paperclip className="h-4 w-4 text-neutral-500 mr-2" />
                                    <div>
                                      <p className="text-xs font-medium text-neutral-800">
                                        {message.attachment.split("/").pop()}
                                      </p>
                                    </div>
                                    <a 
                                      href={message.attachment} 
                                      download
                                      className="ml-auto text-primary-600 text-xs"
                                      target="_blank" 
                                      rel="noopener noreferrer"
                                    >
                                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                                      </svg>
                                    </a>
                                  </div>
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })}
                      <div ref={messagesEndRef} />
                    </>
                  )}
                </div>
                
                {/* Message Input */}
                <div className="px-4 py-3 border-t border-neutral-200">
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="flex items-center space-x-2">
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="text-neutral-500 hover:text-neutral-700"
                        disabled={sendMessageMutation.isPending}
                      >
                        <Paperclip className="h-5 w-5" />
                      </Button>
                      <FormField
                        control={form.control}
                        name="content"
                        render={({ field }) => (
                          <FormItem className="flex-1">
                            <FormControl>
                              <Input 
                                placeholder="Type a message..." 
                                {...field}
                                disabled={sendMessageMutation.isPending}
                                className="rounded-full"
                                onKeyDown={(e) => {
                                  if (e.key === "Enter" && !e.shiftKey) {
                                    e.preventDefault();
                                    form.handleSubmit(onSubmit)();
                                  }
                                }}
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                      <Button 
                        type="submit" 
                        size="icon"
                        className="rounded-full"
                        disabled={sendMessageMutation.isPending || !form.getValues().content.trim()}
                      >
                        <Send className="h-5 w-5" />
                      </Button>
                    </form>
                  </Form>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
