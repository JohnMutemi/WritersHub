import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import WriterDashboard from "@/pages/writer/writer-dashboard";
import ClientDashboard from "@/pages/client/client-dashboard";
import AdminDashboard from "@/pages/admin/admin-dashboard";

export default function DashboardPage() {
  const { user } = useAuth();
  const [_, setLocation] = useLocation();

  useEffect(() => {
    // If user isn't authenticated, this will be caught by ProtectedRoute
    if (!user) return;

    // Set the proper dashboard title based on role
    document.title = `${user.role.charAt(0).toUpperCase() + user.role.slice(1)} Dashboard | SharpQuill`;
  }, [user]);

  // Render the appropriate dashboard based on user role
  if (!user) return null;

  switch (user.role) {
    case "writer":
      return <WriterDashboard />;
    case "client":
      return <ClientDashboard />;
    case "admin":
      return <AdminDashboard />;
    default:
      // In case of an unexpected role, redirect to auth
      setLocation("/auth");
      return null;
  }
}
