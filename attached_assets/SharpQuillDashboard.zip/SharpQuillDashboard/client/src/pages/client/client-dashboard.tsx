import React, { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { DashboardLayout } from "@/components/ui/dashboard-layout";
import { StatCard } from "@/components/ui/stat-card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Job, Order, InsertJob, Bid, User } from "@shared/schema";
import { 
  FileText, 
  DollarSign, 
  Users, 
  Clock, 
  CheckCircle, 
  AlertTriangle,
  Plus,
  Briefcase,
  User as UserIcon
} from "lucide-react";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { CreateJobModal } from "@/components/create-job-modal";

export default function ClientDashboard() {
  const { user, isLoading } = useAuth();
  const [isJobModalOpen, setIsJobModalOpen] = useState(false);
  
  // Fetch client's jobs
  const { data: jobs = [] } = useQuery<Job[]>({
    queryKey: ["/api/clients/jobs"],
    enabled: !!user && user.role === "client",
  });
  
  // Fetch client's orders
  const { data: orders = [] } = useQuery<Order[]>({
    queryKey: ["/api/clients/orders"],
    enabled: !!user && user.role === "client",
  });
  
  // Calculate dashboard stats
  const activeJobs = jobs.filter(job => job.status === "open").length;
  const pendingOrders = orders.filter(order => order.status === "in_progress").length;
  const completedOrders = orders.filter(order => order.status === "completed").length;
  const totalSpent = orders
    .filter(order => order.status === "completed")
    .reduce((total, order) => total + order.amount, 0);
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin h-10 w-10 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }
  
  if (!user || user.role !== "client") {
    return <Redirect to="/auth" />;
  }
  
  return (
    <DashboardLayout>
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
          <h1 className="text-2xl font-bold">Client Dashboard</h1>
          <Button 
            onClick={() => setIsJobModalOpen(true)}
            className="mt-4 md:mt-0 flex items-center"
          >
            <Plus className="mr-2 h-4 w-4" />
            Post New Job
          </Button>
        </div>
        
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatCard
            label="Active Jobs"
            value={activeJobs}
            icon={<Briefcase className="h-6 w-6" />}
            changeType="positive"
          />
          <StatCard
            label="Orders in Progress"
            value={pendingOrders}
            icon={<Clock className="h-6 w-6" />}
            changeType="neutral"
          />
          <StatCard
            label="Completed Orders"
            value={completedOrders}
            icon={<CheckCircle className="h-6 w-6" />}
            changeType="positive"
          />
          <StatCard
            label="Total Spent"
            value={`$${totalSpent.toFixed(2)}`}
            icon={<DollarSign className="h-6 w-6" />}
            changeType="neutral"
          />
        </div>
        
        {/* Main Content Tabs */}
        <Tabs defaultValue="jobs" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="jobs">My Jobs</TabsTrigger>
            <TabsTrigger value="orders">My Orders</TabsTrigger>
            <TabsTrigger value="writers">Top Writers</TabsTrigger>
          </TabsList>
          
          {/* Jobs Tab */}
          <TabsContent value="jobs">
            <div className="grid grid-cols-1 gap-4">
              {jobs.length === 0 ? (
                <Card>
                  <CardContent className="pt-6 text-center">
                    <p className="text-neutral-500 mb-4">You haven't posted any jobs yet.</p>
                    <Button onClick={() => setIsJobModalOpen(true)}>
                      Post Your First Job
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                jobs.map(job => (
                  <JobCard key={job.id} job={job} />
                ))
              )}
            </div>
          </TabsContent>
          
          {/* Orders Tab */}
          <TabsContent value="orders">
            <div className="grid grid-cols-1 gap-4">
              {orders.length === 0 ? (
                <Card>
                  <CardContent className="pt-6 text-center">
                    <p className="text-neutral-500">You don't have any orders yet.</p>
                  </CardContent>
                </Card>
              ) : (
                orders.map(order => (
                  <OrderCard key={order.id} order={order} />
                ))
              )}
            </div>
          </TabsContent>
          
          {/* Writers Tab */}
          <TabsContent value="writers">
            <WriterList />
          </TabsContent>
        </Tabs>
      </div>
      
      {/* Create Job Modal */}
      <CreateJobModal 
        isOpen={isJobModalOpen} 
        onClose={() => setIsJobModalOpen(false)} 
      />
    </DashboardLayout>
  );
}

// Job Card Component
function JobCard({ job }: { job: Job }) {
  // Fetch bids for this job
  const { data: bids = [] } = useQuery<Bid[]>({
    queryKey: ["/api/jobs", job.id, "bids"],
    enabled: !!job,
  });
  
  const statusColor = {
    open: "bg-green-100 text-green-800",
    in_progress: "bg-blue-100 text-blue-800",
    completed: "bg-purple-100 text-purple-800",
    cancelled: "bg-red-100 text-red-800",
    disputed: "bg-orange-100 text-orange-800",
  };
  
  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex justify-between">
          <div>
            <CardTitle>{job.title}</CardTitle>
            <CardDescription>
              Posted on {job.createdAt ? format(new Date(job.createdAt), 'MMM dd, yyyy') : 'Unknown date'}
            </CardDescription>
          </div>
          <Badge className={statusColor[job.status]}>{job.status}</Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
          <div>
            <p className="text-sm text-neutral-500">Budget</p>
            <p className="font-medium">${job.budget.toFixed(2)}</p>
          </div>
          <div>
            <p className="text-sm text-neutral-500">Deadline</p>
            <p className="font-medium">{format(new Date(job.deadline), 'MMM dd, yyyy')}</p>
          </div>
          <div>
            <p className="text-sm text-neutral-500">Pages</p>
            <p className="font-medium">{job.pages}</p>
          </div>
          <div>
            <p className="text-sm text-neutral-500">Words</p>
            <p className="font-medium">{job.wordCount}</p>
          </div>
        </div>
        
        <div className="mb-4">
          <p className="text-sm font-medium mb-1">Description</p>
          <p className="text-sm text-neutral-600 line-clamp-2">{job.description}</p>
        </div>
        
        <div className="flex justify-between items-center">
          <div>
            <p className="text-sm text-neutral-500">
              <span className="font-medium">{bids.length}</span> bids received
            </p>
          </div>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm">
              View Details
            </Button>
            <Button size="sm">
              View Bids
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Order Card Component
function OrderCard({ order }: { order: Order }) {
  const statusColor = {
    open: "bg-green-100 text-green-800",
    in_progress: "bg-blue-100 text-blue-800",
    completed: "bg-purple-100 text-purple-800",
    cancelled: "bg-red-100 text-red-800",
    disputed: "bg-orange-100 text-orange-800",
  };
  
  // Fetch writer info
  const { data: writer } = useQuery<User>({
    queryKey: ["/api/users", order.writerId],
    enabled: !!order.writerId,
  });
  
  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex justify-between">
          <div>
            <CardTitle>{order.title}</CardTitle>
            <CardDescription>
              Order #{order.id} • {order.createdAt ? format(new Date(order.createdAt), 'MMM dd, yyyy') : 'Unknown date'}
            </CardDescription>
          </div>
          <Badge className={statusColor[order.status]}>{order.status}</Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
          <div>
            <p className="text-sm text-neutral-500">Amount</p>
            <p className="font-medium">${order.amount.toFixed(2)}</p>
          </div>
          <div>
            <p className="text-sm text-neutral-500">Deadline</p>
            <p className="font-medium">{format(new Date(order.deadline), 'MMM dd, yyyy')}</p>
          </div>
          <div>
            <p className="text-sm text-neutral-500">Writer</p>
            <p className="font-medium">{writer?.fullName || 'Loading...'}</p>
          </div>
          <div>
            <p className="text-sm text-neutral-500">Delivery Status</p>
            <p className={cn("font-medium", 
              order.deliveryDate ? "text-green-600" : "text-yellow-600"
            )}>
              {order.deliveryDate ? format(new Date(order.deliveryDate), 'MMM dd, yyyy') : 'Pending'}
            </p>
          </div>
        </div>
        
        <div className="flex justify-end space-x-2">
          <Button variant="outline" size="sm">
            Message Writer
          </Button>
          <Button size="sm">
            View Order
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

// Writer List Component
function WriterList() {
  // Fetch top writers
  const { data: writers = [] } = useQuery<User[]>({
    queryKey: ["/api/writers/top"],
  });
  
  if (writers.length === 0) {
    return (
      <Card>
        <CardContent className="pt-6 text-center">
          <p className="text-neutral-500">No writers available at the moment.</p>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {writers.map(writer => (
        <Card key={writer.id}>
          <CardContent className="pt-6">
            <div className="flex items-center space-x-4">
              <div className="h-12 w-12 rounded-full bg-primary-100 flex items-center justify-center">
                {writer.profilePicture ? (
                  <img 
                    src={writer.profilePicture} 
                    alt={writer.fullName} 
                    className="h-12 w-12 rounded-full object-cover"
                  />
                ) : (
                  <UserIcon className="h-6 w-6 text-primary-600" />
                )}
              </div>
              <div>
                <p className="font-medium">{writer.fullName}</p>
                <div className="flex items-center text-sm text-yellow-500">
                  {Array(5).fill(0).map((_, i) => (
                    <span key={i}>
                      {i < Math.floor(writer.rating || 0) ? "★" : "☆"}
                    </span>
                  ))}
                  <span className="ml-1 text-neutral-600">
                    {writer.rating?.toFixed(1) || "New"}
                  </span>
                </div>
              </div>
            </div>
            
            <div className="mt-4">
              <p className="text-sm text-neutral-600 line-clamp-3">
                {writer.bio || "No bio available."}
              </p>
              
              <div className="mt-3 flex flex-wrap gap-1">
                {writer.specializations?.map((spec, i) => (
                  <Badge key={i} variant="outline" className="text-xs">
                    {spec}
                  </Badge>
                ))}
              </div>
            </div>
            
            <div className="mt-4 flex justify-end">
              <Button size="sm" variant="outline">View Profile</Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}