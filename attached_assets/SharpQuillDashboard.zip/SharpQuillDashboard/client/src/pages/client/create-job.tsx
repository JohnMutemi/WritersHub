import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { z } from "zod";
import { DashboardLayout } from "@/components/ui/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertJobSchema } from "@shared/schema";
import { DollarSign, Calendar, Clock, Upload, FileText } from "lucide-react";

// Extend the schema with additional validation
const createJobSchema = insertJobSchema.extend({
  title: z.string().min(5, "Title must be at least 5 characters long"),
  description: z.string().min(30, "Description must be at least 30 characters long"),
  budget: z.coerce.number().positive("Budget must be positive"),
  wordCount: z.coerce.number().int().positive("Word count must be a positive integer"),
  pages: z.coerce.number().int().positive("Page count must be a positive integer"),
  deadline: z.string().refine(val => {
    const date = new Date(val);
    return date > new Date();
  }, "Deadline must be in the future"),
});

export default function CreateJob() {
  const { toast } = useToast();
  const [_, navigate] = useLocation();

  // Define form
  const form = useForm<z.infer<typeof createJobSchema>>({
    resolver: zodResolver(createJobSchema),
    defaultValues: {
      title: "",
      description: "",
      subject: "",
      type: "",
      pages: 1,
      wordCount: 250,
      academicLevel: "Undergraduate",
      citationStyle: "APA",
      budget: 50,
      deadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 7 days from now
    },
  });

  // Create job mutation
  const createJobMutation = useMutation({
    mutationFn: async (data: z.infer<typeof createJobSchema>) => {
      // Format the deadline to ISO string
      const formattedData = {
        ...data,
        deadline: new Date(data.deadline).toISOString(),
        attachments: [], // Would be populated from file uploads in a real implementation
      };
      
      const response = await apiRequest("POST", "/api/jobs", formattedData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Job created successfully",
        description: "Your assignment has been posted and is now open for bids.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
      navigate("/my-jobs");
    },
    onError: (error: any) => {
      toast({
        title: "Failed to create job",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Submit form handler
  const onSubmit = (data: z.infer<typeof createJobSchema>) => {
    createJobMutation.mutate(data);
  };

  return (
    <DashboardLayout title="Create New Assignment">
      <Card>
        <CardHeader>
          <CardTitle>Post a New Writing Assignment</CardTitle>
          <CardDescription>
            Provide detailed information about your assignment to attract qualified writers.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* Assignment title */}
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Assignment Title</FormLabel>
                    <FormControl>
                      <Input placeholder="E.g., Research Paper on Climate Change" {...field} />
                    </FormControl>
                    <FormDescription>
                      Create a clear, specific title that describes your assignment.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Assignment description */}
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Assignment Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Provide detailed instructions, requirements, and any specific guidelines..."
                        className="min-h-[150px]"
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      The more details you provide, the better writers can meet your expectations.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Subject and Type section */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="subject"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Subject</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a subject" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Business">Business</SelectItem>
                          <SelectItem value="English">English</SelectItem>
                          <SelectItem value="History">History</SelectItem>
                          <SelectItem value="Science">Science</SelectItem>
                          <SelectItem value="Mathematics">Mathematics</SelectItem>
                          <SelectItem value="Psychology">Psychology</SelectItem>
                          <SelectItem value="Sociology">Sociology</SelectItem>
                          <SelectItem value="Economics">Economics</SelectItem>
                          <SelectItem value="Philosophy">Philosophy</SelectItem>
                          <SelectItem value="Computer Science">Computer Science</SelectItem>
                          <SelectItem value="Other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Assignment Type</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Essay">Essay</SelectItem>
                          <SelectItem value="Research Paper">Research Paper</SelectItem>
                          <SelectItem value="Case Study">Case Study</SelectItem>
                          <SelectItem value="Report">Report</SelectItem>
                          <SelectItem value="Literature Review">Literature Review</SelectItem>
                          <SelectItem value="Term Paper">Term Paper</SelectItem>
                          <SelectItem value="Thesis">Thesis</SelectItem>
                          <SelectItem value="Dissertation">Dissertation</SelectItem>
                          <SelectItem value="Article">Article</SelectItem>
                          <SelectItem value="Other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Pages, Word Count, Academic Level section */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <FormField
                  control={form.control}
                  name="pages"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Number of Pages</FormLabel>
                      <FormControl>
                        <div className="flex items-center">
                          <Input 
                            type="number" 
                            min="1"
                            className="rounded-r-none"
                            {...field}
                            onChange={(e) => {
                              field.onChange(e);
                              // Update word count based on pages (250 words per page)
                              const pages = parseInt(e.target.value) || 1;
                              form.setValue("wordCount", pages * 250);
                            }}
                          />
                          <div className="bg-neutral-100 px-3 py-2 border border-l-0 border-input rounded-r-md text-sm text-neutral-500">
                            <FileText className="h-4 w-4" />
                          </div>
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="wordCount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Word Count</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          min="250"
                          step="250"
                          {...field}
                          onChange={(e) => {
                            field.onChange(e);
                            // Update pages based on word count (1 page = 250 words)
                            const wordCount = parseInt(e.target.value) || 250;
                            form.setValue("pages", Math.ceil(wordCount / 250));
                          }}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="academicLevel"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Academic Level</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select level" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="High School">High School</SelectItem>
                          <SelectItem value="Undergraduate">Undergraduate</SelectItem>
                          <SelectItem value="Master's">Master's</SelectItem>
                          <SelectItem value="Ph.D.">Ph.D.</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Citation style, Deadline, Budget section */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <FormField
                  control={form.control}
                  name="citationStyle"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Citation Style</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select style" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="APA">APA</SelectItem>
                          <SelectItem value="MLA">MLA</SelectItem>
                          <SelectItem value="Chicago">Chicago</SelectItem>
                          <SelectItem value="Harvard">Harvard</SelectItem>
                          <SelectItem value="IEEE">IEEE</SelectItem>
                          <SelectItem value="None">None</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="deadline"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Deadline</FormLabel>
                      <FormControl>
                        <div className="flex items-center">
                          <Input 
                            type="date"
                            className="rounded-r-none"
                            {...field}
                          />
                          <div className="bg-neutral-100 px-3 py-2 border border-l-0 border-input rounded-r-md text-sm text-neutral-500">
                            <Calendar className="h-4 w-4" />
                          </div>
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="budget"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Budget (USD)</FormLabel>
                      <FormControl>
                        <div className="flex items-center">
                          <div className="bg-neutral-100 px-3 py-2 border border-r-0 border-input rounded-l-md text-sm text-neutral-500">
                            <DollarSign className="h-4 w-4" />
                          </div>
                          <Input 
                            type="number"
                            min="10"
                            step="5"
                            className="rounded-l-none"
                            {...field}
                          />
                        </div>
                      </FormControl>
                      <FormDescription>
                        Higher budgets attract more experienced writers.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* File Attachments */}
              <div className="border-2 border-dashed border-neutral-300 rounded-md p-6">
                <div className="flex flex-col items-center text-center">
                  <Upload className="h-10 w-10 text-neutral-400 mb-2" />
                  <h3 className="text-neutral-900 font-medium">Upload Attachments</h3>
                  <p className="text-neutral-500 text-sm mt-1">
                    Drag and drop files here or click to browse
                  </p>
                  <p className="text-neutral-400 text-xs mt-1">
                    PDF, DOCX, PNG, JPG up to 10MB each
                  </p>
                  <Button
                    type="button"
                    variant="outline"
                    className="mt-4"
                  >
                    Select Files
                  </Button>
                </div>
              </div>

              {/* Submit button */}
              <div className="flex justify-end space-x-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate("/")}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createJobMutation.isPending}
                  className="min-w-[150px]"
                >
                  {createJobMutation.isPending ? (
                    <>
                      <Clock className="mr-2 h-4 w-4 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    "Post Assignment"
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </DashboardLayout>
  );
}
