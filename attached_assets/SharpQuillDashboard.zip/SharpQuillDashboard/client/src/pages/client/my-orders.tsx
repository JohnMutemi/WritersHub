import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { DashboardLayout } from "@/components/ui/dashboard-layout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { ChatModal } from "@/components/chat-modal";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { formatDistanceToNow } from "date-fns";
import {
  CheckCircle,
  Clock,
  AlertCircle,
  MessageSquare,
  Download,
  Star,
  Search,
  Filter,
  ThumbsUp,
  ThumbsDown
} from "lucide-react";

// Schema for reviewing an order
const reviewSchema = z.object({
  clientReview: z.string().min(10, "Review must be at least 10 characters"),
  writerRating: z.coerce.number().min(1).max(5),
});

// Schema for disputing an order
const disputeSchema = z.object({
  reason: z.string().min(5, "Reason must be at least 5 characters"),
  description: z.string().min(20, "Description must be at least 20 characters"),
});

export default function MyOrders() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTab, setSelectedTab] = useState("active");
  const [showChatModal, setShowChatModal] = useState(false);
  const [selectedWriterId, setSelectedWriterId] = useState<number | null>(null);
  const [selectedWriterName, setSelectedWriterName] = useState("");
  const [selectedOrderId, setSelectedOrderId] = useState<number | null>(null);
  const [selectedOrderTitle, setSelectedOrderTitle] = useState("");
  const [showReviewDialog, setShowReviewDialog] = useState(false);
  const [showDisputeDialog, setShowDisputeDialog] = useState(false);

  // Fetch orders
  const { data: orders = [], isLoading } = useQuery({
    queryKey: ["/api/orders"],
  });

  // Fetch writers
  const { data: writers = [] } = useQuery({
    queryKey: ["/api/users"],
    select: (data) => data.filter((user: any) => user.role === "writer"),
  });

  // Initialize review form
  const reviewForm = useForm<z.infer<typeof reviewSchema>>({
    resolver: zodResolver(reviewSchema),
    defaultValues: {
      clientReview: "",
      writerRating: 5,
    },
  });

  // Initialize dispute form
  const disputeForm = useForm<z.infer<typeof disputeSchema>>({
    resolver: zodResolver(disputeSchema),
    defaultValues: {
      reason: "",
      description: "",
    },
  });

  // Review order mutation
  const reviewOrderMutation = useMutation({
    mutationFn: async (data: z.infer<typeof reviewSchema>) => {
      const response = await apiRequest(
        "PUT",
        `/api/orders/${selectedOrderId}/review`,
        data
      );
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      toast({
        title: "Review submitted",
        description: "Thank you for reviewing this order.",
      });
      setShowReviewDialog(false);
    },
    onError: (error: any) => {
      toast({
        title: "Failed to submit review",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Dispute order mutation
  const disputeOrderMutation = useMutation({
    mutationFn: async (data: z.infer<typeof disputeSchema>) => {
      const response = await apiRequest(
        "POST",
        "/api/disputes",
        {
          ...data,
          orderId: selectedOrderId,
        }
      );
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      toast({
        title: "Dispute submitted",
        description: "Your dispute has been submitted and an administrator will review it shortly.",
      });
      setShowDisputeDialog(false);
    },
    onError: (error: any) => {
      toast({
        title: "Failed to submit dispute",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle review submission
  const onSubmitReview = (data: z.infer<typeof reviewSchema>) => {
    reviewOrderMutation.mutate(data);
  };

  // Handle dispute submission
  const onSubmitDispute = (data: z.infer<typeof disputeSchema>) => {
    disputeOrderMutation.mutate(data);
  };

  // Open chat with writer
  const openChat = (writerId: number, writerName: string, orderId: number, orderTitle: string) => {
    setSelectedWriterId(writerId);
    setSelectedWriterName(writerName);
    setSelectedOrderId(orderId);
    setSelectedOrderTitle(orderTitle);
    setShowChatModal(true);
  };

  // Open review dialog
  const openReviewDialog = (orderId: number) => {
    setSelectedOrderId(orderId);
    reviewForm.reset();
    setShowReviewDialog(true);
  };

  // Open dispute dialog
  const openDisputeDialog = (orderId: number) => {
    setSelectedOrderId(orderId);
    disputeForm.reset();
    setShowDisputeDialog(true);
  };

  // Filter orders based on status
  const activeOrders = orders.filter((order: any) => order.status === "in_progress");
  const completedOrders = orders.filter((order: any) => order.status === "completed");
  const disputedOrders = orders.filter((order: any) => order.status === "disputed");

  // Filter orders based on search query
  const filterOrdersBySearch = (orderList: any[]) => {
    if (!searchQuery) return orderList;
    
    return orderList.filter((order: any) => 
      order.id.toString().includes(searchQuery) || 
      (order.title && order.title.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (order.writer?.fullName && order.writer.fullName.toLowerCase().includes(searchQuery.toLowerCase()))
    );
  };

  // Get filtered orders based on current tab
  const getFilteredOrders = () => {
    switch (selectedTab) {
      case "active":
        return filterOrdersBySearch(activeOrders);
      case "completed":
        return filterOrdersBySearch(completedOrders);
      case "disputed":
        return filterOrdersBySearch(disputedOrders);
      default:
        return filterOrdersBySearch(activeOrders);
    }
  };

  // Get writer name from ID
  const getWriterName = (writerId: number) => {
    const writer = writers.find((w: any) => w.id === writerId);
    return writer ? writer.fullName : "Unknown Writer";
  };

  // Get status badge based on order status
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "in_progress":
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">In Progress</Badge>;
      case "completed":
        return <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-100">Completed</Badge>;
      case "disputed":
        return <Badge variant="outline" className="bg-red-100 text-red-800 hover:bg-red-100">Disputed</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <DashboardLayout title="My Orders">
      <div className="space-y-6">
        {/* Search and filter bar */}
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-grow">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-neutral-400" />
            </div>
            <Input
              type="text"
              placeholder="Search orders by ID, title or writer..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button variant="outline" className="md:w-auto" disabled>
            <Filter className="h-4 w-4 mr-2" /> Filter
          </Button>
        </div>

        {/* Orders tabs */}
        <Tabs defaultValue="active" onValueChange={setSelectedTab}>
          <TabsList className="grid grid-cols-3 w-full md:w-auto">
            <TabsTrigger value="active" className="flex items-center">
              <Clock className="h-4 w-4 mr-2" /> 
              Active ({activeOrders.length})
            </TabsTrigger>
            <TabsTrigger value="completed" className="flex items-center">
              <CheckCircle className="h-4 w-4 mr-2" /> 
              Completed ({completedOrders.length})
            </TabsTrigger>
            <TabsTrigger value="disputed" className="flex items-center">
              <AlertCircle className="h-4 w-4 mr-2" /> 
              Disputed ({disputedOrders.length})
            </TabsTrigger>
          </TabsList>

          {/* Tab content */}
          <TabsContent value="active" className="mt-6">
            {renderOrdersList(getFilteredOrders(), "active")}
          </TabsContent>
          
          <TabsContent value="completed" className="mt-6">
            {renderOrdersList(getFilteredOrders(), "completed")}
          </TabsContent>
          
          <TabsContent value="disputed" className="mt-6">
            {renderOrdersList(getFilteredOrders(), "disputed")}
          </TabsContent>
        </Tabs>

        {/* Chat modal */}
        {showChatModal && selectedWriterId && (
          <ChatModal
            recipientId={selectedWriterId}
            recipientName={selectedWriterName}
            recipientAvatar={`https://ui-avatars.com/api/?name=${encodeURIComponent(selectedWriterName)}&background=4F46E5&color=fff`}
            orderId={selectedOrderId || undefined}
            orderTitle={selectedOrderTitle}
            onClose={() => setShowChatModal(false)}
          />
        )}

        {/* Review dialog */}
        <Dialog open={showReviewDialog} onOpenChange={setShowReviewDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Review Order</DialogTitle>
              <DialogDescription>
                Please provide your feedback on the completed work and rate the writer.
              </DialogDescription>
            </DialogHeader>
            
            <Form {...reviewForm}>
              <form onSubmit={reviewForm.handleSubmit(onSubmitReview)} className="space-y-4">
                <FormField
                  control={reviewForm.control}
                  name="writerRating"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Rating (1-5 stars)</FormLabel>
                      <div className="flex items-center space-x-2">
                        {[1, 2, 3, 4, 5].map((rating) => (
                          <button
                            key={rating}
                            type="button"
                            onClick={() => reviewForm.setValue("writerRating", rating)}
                            className="focus:outline-none"
                          >
                            <Star
                              className={`h-8 w-8 ${
                                rating <= field.value
                                  ? "text-yellow-400 fill-yellow-400"
                                  : "text-gray-300"
                              }`}
                            />
                          </button>
                        ))}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={reviewForm.control}
                  name="clientReview"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Your Review</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Please share your thoughts on the quality of work, communication, and overall experience working with this writer..."
                          className="min-h-[150px]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowReviewDialog(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={reviewOrderMutation.isPending}
                  >
                    {reviewOrderMutation.isPending ? "Submitting..." : "Submit Review"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        {/* Dispute dialog */}
        <Dialog open={showDisputeDialog} onOpenChange={setShowDisputeDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Open Dispute</DialogTitle>
              <DialogDescription>
                Please provide details about your concerns with this order.
              </DialogDescription>
            </DialogHeader>
            
            <Form {...disputeForm}>
              <form onSubmit={disputeForm.handleSubmit(onSubmitDispute)} className="space-y-4">
                <FormField
                  control={disputeForm.control}
                  name="reason"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Reason for Dispute</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., Quality issues, Plagiarism, Missed requirements" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={disputeForm.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Detailed Description</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Please provide specific details about the issues you've encountered with this order..."
                          className="min-h-[150px]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowDisputeDialog(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    variant="destructive"
                    disabled={disputeOrderMutation.isPending}
                  >
                    {disputeOrderMutation.isPending ? "Submitting..." : "Open Dispute"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );

  // Helper function to render orders list based on status
  function renderOrdersList(orders: any[], status: string) {
    if (isLoading) {
      return (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      );
    }
    
    if (orders.length === 0) {
      return (
        <Card>
          <CardContent className="flex flex-col items-center justify-center h-64">
            <p className="text-neutral-500">No {status} orders found</p>
            {status === "active" && (
              <p className="text-sm text-neutral-400 mt-2">
                {searchQuery ? "Try adjusting your search query" : "Create a new assignment to get started"}
              </p>
            )}
          </CardContent>
        </Card>
      );
    }
    
    return (
      <div className="grid grid-cols-1 gap-6">
        {orders.map((order: any) => (
          <Card key={order.id}>
            <CardHeader className="pb-3">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-lg">{order.title || `Order #${order.id}`}</CardTitle>
                  <div className="text-sm text-neutral-500 mt-1">
                    Order #{order.id} • 
                    {status === "active" && " Due "}
                    {status === "completed" && " Completed "}
                    {status === "disputed" && " Disputed "}
                    {order.completedAt ? 
                      formatDistanceToNow(new Date(order.completedAt), { addSuffix: true }) : 
                      order.deadline ? 
                        formatDistanceToNow(new Date(order.deadline)) : 
                        "Recently"
                    }
                  </div>
                </div>
                <div>{getStatusBadge(order.status)}</div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center text-sm">
                  <div className="font-medium mr-2">Writer:</div>
                  <div className="flex items-center">
                    <img 
                      src={`https://ui-avatars.com/api/?name=${encodeURIComponent(getWriterName(order.writerId))}&background=4F46E5&color=fff`} 
                      alt={getWriterName(order.writerId)} 
                      className="w-6 h-6 rounded-full mr-2" 
                    />
                    {getWriterName(order.writerId)}
                    
                    {order.writerRating && (
                      <div className="flex ml-4 text-yellow-400">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i} 
                            className={`h-4 w-4 ${i < Math.floor(order.writerRating) ? "fill-yellow-400" : "text-gray-300"}`} 
                          />
                        ))}
                      </div>
                    )}
                  </div>
                </div>
                
                {order.status === "completed" && order.clientReview && (
                  <div className="bg-neutral-50 p-3 rounded-md mt-3">
                    <p className="text-sm font-medium mb-1">Your Review:</p>
                    <p className="text-sm text-neutral-600">{order.clientReview}</p>
                  </div>
                )}
                
                {order.status === "disputed" && order.dispute && (
                  <div className="bg-red-50 p-3 rounded-md mt-3">
                    <p className="text-sm font-medium text-red-800 mb-1">Dispute Reason:</p>
                    <p className="text-sm text-red-700">{order.dispute.reason}</p>
                    <p className="text-sm text-red-600 mt-2">{order.dispute.description}</p>
                    
                    {order.dispute.status === "resolved" && (
                      <div className="mt-3 pt-3 border-t border-red-200">
                        <p className="text-sm font-medium text-green-800">Resolution:</p>
                        <p className="text-sm text-green-700">{order.dispute.resolution}</p>
                      </div>
                    )}
                  </div>
                )}
                
                <div className="flex flex-wrap md:flex-nowrap gap-2 mt-4">
                  <Button 
                    variant="outline" 
                    className="flex-1" 
                    onClick={() => openChat(
                      order.writerId, 
                      getWriterName(order.writerId), 
                      order.id, 
                      order.title || `Order #${order.id}`
                    )}
                  >
                    <MessageSquare className="h-4 w-4 mr-2" /> Message Writer
                  </Button>
                  
                  {order.status === "completed" && !order.clientReview && (
                    <Button 
                      className="flex-1" 
                      onClick={() => openReviewDialog(order.id)}
                    >
                      <Star className="h-4 w-4 mr-2" /> Review Order
                    </Button>
                  )}
                  
                  {order.status === "in_progress" && (
                    <Button 
                      variant="outline" 
                      className="flex-1"
                      onClick={() => openDisputeDialog(order.id)}
                    >
                      <AlertCircle className="h-4 w-4 mr-2" /> Open Dispute
                    </Button>
                  )}
                  
                  {order.submittedWork && (
                    <Button 
                      variant={order.status === "completed" ? "default" : "outline"}
                      className="flex-1"
                    >
                      <Download className="h-4 w-4 mr-2" /> Download Work
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }
}
