import { pgTable, text, serial, integer, boolean, timestamp, json, doublePrecision, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Enums
export const userRoleEnum = pgEnum('user_role', ['client', 'writer', 'admin']);
export const orderStatusEnum = pgEnum('order_status', ['open', 'in_progress', 'completed', 'cancelled', 'disputed']);
export const bidStatusEnum = pgEnum('bid_status', ['pending', 'accepted', 'rejected']);
export const approvalStatusEnum = pgEnum('approval_status', ['pending', 'approved', 'rejected']);

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  fullName: text("full_name").notNull(),
  role: userRoleEnum("role").notNull().default('client'),
  profilePicture: text("profile_picture"),
  rating: doublePrecision("rating").default(0),
  bio: text("bio"),
  specializations: text("specializations").array(),
  earnings: doublePrecision("earnings").default(0),
  approvalStatus: approvalStatusEnum("approval_status").default('pending'),
  quizScore: integer("quiz_score"),
  quizPassed: boolean("quiz_passed"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Jobs table
export const jobs = pgTable("jobs", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  description: text("description").notNull(),
  subject: text("subject").notNull(),
  type: text("type").notNull(),
  pages: integer("pages").notNull(),
  wordCount: integer("word_count").notNull(),
  academicLevel: text("academic_level").notNull(),
  citationStyle: text("citation_style"),
  budget: doublePrecision("budget").notNull(),
  deadline: timestamp("deadline").notNull(),
  status: orderStatusEnum("status").notNull().default('open'),
  attachments: text("attachments").array(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Bids table
export const bids = pgTable("bids", {
  id: serial("id").primaryKey(),
  jobId: integer("job_id").notNull().references(() => jobs.id),
  writerId: integer("writer_id").notNull().references(() => users.id),
  amount: doublePrecision("amount").notNull(),
  deliveryDate: timestamp("delivery_date").notNull(),
  message: text("message"),
  status: bidStatusEnum("status").notNull().default('pending'),
  createdAt: timestamp("created_at").defaultNow(),
});

// Orders table (accepted jobs)
export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  jobId: integer("job_id").notNull().references(() => jobs.id),
  clientId: integer("client_id").notNull().references(() => users.id),
  writerId: integer("writer_id").notNull().references(() => users.id),
  bidId: integer("bid_id").notNull().references(() => bids.id),
  status: orderStatusEnum("status").notNull().default('in_progress'),
  paymentStatus: text("payment_status").notNull().default('pending'),
  submittedWork: text("submitted_work"),
  clientReview: text("client_review"),
  writerRating: doublePrecision("writer_rating"),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Messages table
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  senderId: integer("sender_id").notNull().references(() => users.id),
  receiverId: integer("receiver_id").notNull().references(() => users.id),
  orderId: integer("order_id").references(() => orders.id),
  content: text("content").notNull(),
  attachment: text("attachment"),
  read: boolean("read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Disputes table
export const disputes = pgTable("disputes", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull().references(() => orders.id),
  clientId: integer("client_id").notNull().references(() => users.id),
  writerId: integer("writer_id").notNull().references(() => users.id),
  reason: text("reason").notNull(),
  description: text("description").notNull(),
  status: text("status").notNull().default('open'),
  resolution: text("resolution"),
  resolvedBy: integer("resolved_by").references(() => users.id),
  resolvedAt: timestamp("resolved_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Notifications table
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  type: text("type").notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  read: boolean("read").default(false),
  relatedId: integer("related_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Transactions table
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").references(() => orders.id),
  clientId: integer("client_id").notNull().references(() => users.id),
  writerId: integer("writer_id").references(() => users.id),
  amount: doublePrecision("amount").notNull(),
  type: text("type").notNull(), // deposit, payment, refund, withdrawal
  status: text("status").notNull().default('pending'),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  clientJobs: many(jobs, { relationName: "clientJobs" }),
  writerBids: many(bids, { relationName: "writerBids" }),
  clientOrders: many(orders, { relationName: "clientOrders" }),
  writerOrders: many(orders, { relationName: "writerOrders" }),
  sentMessages: many(messages, { relationName: "senderMessages" }),
  receivedMessages: many(messages, { relationName: "receiverMessages" }),
  notifications: many(notifications),
  clientTransactions: many(transactions, { relationName: "clientTransactions" }),
  writerTransactions: many(transactions, { relationName: "writerTransactions" }),
}));

export const jobsRelations = relations(jobs, ({ one, many }) => ({
  client: one(users, {
    fields: [jobs.clientId],
    references: [users.id],
    relationName: "clientJobs"
  }),
  bids: many(bids),
  order: one(orders, { 
    fields: [jobs.id],
    references: [orders.jobId],
    relationName: "jobOrder" 
  }),
}));

export const bidsRelations = relations(bids, ({ one }) => ({
  job: one(jobs, {
    fields: [bids.jobId],
    references: [jobs.id]
  }),
  writer: one(users, {
    fields: [bids.writerId],
    references: [users.id],
    relationName: "writerBids"
  }),
  order: one(orders, {
    fields: [bids.id],
    references: [orders.bidId],
    relationName: "bidOrder" 
  }),
}));

export const ordersRelations = relations(orders, ({ one, many }) => ({
  job: one(jobs, {
    fields: [orders.jobId],
    references: [jobs.id],
    relationName: "jobOrder"
  }),
  client: one(users, {
    fields: [orders.clientId],
    references: [users.id],
    relationName: "clientOrders"
  }),
  writer: one(users, {
    fields: [orders.writerId],
    references: [users.id],
    relationName: "writerOrders"
  }),
  bid: one(bids, {
    fields: [orders.bidId],
    references: [bids.id],
    relationName: "bidOrder"
  }),
  messages: many(messages),
  disputes: many(disputes),
  transactions: many(transactions),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  sender: one(users, {
    fields: [messages.senderId],
    references: [users.id],
    relationName: "senderMessages"
  }),
  receiver: one(users, {
    fields: [messages.receiverId],
    references: [users.id],
    relationName: "receiverMessages"
  }),
  order: one(orders, {
    fields: [messages.orderId],
    references: [orders.id]
  }),
}));

export const disputesRelations = relations(disputes, ({ one }) => ({
  order: one(orders, {
    fields: [disputes.orderId],
    references: [orders.id]
  }),
  client: one(users, {
    fields: [disputes.clientId],
    references: [users.id]
  }),
  writer: one(users, {
    fields: [disputes.writerId],
    references: [users.id]
  }),
  resolvedByAdmin: one(users, {
    fields: [disputes.resolvedBy],
    references: [users.id]
  }),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, {
    fields: [notifications.userId],
    references: [users.id]
  }),
}));

export const transactionsRelations = relations(transactions, ({ one }) => ({
  order: one(orders, {
    fields: [transactions.orderId],
    references: [orders.id]
  }),
  client: one(users, {
    fields: [transactions.clientId],
    references: [users.id],
    relationName: "clientTransactions"
  }),
  writer: one(users, {
    fields: [transactions.writerId],
    references: [users.id],
    relationName: "writerTransactions"
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users)
  .omit({ id: true, createdAt: true, rating: true, earnings: true })
  .extend({
    password: z.string().min(6, "Password must be at least 6 characters"),
  });

export const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

// Create a modified insert schema for jobs with date string handling
export const insertJobSchema = createInsertSchema(jobs, {
  deadline: z.union([
    z.date(),
    z.string().transform((val) => new Date(val))
  ])
}).omit({ 
  id: true, 
  createdAt: true, 
  clientId: true, 
  status: true 
});

export const insertBidSchema = createInsertSchema(bids, {
  deliveryDate: z.union([
    z.date(),
    z.string().transform((val) => new Date(val))
  ])
}).omit({ 
  id: true, 
  createdAt: true, 
  writerId: true, 
  status: true 
});

export const insertMessageSchema = createInsertSchema(messages).omit({ 
  id: true, 
  createdAt: true, 
  read: true
});

export const insertDisputeSchema = createInsertSchema(disputes).omit({ 
  id: true, 
  createdAt: true, 
  status: true, 
  resolution: true, 
  resolvedBy: true, 
  resolvedAt: true
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type LoginData = z.infer<typeof loginSchema>;

export type Job = typeof jobs.$inferSelect;
export type InsertJob = z.infer<typeof insertJobSchema>;

export type Bid = typeof bids.$inferSelect;
export type InsertBid = z.infer<typeof insertBidSchema>;

export type Order = typeof orders.$inferSelect;

export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;

export type Dispute = typeof disputes.$inferSelect;
export type InsertDispute = z.infer<typeof insertDisputeSchema>;

export type Notification = typeof notifications.$inferSelect;

export type Transaction = typeof transactions.$inferSelect;
